import {
  AuthError,
  corsHeaders,
  createAdminClient,
  json,
  requireAuth,
} from "../_shared/auth.ts";
import { createCheckout, listPaymentMethods, PaymentMethod, readPaymobConfig } from "../_shared/paymob.ts";

interface QuoteBody {
  action: "quote" | "create" | "methods";
  item_type: "COURSE" | "LIVE";
  course_id?: string | null;
  live_plan_id?: string | null;
  live_group_id?: string | null;
  coupon_code?: string | null;
  idempotency_key?: string | null;
  /** Paymob integration the learner picked on the payment screen. */
  method_id?: string | null;
  /** Currency of the quote, used to hide methods the account cannot charge in. */
  currency?: string | null;
}

/** Payment options for the merchant account, cached briefly so a checkout is not slowed down. */
let methodCache: { at: number; methods: PaymentMethod[] } | null = null;
const METHOD_CACHE_MS = 5 * 60 * 1000;

async function paymentMethods(cfg: Parameters<typeof listPaymentMethods>[0]): Promise<PaymentMethod[]> {
  if (methodCache && Date.now() - methodCache.at < METHOD_CACHE_MS) return methodCache.methods;
  const methods = await listPaymentMethods(cfg);
  methodCache = { at: Date.now(), methods };
  return methods;
}

/** Maps a Postgres exception message to a stable, user-safe error code. */
function toErrorCode(message: string): string {
  const known = [
    "COURSE_NOT_AVAILABLE",
    "LIVE_NOT_AVAILABLE",
    "TEACHER_NOT_ACCEPTING_STUDENTS",
    "GROUP_FULL",
    "GROUP_NOT_FOUND",
    "ALREADY_ENROLLED",
    "ACCOUNT_NOT_ACTIVE",
    "ITEM_NOT_FOUND",
  ];
  const hit = known.find((k) => message.includes(k));
  return hit ?? "CHECKOUT_FAILED";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const user = await requireAuth(req);
    const body = (await req.json()) as QuoteBody;
    const admin = createAdminClient();

    // One catalogue, one price, for everyone.
    //
    // Pricing used to follow the buyer's detected location, which meant someone travelling or
    // using a foreign network could be quoted a currency the gateway cannot charge — in effect a
    // country restriction. The platform's own country decides the price now, so anyone anywhere
    // pays the same amount through the same live payment methods.
    const { data: defaultCountryRaw } = await admin
      .from("app_settings")
      .select("value")
      .eq("key", "pricing.default_country")
      .maybeSingle();
    const country =
      (typeof defaultCountryRaw?.value === "string" ? (defaultCountryRaw.value as string) : "EG")
        .toUpperCase();

    if (body.action === "quote") {
      const { data, error } = await admin.rpc("quote_checkout", {
        p_user: user.userId,
        p_item_type: body.item_type,
        p_course_id: body.course_id ?? null,
        p_live_plan_id: body.live_plan_id ?? null,
        p_live_group_id: body.live_group_id ?? null,
        p_coupon_code: body.coupon_code ?? null,
        p_country: country,
      });
      if (error) return json({ error: toErrorCode(error.message), detail: error.message }, 400);
      return json({ ok: true, quote: data });
    }

    if (body.action === "methods") {
      const cfg = readPaymobConfig();
      if (!cfg) return json({ ok: true, methods: [] });
      try {
        const wanted = body.currency?.toUpperCase();
        const methods = (await paymentMethods(cfg))
          .filter((m) => !wanted || m.currency === wanted)
          .map(({ id, kind, label }) => ({ id, kind, label }));
        return json({ ok: true, methods });
      } catch (err) {
        // The account may not expose the listing endpoint; the default integration still works.
        console.error("paymob_methods_failed", err instanceof Error ? err.message : err);
        return json({ ok: true, methods: [] });
      }
    }

    if (body.action !== "create") return json({ error: "UNKNOWN_ACTION" }, 400);

    const { data: order, error: orderError } = await admin.rpc("create_order", {
      p_user: user.userId,
      p_item_type: body.item_type,
      p_course_id: body.course_id ?? null,
      p_live_plan_id: body.live_plan_id ?? null,
      p_live_group_id: body.live_group_id ?? null,
      p_coupon_code: body.coupon_code ?? null,
      p_country: country,
      p_idempotency_key: body.idempotency_key ?? null,
    });
    if (orderError) return json({ error: toErrorCode(orderError.message), detail: orderError.message }, 400);

    const row = order as Record<string, unknown>;
    const orderId = row.id as string;
    const total = Number(row.total_amount ?? 0);

    // Free / fully discounted orders are granted immediately — no gateway round trip.
    if (total <= 0) {
      const { error: grantError } = await admin.rpc("confirm_order_payment", {
        p_order_id: orderId,
        p_provider: "FREE",
        p_provider_ref: `free_${orderId}`,
        p_event_id: `free_${orderId}`,
        p_payload: { reason: "ZERO_TOTAL" },
      });
      if (grantError) return json({ error: toErrorCode(grantError.message), detail: grantError.message }, 400);
      return json({ ok: true, order_id: orderId, free: true, total_amount: 0 });
    }

    const cfg = readPaymobConfig();
    if (!cfg) {
      await admin.rpc("fail_order_payment", {
        p_order_id: orderId,
        p_provider: "PAYMOB",
        p_event_id: `cfg_${orderId}`,
        p_status: "PAYMENT_FAILED",
        p_reason: "Payment gateway is not configured yet.",
        p_payload: {},
      });
      return json({ error: "GATEWAY_NOT_CONFIGURED" }, 503);
    }

    const { data: profile } = await admin
      .from("profiles")
      .select("full_name, email, phone")
      .eq("id", user.userId)
      .maybeSingle();

    const nameParts = String(profile?.full_name ?? "7PRO Student").trim().split(" ");

    // Only an integration that really belongs to this account, in the order's own currency,
    // may be charged — the id arrives from the client and is never trusted as-is.
    let integrationId: string | null = null;
    if (body.method_id) {
      const allowed = await paymentMethods(cfg).catch(() => [] as PaymentMethod[]);
      const match = allowed.find(
        (m) => m.id === String(body.method_id) && m.currency === String(row.currency ?? "EGP").toUpperCase(),
      );
      integrationId = match?.id ?? null;
    }

    let session;
    try {
      session = await createCheckout(cfg, {
        orderId,
        amount: total,
        currency: String(row.currency ?? "EGP"),
        description: `7PRO ${String(row.item_type)} purchase`,
        email: String(profile?.email ?? user.email ?? "student@7pro.app"),
        firstName: nameParts[0] ?? "Student",
        lastName: nameParts.slice(1).join(" ") || "7PRO",
        phone: String(profile?.phone ?? ""),
        integrationId,
        country,
      });
    } catch (err) {
      console.error("paymob_checkout_failed", err instanceof Error ? err.message : err);
      await admin.rpc("fail_order_payment", {
        p_order_id: orderId,
        p_provider: "PAYMOB",
        p_event_id: `err_${orderId}`,
        p_status: "PAYMENT_FAILED",
        p_reason: "Could not open the payment page. Please try again.",
        p_payload: {},
      });
      return json({ error: "GATEWAY_UNAVAILABLE" }, 502);
    }

    await admin
      .from("orders")
      .update({ provider: "PAYMOB", provider_ref: session.providerRef, checkout_url: session.checkoutUrl })
      .eq("id", orderId);

    return json({
      ok: true,
      order_id: orderId,
      checkout_url: session.checkoutUrl,
      total_amount: total,
      currency: row.currency,
    });
  } catch (err) {
    if (err instanceof AuthError) return json({ error: "UNAUTHORIZED" }, 401);
    console.error("checkout_error", err instanceof Error ? err.message : err);
    return json({ error: "INTERNAL_ERROR" }, 500);
  }
});
