import { corsHeaders, createAdminClient, json } from "../_shared/auth.ts";

/**
 * Scheduled housekeeping: matures teacher earnings, expires subscriptions and
 * sends renewal / payment reminders. Protected by a shared secret so it can be
 * driven by an external scheduler without exposing it publicly.
 */
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const secret = Deno.env.get("MAINTENANCE_SECRET");
  const provided = req.headers.get("x-maintenance-secret") ?? new URL(req.url).searchParams.get("secret");
  if (!secret || provided !== secret) return json({ error: "UNAUTHORIZED" }, 401);

  const admin = createAdminClient();

  try {
    const { data: released } = await admin.rpc("release_matured_earnings");
    const { data: expired } = await admin.rpc("expire_subscriptions");

    // Renewal reminders for subscriptions ending within 3 days.
    const soon = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString();
    const { data: expiring } = await admin
      .from("subscriptions")
      .select("id, user_id, ends_at, live_service_id")
      .in("status", ["ACTIVE", "EXPIRING"])
      .lte("ends_at", soon)
      .gte("ends_at", new Date().toISOString());

    let reminders = 0;
    for (const sub of expiring ?? []) {
      const { data: already } = await admin
        .from("notifications")
        .select("id")
        .eq("user_id", sub.user_id)
        .eq("kind", "RENEWAL_REMINDER")
        .contains("data", { subscription_id: sub.id })
        .maybeSingle();
      if (already) continue;
      await admin.from("notifications").insert({
        user_id: sub.user_id,
        kind: "RENEWAL_REMINDER",
        title: "Your live subscription is ending soon",
        body: `Renew before ${new Date(sub.ends_at as string).toDateString()} to keep your seat.`,
        data: { subscription_id: sub.id, live_service_id: sub.live_service_id },
      });
      reminders++;
    }

    // Payment reminders on teacher-managed student records.
    const today = new Date().toISOString().slice(0, 10);
    const { data: due } = await admin
      .from("teacher_students")
      .select("id, teacher_id, full_name, next_payment_date, status")
      .in("status", ["DUE_SOON", "OVERDUE"])
      .lte("next_payment_date", today);

    let teacherAlerts = 0;
    for (const record of due ?? []) {
      await admin.from("notifications").insert({
        user_id: record.teacher_id,
        kind: "PAYMENT_REMINDER",
        title: record.status === "OVERDUE" ? "Payment overdue" : "Payment due",
        body: `${record.full_name} — due ${record.next_payment_date}.`,
        data: { teacher_student_id: record.id },
      });
      teacherAlerts++;
    }

    return json({ ok: true, released, expired, reminders, teacherAlerts });
  } catch (err) {
    console.error("maintenance_error", err instanceof Error ? err.message : err);
    return json({ error: "INTERNAL_ERROR" }, 500);
  }
});
