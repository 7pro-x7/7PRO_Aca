# 7PRO release rules.
# Code shrinking is currently disabled (isMinifyEnabled = false); these rules are kept so that
# turning it on stays safe for the reflective parts of the stack: kotlinx.serialization models,
# Ktor engines and the Supabase client.

# --- kotlinx.serialization ---------------------------------------------------
-keepattributes *Annotation*, InnerClasses, Signature, RuntimeVisibleAnnotations, AnnotationDefault
-dontnote kotlinx.serialization.**

-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Every @Serializable model in the app keeps its generated serializer.
-if @kotlinx.serialization.Serializable class **
-keepclassmembers class <1> {
    static <1>$Companion Companion;
}
-if @kotlinx.serialization.Serializable class ** {
    static **$* *;
}
-keepclassmembers class <2>$<3> {
    kotlinx.serialization.KSerializer serializer(...);
}

-keep,includedescriptorclasses class com.rork.pro.data.**$$serializer { *; }
-keepclassmembers class com.rork.pro.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.rork.pro.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# --- Ktor / OkHttp -----------------------------------------------------------
-keepclassmembers class io.ktor.** { volatile <fields>; }
-dontwarn io.ktor.**
-dontwarn org.slf4j.**
-dontwarn okhttp3.**
-dontwarn okio.**

# --- Coroutines --------------------------------------------------------------
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
-dontwarn kotlinx.coroutines.**

# --- Supabase ----------------------------------------------------------------
-keep class io.github.jan.supabase.** { *; }
-dontwarn io.github.jan.supabase.**

# --- Compose -----------------------------------------------------------------
-dontwarn androidx.compose.**
