package com.rork.pro.ui.screens.test

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.rork.pro.data.AnswerResult
import com.rork.pro.data.AppError
import com.rork.pro.data.Async
import com.rork.pro.data.CatalogRepository
import com.rork.pro.data.NextQuestion
import com.rork.pro.data.PlacementTest
import com.rork.pro.data.Recommendations
import com.rork.pro.data.TestAttemptRow
import com.rork.pro.data.TestQuestionView
import com.rork.pro.data.TestRepository
import com.rork.pro.data.TestResult
import com.rork.pro.data.TeacherProfile
import com.rork.pro.data.toAppError
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.EmptyBlock
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.Avatar
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LessonVideo
import com.rork.pro.ui.components.LevelDial
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.Pill
import com.rork.pro.ui.components.PrimaryAction
import com.rork.pro.ui.components.QuestionAudio
import com.rork.pro.ui.components.QuestionImage
import com.rork.pro.ui.components.resolveLessonMedia
import com.rork.pro.ui.components.Refreshable
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.SkillBar
import com.rork.pro.ui.components.formatDate
import com.rork.pro.ui.components.formatMoney
import com.rork.pro.ui.components.levelName
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.navigation.Routes
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.rork.pro.ui.i18n.StrTest
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf
import com.rork.pro.ui.i18n.Str

// ---------------------------------------------------------------- Start

data class TestListData(
    val tests: List<PlacementTest>,
    val history: List<TestAttemptRow>,
    val teachers: List<TeacherProfile>,
)

class PlacementStartViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<TestListData>>(Async.Loading)
    val state: StateFlow<Async<TestListData>> = _state.asStateFlow()

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    private val _exercises = MutableStateFlow<List<PlacementTest>>(emptyList())
    val exercises: StateFlow<List<PlacementTest>> = _exercises.asStateFlow()

    private val _exerciseLoading = MutableStateFlow(false)
    val exerciseLoading: StateFlow<Boolean> = _exerciseLoading.asStateFlow()

    init { load() }

    fun refresh() {
        _refreshing.value = true
        load(quiet = true)
    }

    fun load(quiet: Boolean = false) {
        viewModelScope.launch {
            if (!quiet) _state.value = Async.Loading
            runCatching {
                TestListData(
                    CatalogRepository.publishedTests(),
                    TestRepository.history(),
                    CatalogRepository.exerciseTeachers(),
                )
            }.onSuccess { _state.value = Async.Success(it) }
                .onFailure { if (!quiet) _state.value = Async.Failure(it.toAppError()) }
            _refreshing.value = false
        }
    }

    fun loadExercises(teacherId: String?) {
        if (teacherId == null) {
            _exercises.value = emptyList()
            return
        }
        viewModelScope.launch {
            _exerciseLoading.value = true
            runCatching { CatalogRepository.publishedTeacherExercises(teacherId) }
                .onSuccess { _exercises.value = it }
            _exerciseLoading.value = false
        }
    }
}

@Composable
fun PlacementStartScreen(navController: NavHostController) {
    val vm: PlacementStartViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()
    val exercises by vm.exercises.collectAsStateWithLifecycle()
    val exerciseLoading by vm.exerciseLoading.collectAsStateWithLifecycle()
    var mode by remember { mutableStateOf("PLACEMENT") }
    var selectedTeacher by remember { mutableStateOf<TeacherProfile?>(null) }

    LaunchedEffect(selectedTeacher?.id) { vm.loadExercises(selectedTeacher?.id) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        DetailHeader(tr(StrTest.placementTest), onBack = { navController.popBackStack() })

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load() }
            is Async.Success -> Refreshable(refreshing, { vm.refresh() }) {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = Dimens.screenPadding, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(
                            tr(StrTest.placementTests),
                            Modifier.clickable { mode = "PLACEMENT" },
                            background = if (mode == "PLACEMENT") Ink.AmberSoft else Ink.SurfaceHigh,
                            foreground = if (mode == "PLACEMENT") Ink.Amber else Ink.TextMuted,
                        )
                        Pill(
                            tr(StrTest.teacherExercises),
                            Modifier.clickable { mode = "EXERCISES" },
                            background = if (mode == "EXERCISES") Ink.AmberSoft else Ink.SurfaceHigh,
                            foreground = if (mode == "EXERCISES") Ink.Amber else Ink.TextMuted,
                        )
                    }
                }

                if (mode == "PLACEMENT") {
                    item {
                        Text(
                            tr(StrTest.findYourLevel),
                            style = MaterialTheme.typography.headlineSmall,
                            color = Ink.TextPrimary,
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tr(StrTest.adaptiveIntro),
                            color = Ink.TextSecondary,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                    if (s.value.tests.isEmpty()) {
                        item { EmptyBlock(tr(StrTest.noTestPublished), tr(StrTest.noTestPublishedBody)) }
                    } else {
                        items(s.value.tests, key = { it.id }) { test ->
                            InkCard(borderColor = Ink.Amber.copy(alpha = 0.25f)) {
                                Text(test.title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleLarge)
                                if (!test.description.isNullOrBlank()) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(test.description, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                                }
                                Spacer(Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Pill(if (test.isAdaptive) tr(StrTest.adaptive) else tr(StrTest.fixed))
                                    Pill(
                                        trf(StrTest.questionsCount, test.questionCount),
                                        background = Color(0x1F8FA3BC),
                                        foreground = Ink.TextSecondary,
                                    )
                                    Pill(
                                        trf(StrTest.minutes, test.timeLimitSeconds / 60),
                                        background = Color(0x1F8FA3BC),
                                        foreground = Ink.TextSecondary,
                                    )
                                }
                                Spacer(Modifier.height(16.dp))
                                PrimaryAction(tr(StrTest.startFreeTest)) { navController.navigate(Routes.testRun(test.id)) }
                            }
                        }
                    }
                } else {
                    item {
                        Text(tr(StrTest.teacherExercises), color = Ink.TextPrimary, style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(tr(StrTest.teacherExercisesIntro), color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    }
                    if (s.value.teachers.isEmpty()) {
                        item { EmptyBlock(tr(StrTest.noTeachers), tr(StrTest.noExercisesBody)) }
                    } else {
                        item { SectionHeader(tr(StrTest.chooseTeacher)) }
                        items(s.value.teachers, key = { it.id }) { teacher ->
                            val name = teacher.profile?.fullName ?: tr(StrTest.chooseTeacher)
                            InkCard(
                                onClick = { selectedTeacher = teacher },
                                borderColor = if (selectedTeacher?.id == teacher.id) Ink.Amber else null,
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Avatar(teacher.profile?.avatarUrl, name, 44.dp)
                                    Column(Modifier.weight(1f)) {
                                        Text(name, color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                                        teacher.headline?.takeIf { it.isNotBlank() }?.let {
                                            Text(it, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                    if (selectedTeacher?.id == teacher.id) Pill(tr(StrTest.exercise))
                                }
                            }
                        }
                    }
                    if (selectedTeacher != null) {
                        if (exerciseLoading) {
                            item { LoadingBlock() }
                        } else if (exercises.isEmpty()) {
                            item { EmptyBlock(tr(StrTest.noExercises), tr(StrTest.noExercisesBody)) }
                        } else {
                            item { SectionHeader(tr(StrTest.teacherExercises)) }
                            items(exercises, key = { it.id }) { exercise ->
                                InkCard(borderColor = Ink.Amber.copy(alpha = 0.25f)) {
                                    Text(exercise.title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleLarge)
                                    exercise.description?.takeIf { it.isNotBlank() }?.let {
                                        Spacer(Modifier.height(6.dp))
                                        Text(it, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Pill(tr(StrTest.exercise))
                                        Pill(trf(StrTest.questionsCount, exercise.questionCount), background = Color(0x1F8FA3BC), foreground = Ink.TextSecondary)
                                        Pill(trf(StrTest.minutes, exercise.timeLimitSeconds / 60), background = Color(0x1F8FA3BC), foreground = Ink.TextSecondary)
                                    }
                                    Spacer(Modifier.height(16.dp))
                                    PrimaryAction(tr(StrTest.startExercise)) { navController.navigate(Routes.testRun(exercise.id)) }
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }
}

// ---------------------------------------------------------------- Runner

sealed interface RunnerState {
    data object Loading : RunnerState
    data class Question(val question: TestQuestionView, val index: Int, val total: Int) : RunnerState
    data class Finished(val attemptId: String) : RunnerState
    data class Failed(val error: AppError) : RunnerState
}

class PlacementRunnerViewModel : ViewModel() {
    private val _state = MutableStateFlow<RunnerState>(RunnerState.Loading)
    val state: StateFlow<RunnerState> = _state.asStateFlow()

    private val _feedback = MutableStateFlow<AnswerResult?>(null)
    val feedback: StateFlow<AnswerResult?> = _feedback.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    /** Seconds left on the server clock, re-synced on every question so it can never drift. */
    private val _secondsLeft = MutableStateFlow<Int?>(null)
    val secondsLeft: StateFlow<Int?> = _secondsLeft.asStateFlow()

    private val _timedOut = MutableStateFlow(false)
    val timedOut: StateFlow<Boolean> = _timedOut.asStateFlow()

    private var attemptId: String? = null
    private var ticker: Job? = null
    private var finishing: Boolean = false

    fun start(testId: String) {
        viewModelScope.launch {
            ticker?.cancel()
            finishing = false
            _timedOut.value = false
            _feedback.value = null
            _state.value = RunnerState.Loading
            runCatching {
                val attempt = TestRepository.start(testId)
                attemptId = attempt.attemptId
                _secondsLeft.value = attempt.secondsLeft ?: attempt.timeLimitSeconds.takeIf { it > 0 }
                TestRepository.next(attempt.attemptId)
            }.onSuccess { serve(it) }
                .onFailure { fail(it) }
        }
    }

    fun answer(questionId: String, selected: List<Int>, text: String?) {
        val attempt = attemptId ?: return
        viewModelScope.launch {
            _busy.value = true
            runCatching { TestRepository.answer(attempt, questionId, selected, text) }
                .onSuccess { _feedback.value = it }
                .onFailure { fail(it) }
            _busy.value = false
        }
    }

    fun advance() {
        val attempt = attemptId ?: return
        viewModelScope.launch {
            _feedback.value = null
            _busy.value = true
            runCatching { TestRepository.next(attempt) }
                .onSuccess { serve(it) }
                .onFailure { fail(it) }
            _busy.value = false
        }
    }

    /** Records a blank answer for a question that cannot be answered, so the run continues. */
    fun skip(questionId: String) {
        val attempt = attemptId ?: return
        viewModelScope.launch {
            _busy.value = true
            runCatching {
                TestRepository.answer(attempt, questionId, emptyList(), null)
                TestRepository.next(attempt)
            }.onSuccess {
                _feedback.value = null
                serve(it)
            }.onFailure { fail(it) }
            _busy.value = false
        }
    }

    private fun serve(next: NextQuestion) {
        next.secondsLeft?.let { _secondsLeft.value = it }
        if (next.done || next.question == null) {
            if (next.reason == "TIME_UP") _timedOut.value = true
            finishNow()
            return
        }
        _state.value = RunnerState.Question(next.question, next.index, next.total)
        startTicker()
    }

    /**
     * Drives the on-screen countdown. The server enforces the limit anyway; this makes the
     * deadline visible instead of ending the test without warning.
     */
    private fun startTicker() {
        if (ticker?.isActive == true) return
        if (_secondsLeft.value == null) return
        ticker = viewModelScope.launch {
            while (true) {
                delay(1_000)
                val left = _secondsLeft.value ?: return@launch
                if (left <= 1) {
                    _secondsLeft.value = 0
                    _timedOut.value = true
                    finishNow()
                    return@launch
                }
                _secondsLeft.value = left - 1
            }
        }
    }

    private fun finishNow() {
        val attempt = attemptId ?: return
        if (finishing) return
        finishing = true
        ticker?.cancel()
        _state.value = RunnerState.Loading
        viewModelScope.launch {
            runCatching { TestRepository.finish(attempt) }
                .onSuccess { _state.value = RunnerState.Finished(it.attemptId) }
                .onFailure {
                    finishing = false
                    fail(it)
                }
        }
    }

    private fun fail(error: Throwable) {
        ticker?.cancel()
        _state.value = RunnerState.Failed(error.toAppError())
    }

    override fun onCleared() {
        ticker?.cancel()
        super.onCleared()
    }
}

@Composable
fun PlacementRunnerScreen(navController: NavHostController, testId: String) {
    val vm: PlacementRunnerViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val feedback by vm.feedback.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val secondsLeft by vm.secondsLeft.collectAsStateWithLifecycle()
    val timedOut by vm.timedOut.collectAsStateWithLifecycle()

    var picked by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var typed by remember { mutableStateOf("") }

    LaunchedEffect(testId) { vm.start(testId) }

    // Keyed on the question, so a new question always starts from a clean answer sheet while
    // feedback for the current one never wipes what the learner just picked.
    val questionId = (state as? RunnerState.Question)?.question?.id
    LaunchedEffect(questionId) {
        picked = emptySet()
        typed = ""
    }

    LaunchedEffect(state) {
        val finished = state as? RunnerState.Finished ?: return@LaunchedEffect
        navController.navigate(Routes.testResult(finished.attemptId)) {
            popUpTo(Routes.TEST_START) { inclusive = true }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        DetailHeader(tr(StrTest.levelTest), onBack = { navController.popBackStack() })

        when (val s = state) {
            is RunnerState.Loading, is RunnerState.Finished -> LoadingBlock(
                Modifier.fillMaxSize(),
                if (timedOut) tr(StrTest.timeUpBody) else tr(StrTest.scoringAnswers),
            )
            is RunnerState.Failed -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.start(testId) }
            is RunnerState.Question -> {
                val multi = s.question.kind == "MULTI"
                val options: List<String> = when {
                    s.question.options.isNotEmpty() -> s.question.options
                    s.question.kind == "TRUE_FALSE" -> listOf(tr(StrTest.trueLabel), tr(StrTest.falseLabel))
                    else -> emptyList()
                }
                val answerable = s.question.kind == "TEXT" || options.isNotEmpty()
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(horizontal = Dimens.screenPadding)
                            .padding(bottom = 110.dp),
                    ) {
                        LinearProgressIndicator(
                            progress = { if (s.total > 0) s.index.toFloat() / s.total else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(999.dp)),
                            color = Ink.Amber,
                            trackColor = Ink.SurfaceHigh,
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                trf(StrTest.questionXofY, s.index, s.total),
                                color = Ink.TextMuted,
                                style = MaterialTheme.typography.bodySmall,
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                secondsLeft?.let { left ->
                                    Text(
                                        clockText(left),
                                        color = if (left <= 30) Ink.Coral else Ink.TextSecondary,
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                                Text(
                                    s.question.skill.lowercase().replaceFirstChar { it.uppercase() },
                                    color = Ink.Amber,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }

                        Spacer(Modifier.height(20.dp))

                        Text(
                            s.question.prompt,
                            color = Ink.TextPrimary,
                            style = MaterialTheme.typography.headlineSmall,
                        )

                        // Media is optional and dynamic: a question shows whatever the academy
                        // attached to it, and nothing at all when it attached none.
                        QuestionMediaBlock(s.question)

                        Spacer(Modifier.height(20.dp))

                        if (s.question.kind == "TEXT") {
                            com.rork.pro.ui.screens.auth.InkField(
                                typed,
                                { typed = it },
                                tr(StrTest.yourAnswer),
                                singleLine = false,
                                minLines = 2,
                            )
                        } else if (options.isNotEmpty()) {
                            if (multi) {
                                Text(
                                    tr(StrTest.chooseAllThatApply),
                                    color = Ink.TextMuted,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(bottom = 8.dp),
                                )
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                items(options.size) { index ->
                                    OptionRow(
                                        text = options[index],
                                        selected = index in picked,
                                        multi = multi,
                                        locked = feedback != null,
                                    ) {
                                        // Single-answer questions replace the choice; multi-answer
                                        // ones toggle it, which is why a MULTI question could never
                                        // be answered correctly before.
                                        picked = when {
                                            !multi -> setOf(index)
                                            index in picked -> picked - index
                                            else -> picked + index
                                        }
                                    }
                                }
                            }
                        } else {
                            EmptyBlock(
                                tr(StrTest.questionUnavailable),
                                tr(StrTest.questionUnavailableBody),
                            )
                        }

                        AnimatedVisibility(feedback != null) {
                            Column(Modifier.padding(top = 16.dp)) {
                                val graded = feedback?.graded != false
                                Text(
                                    when {
                                        !graded -> tr(StrTest.answerRecorded)
                                        feedback?.correct == true -> tr(StrTest.correct)
                                        else -> tr(StrTest.notQuite)
                                    },
                                    color = when {
                                        !graded -> Ink.TextSecondary
                                        feedback?.correct == true -> Ink.Teal
                                        else -> Ink.Coral
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                if (!feedback?.explanation.isNullOrBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        feedback?.explanation.orEmpty(),
                                        color = Ink.TextSecondary,
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                            }
                        }
                    }

                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Ink.Canvas)
                            .padding(horizontal = Dimens.screenPadding, vertical = 14.dp)
                            .navigationBarsPadding(),
                    ) {
                        if (feedback != null) {
                            PrimaryAction(tr(StrTest.nextQuestion), loading = busy) { vm.advance() }
                        } else if (!answerable) {
                            PrimaryAction(tr(StrTest.skipQuestion), loading = busy) { vm.skip(s.question.id) }
                        } else {
                            PrimaryAction(
                                tr(StrTest.submitAnswer),
                                enabled = if (s.question.kind == "TEXT") typed.isNotBlank() else picked.isNotEmpty(),
                                loading = busy,
                            ) {
                                vm.answer(
                                    s.question.id,
                                    picked.sorted(),
                                    typed.takeIf { s.question.kind == "TEXT" },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Image, audio and video attached to a placement question, in that order. */
@Composable
private fun QuestionMediaBlock(question: TestQuestionView) {
    val image = question.imageUrl?.trim().orEmpty()
    val audio = question.audioUrl?.trim().orEmpty()
    val video = question.videoUrl?.trim().orEmpty()
    if (image.isEmpty() && audio.isEmpty() && video.isEmpty()) return

    Column(Modifier.padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (image.isNotEmpty()) QuestionImage(image)
        if (audio.isNotEmpty()) QuestionAudio(audio)
        if (video.isNotEmpty()) LessonVideo(resolveLessonMedia(video))
    }
}

/** Whole seconds as m:ss, for the countdown chip. */
private fun clockText(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    return "${safe / 60}:${(safe % 60).toString().padStart(2, '0')}"
}

@Composable
private fun OptionRow(
    text: String,
    selected: Boolean,
    multi: Boolean,
    locked: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) Ink.AmberSoft else Ink.Surface)
            .border(1.dp, if (selected) Ink.Amber else Ink.Hairline, shape)
            .clickable(enabled = !locked, onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            when {
                selected -> Icons.Default.CheckCircle
                multi -> Icons.Default.CheckBoxOutlineBlank
                else -> Icons.Default.RadioButtonUnchecked
            },
            null,
            tint = if (selected) Ink.Amber else Ink.TextMuted,
            modifier = Modifier.size(20.dp),
        )
        Text(text, color = Ink.TextPrimary, style = MaterialTheme.typography.bodyLarge)
    }
}

// ---------------------------------------------------------------- Result

data class ResultData(val result: TestResult, val recommendations: Recommendations)

class PlacementResultViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<ResultData>>(Async.Loading)
    val state: StateFlow<Async<ResultData>> = _state.asStateFlow()

    /**
     * Reads the stored result. This screen used to call the closing routine, which meant
     * merely opening an old score could close a test the learner still had open.
     */
    fun load(attemptId: String) {
        viewModelScope.launch {
            _state.value = Async.Loading
            runCatching {
                val result = TestRepository.result(attemptId)
                ResultData(
                    result = result,
                    recommendations = result.level?.let { TestRepository.recommendations(it) }
                        ?: Recommendations(),
                )
            }.onSuccess { _state.value = Async.Success(it) }
                .onFailure { _state.value = Async.Failure(it.toAppError()) }
        }
    }
}

@Composable
fun PlacementResultScreen(navController: NavHostController, attemptId: String, session: SessionViewModel) {
    val vm: PlacementResultViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()

    LaunchedEffect(attemptId) {
        vm.load(attemptId)
        session.loadEverything()
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        DetailHeader(tr(StrTest.yourLevelResult), onBack = { navController.popBackStack() })

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load(attemptId) }
            // An attempt that ended with nothing answered has no level to show, so it gets an
            // honest explanation and a way back into the test instead of a fake 0% dial.
            is Async.Success -> if (s.value.result.level.isNullOrBlank() || s.value.result.answered == 0) {
                EmptyBlock(
                    tr(StrTest.notCompleted),
                    tr(StrTest.notCompletedBody),
                    Modifier.fillMaxSize(),
                    actionLabel = tr(StrTest.retakeTest),
                    onAction = {
                        navController.navigate(Routes.TEST_START) {
                            popUpTo(Routes.TEST_START) { inclusive = true }
                        }
                    },
                )
            } else {
                val data = s.value
                Box(Modifier.fillMaxSize()) {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 120.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        item {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                LevelDial(data.result.level ?: "—", data.result.percent)
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    levelName(data.result.level ?: "").substringAfter("· ").ifBlank {
                                        data.result.level ?: tr(StrTest.result)
                                    },
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = Ink.TextPrimary,
                                    textAlign = TextAlign.Center,
                                )
                                data.result.betterThanPercent?.let {
                                    Text(
                                        trf(StrTest.topPercentOfLearners, (100 - it).toInt()),
                                        color = Ink.Amber,
                                        style = MaterialTheme.typography.titleMedium,
                                    )
                                }
                            }
                        }

                        if (data.result.skills.isNotEmpty()) {
                            item {
                                InkCard(Modifier.padding(horizontal = Dimens.screenPadding)) {
                                    data.result.skills.entries.sortedByDescending { it.value }.forEach { (skill, value) ->
                                        SkillBar(
                                            skill.lowercase().replaceFirstChar { it.uppercase() },
                                            value,
                                            Modifier.padding(vertical = 6.dp),
                                        )
                                    }
                                }
                            }
                        }

                        item {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = Dimens.screenPadding),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                InsightCard(
                                    tr(StrTest.strengths),
                                    data.result.strengths.joinToString(", ") { it.lowercase().replaceFirstChar(Char::uppercase) },
                                    Ink.Teal,
                                    Modifier.weight(1f),
                                )
                                InsightCard(
                                    tr(StrTest.focus),
                                    data.result.weaknesses.joinToString(", ") { it.lowercase().replaceFirstChar(Char::uppercase) },
                                    Ink.Coral,
                                    Modifier.weight(1f),
                                )
                            }
                        }

                        if (data.recommendations.courses.isNotEmpty()) {
                            item {
                                SectionHeader(
                                    trf(StrTest.recommendedFor, data.result.level),
                                    Modifier.padding(horizontal = Dimens.screenPadding),
                                    actionLabel = tr(StrTest.seeAll),
                                    onAction = { navController.navigate(Routes.COURSES) },
                                )
                            }
                            item {
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = Dimens.screenPadding),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    items(data.recommendations.courses, key = { it.id }) { course ->
                                        InkCard(
                                            Modifier.width(210.dp),
                                            onClick = { navController.navigate(Routes.courseDetail(course.id)) },
                                        ) {
                                            Text(
                                                course.title,
                                                color = Ink.TextPrimary,
                                                style = MaterialTheme.typography.titleSmall,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            Spacer(Modifier.height(8.dp))
                                            Pill(
                                                if (course.isFreeCourse) tr(Str.free) else formatMoney(course.basePrice, course.baseCurrency),
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (data.recommendations.courses.isEmpty()) {
                            item {
                                EmptyBlock(
                                    tr(StrTest.noRecommendations),
                                    tr(StrTest.noRecommendationsBody),
                                )
                            }
                        }
                    }

                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Ink.Canvas)
                            .padding(horizontal = Dimens.screenPadding, vertical = 14.dp)
                            .navigationBarsPadding(),
                    ) {
                        PrimaryAction(tr(StrTest.browseCourses)) {
                            navController.navigate(Routes.COURSES)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightCard(title: String, body: String, accent: Color, modifier: Modifier = Modifier) {
    InkCard(modifier) {
        Text(title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            body.ifBlank { "—" },
            color = accent,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}
