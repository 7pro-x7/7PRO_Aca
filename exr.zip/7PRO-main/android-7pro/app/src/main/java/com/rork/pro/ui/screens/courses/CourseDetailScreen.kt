package com.rork.pro.ui.screens.courses

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.rork.pro.data.AppError
import com.rork.pro.data.Async
import com.rork.pro.data.CatalogRepository
import com.rork.pro.data.CommerceRepository
import com.rork.pro.data.Course
import com.rork.pro.data.CourseSection
import com.rork.pro.data.Enrollment
import com.rork.pro.data.LearningRepository
import com.rork.pro.data.Lesson
import com.rork.pro.data.PriceQuote
import com.rork.pro.data.Review
import com.rork.pro.data.toAppError
import com.rork.pro.ui.components.Avatar
import com.rork.pro.ui.components.CoverImage
import com.rork.pro.ui.components.Divider
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.KeyValueRow
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.Pill
import com.rork.pro.ui.components.PrimaryAction
import com.rork.pro.ui.components.RatingRow
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.formatDate
import com.rork.pro.ui.components.formatMoney
import com.rork.pro.ui.components.levelName
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.navigation.Routes
import com.rork.pro.ui.screens.payment.HostedCheckout
import com.rork.pro.ui.screens.payment.PaymentSheet
import com.rork.pro.ui.screens.payment.PaymentSummary
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.rork.pro.ui.i18n.Tr
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf
import com.rork.pro.ui.i18n.StrCourses
import com.rork.pro.ui.i18n.Str

private object CheckoutFailed {
    val phrase = Tr("Checkout could not be started.", "تعذّر بدء عملية الدفع.")
}

data class CourseDetailData(
    val course: Course,
    val lessons: List<Lesson>,
    val sections: List<CourseSection>,
    val enrollment: Enrollment?,
    val reviews: List<Review>,
    val quote: PriceQuote?,
    val quoteError: AppError?,
)

class CourseDetailViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<CourseDetailData>>(Async.Loading)
    val state: StateFlow<Async<CourseDetailData>> = _state.asStateFlow()

    private val _checkout = MutableStateFlow<CheckoutUiState>(CheckoutUiState.Idle)
    val checkout: StateFlow<CheckoutUiState> = _checkout.asStateFlow()

    fun load(courseId: String) {
        viewModelScope.launch {
            _state.value = Async.Loading
            runCatching {
                val course = CatalogRepository.course(courseId) ?: error("COURSE_NOT_AVAILABLE")
                val enrollment = LearningRepository.enrollment(courseId)
                var quote: PriceQuote? = null
                var quoteError: AppError? = null
                if (enrollment == null && !course.isFreeCourse) {
                    runCatching { CommerceRepository.quote("COURSE", courseId = courseId) }
                        .onSuccess { quote = it }
                        .onFailure { quoteError = it.toAppError() }
                }
                CatalogRepository.trackCourseView(courseId)
                CourseDetailData(
                    course = course,
                    lessons = CatalogRepository.lessons(courseId),
                    sections = CatalogRepository.courseSections(courseId),
                    enrollment = enrollment,
                    reviews = CatalogRepository.reviewsFor(courseId = courseId, limit = 5),
                    quote = quote,
                    quoteError = quoteError,
                )
            }.onSuccess { _state.value = Async.Success(it) }
                .onFailure { _state.value = Async.Failure(it.toAppError()) }
        }
    }

    fun buy(courseId: String, methodId: String? = null) {
        viewModelScope.launch {
            _checkout.value = CheckoutUiState.Working
            runCatching { CommerceRepository.startCheckout("COURSE", courseId = courseId, methodId = methodId) }
                .onSuccess { session ->
                    _checkout.value = when {
                        session.free -> CheckoutUiState.Granted
                        session.checkoutUrl != null -> CheckoutUiState.Redirect(session.checkoutUrl, session.orderId.orEmpty())
                        else -> CheckoutUiState.Error(AppError("CHECKOUT_FAILED", CheckoutFailed.phrase, true))
                    }
                }
                .onFailure { _checkout.value = CheckoutUiState.Error(it.toAppError()) }
        }
    }

    fun resetCheckout() {
        _checkout.value = CheckoutUiState.Idle
    }
}

sealed interface CheckoutUiState {
    data object Idle : CheckoutUiState
    data object Working : CheckoutUiState
    data class Redirect(val url: String, val orderId: String) : CheckoutUiState
    data object Granted : CheckoutUiState
    data class Error(val error: AppError) : CheckoutUiState
}

/**
 * Shows the gateway's payment page inside 7PRO and waits for the result.
 *
 * Access is only ever granted by the verified server-side webhook: this screen watches the
 * order until the server itself reports it paid, so a page that merely looks successful
 * unlocks nothing.
 */
@Composable
fun CheckoutLauncher(
    state: CheckoutUiState,
    onHandled: () -> Unit,
    onGranted: () -> Unit,
) {
    when (state) {
        is CheckoutUiState.Redirect -> HostedCheckout(state.url, state.orderId) { paid ->
            onHandled()
            if (paid) onGranted()
        }

        is CheckoutUiState.Granted -> LaunchedEffect(state) {
            onGranted()
            onHandled()
        }

        else -> Unit
    }
}

@Composable
fun CourseDetailScreen(navController: NavHostController, courseId: String) {
    val vm: CourseDetailViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val checkout by vm.checkout.collectAsStateWithLifecycle()

    // Set while the branded payment sheet is open, so the learner picks a method before paying.
    var paying by remember { mutableStateOf<PaymentSummary?>(null) }

    LaunchedEffect(courseId) { vm.load(courseId) }

    paying?.let { summary ->
        PaymentSheet(
            summary = summary,
            working = checkout is CheckoutUiState.Working,
            onDismiss = { paying = null },
            onPay = { methodId ->
                paying = null
                vm.buy(courseId, methodId)
            },
        )
    }

    CheckoutLauncher(
        state = checkout,
        onHandled = { vm.resetCheckout() },
        onGranted = {
            vm.load(courseId)
            navController.navigate(Routes.coursePlayer(courseId))
        },
    )

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        DetailHeader(tr(StrCourses.courseTitle), onBack = { navController.popBackStack() })

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load(courseId) }
            is Async.Success -> {
                val data = s.value
                Box(Modifier.fillMaxSize()) {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 130.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        item {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(210.dp),
                            ) {
                                CoverImage(data.course.thumbnailUrl, Modifier.fillMaxSize(), data.course.title)
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color.Transparent, Color(0xE00B1220)),
                                            ),
                                        ),
                                )
                            }
                        }

                        item {
                            Column(Modifier.padding(horizontal = Dimens.screenPadding)) {
                                Text(
                                    data.course.title,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = Ink.TextPrimary,
                                )
                                if (!data.course.subtitle.isNullOrBlank()) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        data.course.subtitle,
                                        color = Ink.TextSecondary,
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                                Spacer(Modifier.height(12.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    RatingRow(data.course.ratingAvg, data.course.ratingCount)
                                    data.course.level?.let { Pill(levelName(it)) }
                                    Pill(
                                        trf(StrCourses.learnersCount, data.course.enrollmentsCount),
                                        background = Color(0x1F8FA3BC),
                                        foreground = Ink.TextSecondary,
                                    )
                                }
                            }
                        }

                        item {
                            InkCard(Modifier.padding(horizontal = Dimens.screenPadding)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    Avatar(data.course.teacher?.avatarUrl, data.course.teacher?.fullName, 46.dp)
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            data.course.teacher?.fullName ?: tr(StrCourses.sevenProTeacher),
                                            color = Ink.TextPrimary,
                                            style = MaterialTheme.typography.titleMedium,
                                        )
                                    }
                                }
                            }
                        }

                        if (!data.course.description.isNullOrBlank()) {
                            item {
                                Column(Modifier.padding(horizontal = Dimens.screenPadding)) {
                                    SectionHeader(tr(StrCourses.aboutThisCourse))
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        data.course.description,
                                        color = Ink.TextSecondary,
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                }
                            }
                        }

                        item {
                            SectionHeader(
                                trf(StrCourses.lessonsCount, data.lessons.size),
                                Modifier.padding(horizontal = Dimens.screenPadding),
                            )
                        }

                        groupLessons(data.sections, data.lessons).forEach { group ->
                            group.section?.let { section ->
                                item(key = "section-${section.id}") {
                                    Text(
                                        section.title,
                                        color = Ink.Amber,
                                        style = MaterialTheme.typography.titleSmall,
                                        modifier = Modifier.padding(
                                            start = Dimens.screenPadding,
                                            end = Dimens.screenPadding,
                                            top = 6.dp,
                                        ),
                                    )
                                }
                            }
                            items(group.lessons, key = { it.id }) { lesson ->
                                LessonRow(
                                    lesson = lesson,
                                    unlocked = data.enrollment != null || lesson.isPreview || data.course.isFreeCourse,
                                    modifier = Modifier.padding(horizontal = Dimens.screenPadding),
                                ) {
                                    if (data.enrollment != null || lesson.isPreview || data.course.isFreeCourse) {
                                        navController.navigate(Routes.coursePlayer(courseId))
                                    }
                                }
                            }
                        }

                        if (data.reviews.isNotEmpty()) {
                            item {
                                SectionHeader(tr(StrCourses.verifiedReviews), Modifier.padding(horizontal = Dimens.screenPadding))
                            }
                            items(data.reviews, key = { it.id }) { review ->
                                ReviewRow(review, Modifier.padding(horizontal = Dimens.screenPadding))
                            }
                        }
                    }

                    BuyBar(
                        data = data,
                        working = checkout is CheckoutUiState.Working,
                        modifier = Modifier.align(Alignment.BottomCenter),
                        onOpen = { navController.navigate(Routes.coursePlayer(courseId)) },
                        onBuy = {
                            val quote = data.quote
                            // Free courses are granted straight away; paid ones go through the sheet.
                            if (data.course.isFreeCourse || quote == null) {
                                vm.buy(courseId)
                            } else {
                                paying = PaymentSummary(
                                    title = data.course.title,
                                    listPrice = quote.listPrice,
                                    discount = quote.discountAmount,
                                    total = quote.totalAmount,
                                    currency = quote.currency,
                                )
                            }
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun BuyBar(
    data: CourseDetailData,
    working: Boolean,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
    onBuy: () -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Ink.Canvas, Ink.Canvas)))
            .padding(horizontal = Dimens.screenPadding, vertical = 14.dp)
            .navigationBarsPadding(),
    ) {
        when {
            data.enrollment != null -> {
                Text(
                    trf(StrCourses.youOwnThisCourse, data.enrollment.progressPercent.toInt()),
                    color = Ink.Teal,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                PrimaryAction(if (data.enrollment.progressPercent > 0) tr(StrCourses.continueLearning) else tr(StrCourses.startLearning), onClick = onOpen)
            }
            data.course.isFreeCourse -> PrimaryAction(tr(StrCourses.startForFree), loading = working, onClick = onBuy)
            data.quoteError != null -> {
                Text(
                    data.quoteError.message,
                    color = Ink.Coral,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                PrimaryAction(tr(Str.retry), loading = working, onClick = onBuy)
            }
            data.quote != null -> {
                val quote = data.quote
                if (quote.discountAmount > 0) {
                    Text(
                        "${formatMoney(quote.listPrice, quote.currency)} → ${formatMoney(quote.totalAmount, quote.currency)}",
                        color = Ink.Teal,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                } else {
                    Text(
                        trf(StrCourses.countryPricingSecure, quote.countryCode),
                        color = Ink.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp),
                    )
                }
                PrimaryAction(
                    trf(StrCourses.buyFor, formatMoney(quote.totalAmount, quote.currency)),
                    loading = working,
                    onClick = onBuy,
                )
            }
            else -> PrimaryAction(tr(StrCourses.enroll), loading = working, onClick = onBuy)
        }
    }
}

@Composable
private fun LessonRow(lesson: Lesson, unlocked: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    InkCard(modifier = modifier, onClick = onClick, contentPadding = PaddingValues(13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (unlocked) Ink.AmberSoft else Ink.SurfaceHigh),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    when {
                        !unlocked -> Icons.Default.Lock
                        lesson.kind == "QUIZ" -> Icons.Default.Quiz
                        lesson.kind == "DOCUMENT" -> Icons.Default.Description
                        else -> Icons.Default.PlayArrow
                    },
                    null,
                    tint = if (unlocked) Ink.Amber else Ink.TextMuted,
                    modifier = Modifier.size(19.dp),
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    lesson.title,
                    color = Ink.TextPrimary,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    buildString {
                        append(lesson.kind.lowercase().replaceFirstChar { it.uppercase() })
                        if (lesson.durationSeconds > 0) append(" · " + trf(StrCourses.minutes, lesson.durationSeconds / 60))
                        if (lesson.isPreview) append(tr(StrCourses.freePreview))
                    },
                    color = Ink.TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
fun ReviewRow(review: Review, modifier: Modifier = Modifier) {
    InkCard(modifier = modifier, contentPadding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Avatar(review.author?.avatarUrl, review.author?.fullName, 32.dp)
            Column(Modifier.weight(1f)) {
                Text(
                    review.author?.fullName ?: tr(StrCourses.verifiedStudent),
                    color = Ink.TextPrimary,
                    style = MaterialTheme.typography.titleSmall,
                )
                Text(formatDate(review.createdAt), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            Pill("★ ${review.rating}")
        }
        if (!review.body.isNullOrBlank()) {
            Spacer(Modifier.height(9.dp))
            Text(review.body, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

/** A curriculum section together with the lessons filed under it. */
data class LessonGroup(val section: CourseSection?, val lessons: List<Lesson>)

/**
 * Groups a course's lessons by section for display.
 *
 * Courses created before sections existed — or that simply never used them — return a single
 * unlabelled group, so the list looks exactly as it always did.
 */
fun groupLessons(sections: List<CourseSection>, lessons: List<Lesson>): List<LessonGroup> {
    if (sections.isEmpty()) return listOf(LessonGroup(null, lessons))
    return buildList {
        sections.forEach { section ->
            val inSection = lessons.filter { it.sectionId == section.id }
            if (inSection.isNotEmpty()) add(LessonGroup(section, inSection))
        }
        val loose = lessons.filter { it.sectionId == null }
        if (loose.isNotEmpty()) add(LessonGroup(null, loose))
    }
}
