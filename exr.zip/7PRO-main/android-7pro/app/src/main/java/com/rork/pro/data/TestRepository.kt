package com.rork.pro.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Adaptive placement test flow. Grading and level mapping happen entirely server-side. */
object TestRepository {

    suspend fun start(testId: String): StartAttempt =
        Backend.rpc("start_test_attempt", buildJsonObject { put("p_test_id", testId) })

    suspend fun next(attemptId: String): NextQuestion =
        Backend.rpc("next_test_question", buildJsonObject { put("p_attempt_id", attemptId) })

    /**
     * Records one answer and gets it graded on the server.
     *
     * Every parameter is always sent, including the empty ones: PostgREST picks a function by its
     * exact argument list, so leaving `p_text` or `p_order` out made the whole call fail with
     * "function not found" — which is why answers were never scored.
     */
    suspend fun answer(
        attemptId: String,
        questionId: String,
        selected: List<Int> = emptyList(),
        text: String? = null,
        order: List<Int>? = null,
    ): AnswerResult =
        Backend.rpc(
            "submit_test_answer",
            buildJsonObject {
                put("p_attempt_id", attemptId)
                put("p_question_id", questionId)
                put("p_selected", JsonArray(selected.map { JsonPrimitive(it) }))
                put("p_text", text)
                put("p_order", order?.let { o -> JsonArray(o.map { JsonPrimitive(it) }) } ?: JsonNull)
                put("p_match", buildJsonObject { })
            },
        )

    suspend fun finish(attemptId: String): TestResult =
        Backend.rpc("finish_test_attempt", buildJsonObject { put("p_attempt_id", attemptId) })

    /**
     * Reads a stored result without touching it.
     *
     * Opening a past result used to call [finish], which is a write: a test the learner had
     * left open was closed just by looking at an old score.
     */
    suspend fun result(attemptId: String): TestResult =
        Backend.rpc("test_attempt_result", buildJsonObject { put("p_attempt_id", attemptId) })

    suspend fun recommendations(level: String): Recommendations =
        Backend.rpc("recommendations_for_level", buildJsonObject { put("p_level", level) })

    suspend fun latestResult(): TestAttemptRow? {
        val userId = Backend.currentUserId ?: return null
        return Backend.client.from("test_attempts")
            .select {
                filter {
                    eq("user_id", userId)
                    eq("status", "SUBMITTED")
                }
                order("submitted_at", Order.DESCENDING)
                limit(1)
            }
            .decodeList<TestAttemptRow>()
            .firstOrNull()
    }

    suspend fun history(): List<TestAttemptRow> {
        val userId = Backend.currentUserId ?: return emptyList()
        return Backend.client.from("test_attempts")
            .select {
                filter {
                    eq("user_id", userId)
                    eq("status", "SUBMITTED")
                }
                order("submitted_at", Order.DESCENDING)
                limit(20)
            }
            .decodeList()
    }
}
