package com.rork.pro.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.rork.pro.data.AppError
import com.rork.pro.ui.i18n.AppLanguage
import com.rork.pro.ui.i18n.Str
import com.rork.pro.ui.i18n.levelLabel
import com.rork.pro.ui.i18n.statusLabel
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = Ink.TextPrimary)
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction, contentPadding = PaddingValues(horizontal = 6.dp)) {
                Text(actionLabel, color = Ink.Amber, style = MaterialTheme.typography.titleSmall)
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Ink.Amber, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun Eyebrow(text: String, modifier: Modifier = Modifier, color: Color = Ink.TextSecondary) {
    Text(
        text.uppercase(),
        modifier = modifier,
        style = MaterialTheme.typography.labelSmall,
        color = color,
    )
}

@Composable
fun InkCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    color: Color = Ink.Surface,
    borderColor: Color? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(Dimens.cardRadius)
    val base = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(color)
        .then(if (borderColor != null) Modifier.border(1.dp, borderColor, shape) else Modifier)
    Column(
        modifier = if (onClick != null) base.clickable(onClick = onClick) else base,
        content = {
            Column(Modifier.padding(contentPadding), content = content)
        },
    )
}

/** Amber pill used for levels, prices and status. */
@Composable
fun Pill(
    text: String,
    modifier: Modifier = Modifier,
    background: Color = Ink.AmberSoft,
    foreground: Color = Ink.Amber,
    bold: Boolean = true,
) {
    Text(
        text,
        modifier = modifier
            .clip(RoundedCornerShape(Dimens.chipRadius))
            .background(background)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        color = foreground,
        style = MaterialTheme.typography.bodySmall.copy(fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium),
        maxLines = 1,
    )
}

@Composable
fun LevelBadge(level: String?, modifier: Modifier = Modifier) {
    if (level.isNullOrBlank()) return
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(Dimens.chipRadius))
            .border(1.dp, Ink.Amber.copy(alpha = 0.55f), RoundedCornerShape(Dimens.chipRadius))
            .background(Ink.AmberSoft)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Box(
            Modifier
                .size(20.dp)
                .clip(CircleShape)
                .border(1.dp, Ink.Amber, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(level.take(2), color = Ink.Amber, fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
        Text(levelName(level), color = Ink.Amber, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
    }
}

fun levelName(level: String): String = levelLabel(level).ifBlank { level }

@Composable
fun RatingRow(rating: Double, count: Int, modifier: Modifier = Modifier) {
    if (count <= 0) {
        Text(tr(Str.new), modifier = modifier, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
        return
    }
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            String.format(java.util.Locale.US, "%.1f", rating),
            color = Ink.Amber,
            style = MaterialTheme.typography.titleSmall,
        )
        Icon(Icons.Default.Star, null, tint = Ink.Amber, modifier = Modifier.size(14.dp))
        Text("($count)", color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
    }
}

/** Primary amber action with a subtle press-scale. */
@Composable
fun PrimaryAction(
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    onClick: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.975f else 1f, tween(110), label = "press")
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .scale(scale),
        enabled = enabled && !loading,
        interactionSource = interaction,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Ink.Amber,
            contentColor = Ink.OnAmber,
            disabledContainerColor = Ink.SurfaceHigh,
            disabledContentColor = Ink.TextMuted,
        ),
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = Ink.OnAmber,
            )
        } else {
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun SecondaryAction(
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    tint: Color = Ink.TextPrimary,
    onClick: () -> Unit,
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(50.dp),
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (tint == Ink.TextPrimary) Ink.Hairline else tint.copy(alpha = 0.45f),
        ),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tint),
    ) {
        Text(label, style = MaterialTheme.typography.titleSmall)
    }
}

/**
 * Asks before an action that cannot be undone.
 *
 * Destructive choices are tinted coral and never made the default, so the safe way out is
 * always the easiest one to hit.
 */
@Composable
fun ConfirmDialog(
    title: String,
    body: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    destructive: Boolean = false,
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ink.Surface,
        titleContentColor = Ink.TextPrimary,
        textContentColor = Ink.TextSecondary,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { Text(body, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onConfirm) {
                Text(confirmLabel, color = if (destructive) Ink.Coral else Ink.Amber)
            }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text(tr(Str.cancel), color = Ink.TextSecondary)
            }
        },
    )
}

@Composable
fun LoadingBlock(modifier: Modifier = Modifier, label: String = tr(Str.loading)) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        CircularProgressIndicator(color = Ink.Amber, strokeWidth = 2.5.dp, modifier = Modifier.size(30.dp))
        Text(label, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun ErrorBlock(error: AppError, modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = Dimens.screenPadding, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            if (error.code == "OFFLINE") Icons.Default.CloudOff else Icons.Default.ErrorOutline,
            null,
            tint = if (error.code == "OFFLINE") Ink.Sky else Ink.Coral,
            modifier = Modifier.size(34.dp),
        )
        Text(
            error.message,
            color = Ink.TextSecondary,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        if (onRetry != null && error.retryable) {
            SecondaryAction(tr(Str.retry), onClick = onRetry)
        }
    }
}

@Composable
fun EmptyBlock(
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = Dimens.screenPadding, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
        Text(
            body,
            color = Ink.TextMuted,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(4.dp))
            SecondaryAction(actionLabel, onClick = onAction)
        }
    }
}

@Composable
fun CoverImage(
    url: String?,
    modifier: Modifier = Modifier,
    fallbackLabel: String = "",
) {
    Box(modifier.background(Ink.SurfaceHigh), contentAlignment = Alignment.Center) {
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = url,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            )
        } else if (fallbackLabel.isNotBlank()) {
            Text(
                fallbackLabel.take(2).uppercase(),
                color = Ink.Amber.copy(alpha = 0.7f),
                style = MaterialTheme.typography.titleLarge,
            )
        }
    }
}

@Composable
fun Avatar(url: String?, name: String?, size: androidx.compose.ui.unit.Dp = 34.dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Ink.SurfaceHigh),
        contentAlignment = Alignment.Center,
    ) {
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = url,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            )
        } else {
            Text(
                (name ?: "?").trim().take(1).uppercase(),
                color = Ink.Amber,
                style = MaterialTheme.typography.titleSmall,
            )
        }
    }
}

/** Animated horizontal skill/progress bar. */
@Composable
fun SkillBar(
    label: String,
    percent: Double,
    modifier: Modifier = Modifier,
    color: Color = Ink.Amber,
) {
    val animated by animateFloatAsState(
        targetValue = (percent / 100.0).toFloat().coerceIn(0f, 1f),
        animationSpec = tween(720),
        label = "skill",
    )
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            color = Ink.TextPrimary,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.width(104.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Box(
            Modifier
                .weight(1f)
                .height(9.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(Ink.SurfaceHigh),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(animated)
                    .height(9.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.75f), color))),
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            "${percent.toInt()}%",
            color = Ink.TextSecondary,
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.width(44.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.End,
        )
    }
}

/** Big amber dial used for the placement level result. */
@Composable
fun LevelDial(level: String, percent: Double, modifier: Modifier = Modifier) {
    val sweep by animateFloatAsState(
        targetValue = (percent / 100.0).toFloat().coerceIn(0.04f, 1f),
        animationSpec = tween(1100),
        label = "dial",
    )
    Box(modifier.size(200.dp), contentAlignment = Alignment.Center) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            drawArc(
                color = Ink.SurfaceHigh,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(Ink.AmberPressed, Ink.Amber, Color(0xFFFFD27A), Ink.Amber)),
                startAngle = -90f,
                sweepAngle = 360f * sweep,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(level, color = Ink.Amber, fontSize = 60.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun StatTile(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    accent: Color = Ink.TextPrimary,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = accent, style = MaterialTheme.typography.titleLarge, maxLines = 1)
        Text(label, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
    }
}

@Composable
fun KeyValueRow(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Ink.TextPrimary) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        Text(
            value,
            color = valueColor,
            style = MaterialTheme.typography.titleSmall,
            textAlign = androidx.compose.ui.text.style.TextAlign.End,
            modifier = Modifier.padding(start = 12.dp),
        )
    }
}

@Composable
fun StatusPill(status: String, modifier: Modifier = Modifier) {
    val (bg, fg) = when (status.uppercase()) {
        "ACTIVE", "PUBLISHED", "APPROVED", "PAID", "AVAILABLE", "AVAILABLE_BALANCE" -> Ink.TealSoft to Ink.Teal
        "PENDING", "PENDING_REVIEW", "DUE_SOON", "EXPIRING", "OFFERED", "WAITING" -> Ink.AmberSoft to Ink.Amber
        "REJECTED", "FAILED", "SUSPENDED", "OVERDUE", "EXPIRED", "CANCELLED", "CHARGEBACK", "REFUNDED" -> Ink.CoralSoft to Ink.Coral
        "DRAFT", "ARCHIVED" -> Color(0x1F8FA3BC) to Ink.TextSecondary
        else -> Ink.SkySoft to Ink.Sky
    }
    Pill(statusLabel(status), modifier, background = bg, foreground = fg)
}

@Composable
fun Divider(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Ink.Hairline),
    )
}

@Composable
fun animatedAccent(active: Boolean): Color {
    val color by animateColorAsState(if (active) Ink.Amber else Ink.TextMuted, label = "accent")
    return color
}

fun formatMoney(amount: Double, currency: String): String {
    val rounded = if (amount % 1.0 == 0.0) {
        String.format(java.util.Locale.US, "%,.0f", amount)
    } else {
        String.format(java.util.Locale.US, "%,.2f", amount)
    }
    return "$rounded $currency"
}

fun formatDate(iso: String?): String {
    if (iso.isNullOrBlank()) return "—"
    return runCatching {
        val instant = if (iso.length <= 10) {
            java.time.LocalDate.parse(iso).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant()
        } else {
            java.time.Instant.parse(iso.replace(" ", "T").let { if (it.endsWith("Z")) it else it + "Z" })
        }
        java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy", AppLanguage.locale())
            .withZone(java.time.ZoneId.systemDefault())
            .format(instant)
    }.getOrElse { iso.take(10) }
}

/**
 * Wraps a screen's content in pull-to-refresh.
 *
 * The refresh keeps whatever is already on screen and only swaps in newer data when it arrives,
 * so a swipe never blanks the page the way a full reload does.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun Refreshable(
    refreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    androidx.compose.material3.pulltorefresh.PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = onRefresh,
        modifier = modifier.fillMaxSize(),
        indicator = {
            androidx.compose.material3.pulltorefresh.PullToRefreshDefaults.Indicator(
                state = androidx.compose.material3.pulltorefresh.rememberPullToRefreshState(),
                isRefreshing = refreshing,
                modifier = Modifier.align(Alignment.TopCenter),
                containerColor = Ink.Surface,
                color = Ink.Amber,
            )
        },
    ) { content() }
}
