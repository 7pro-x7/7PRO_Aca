package com.rork.pro.ui.screens.admin

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.rork.pro.BuildConfig
import com.rork.pro.data.AdmobPlacement
import com.rork.pro.data.AdminRepository
import com.rork.pro.data.AppError
import com.rork.pro.data.AppSetting
import com.rork.pro.data.Async
import com.rork.pro.data.AuditLog
import com.rork.pro.data.Banner
import com.rork.pro.data.Coupon
import com.rork.pro.data.Course
import com.rork.pro.data.CountryPricing
import com.rork.pro.data.Order
import com.rork.pro.data.Payout
import com.rork.pro.data.PlacementTest
import com.rork.pro.data.Profile
import com.rork.pro.data.RefundRow
import com.rork.pro.data.Review
import com.rork.pro.data.SupportTicket
import com.rork.pro.data.TeacherProfile
import com.rork.pro.data.UpdateKeys
import com.rork.pro.data.toAppError
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.Avatar
import com.rork.pro.ui.components.ConfirmDialog
import com.rork.pro.ui.components.Divider
import com.rork.pro.ui.components.EmptyBlock
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.KeyValueRow
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.Pill
import com.rork.pro.ui.components.PrimaryAction
import com.rork.pro.ui.components.Refreshable
import com.rork.pro.ui.components.SecondaryAction
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.StatusPill
import com.rork.pro.ui.components.formatDate
import com.rork.pro.ui.components.formatMoney
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.screens.auth.InkField
import com.rork.pro.ui.screens.test.TestMediaField
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import com.rork.pro.ui.i18n.StrAdmin
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf
import com.rork.pro.ui.i18n.Str
import com.rork.pro.ui.i18n.StrTeacher
import com.rork.pro.ui.i18n.statusLabel
import com.rork.pro.ui.i18n.codeLabel

/** Generic list + action view model used by the admin screens. */
open class AdminListViewModel<T>(private val loader: suspend () -> T) : ViewModel() {
    private val _state = MutableStateFlow<Async<T>>(Async.Loading)
    val state: StateFlow<Async<T>> = _state.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _error = MutableStateFlow<AppError?>(null)
    val error: StateFlow<AppError?> = _error.asStateFlow()

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    init { load() }

    /** Pull-to-refresh: fetches again while leaving the current list on screen. */
    fun refresh() {
        _refreshing.value = true
        load(quiet = true)
    }

    fun load(quiet: Boolean = false) {
        viewModelScope.launch {
            if (!quiet) _state.value = Async.Loading
            runCatching { loader() }
                .onSuccess { _state.value = Async.Success(it) }
                .onFailure { if (!quiet) _state.value = Async.Failure(it.toAppError()) }
            _refreshing.value = false
        }
    }

    fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            runCatching { block() }.onFailure { _error.value = it.toAppError() }
            _busy.value = false
            load()
        }
    }

    fun clearError() { _error.value = null }
}

@Composable
private fun <T> AdminScaffold(
    title: String,
    navController: NavHostController,
    vm: AdminListViewModel<T>,
    content: androidx.compose.foundation.lazy.LazyListScope.(T) -> Unit,
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding(),
    ) {
        DetailHeader(title, onBack = { navController.popBackStack() })

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load() }
            is Async.Success -> Refreshable(refreshing, { vm.refresh() }) {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = Dimens.screenPadding, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    error?.let { err ->
                        item {
                            InkCard(borderColor = Ink.Coral.copy(alpha = 0.4f)) {
                                Text(err.message, color = Ink.Coral, style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.height(8.dp))
                                SecondaryAction(tr(StrAdmin.dismiss)) { vm.clearError() }
                            }
                        }
                    }
                    content(s.value)
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Ink.Canvas,
                checkedTrackColor = Ink.Amber,
                uncheckedThumbColor = Ink.TextMuted,
                uncheckedTrackColor = Ink.SurfaceHigh,
            ),
        )
    }
}

// ---------------------------------------------------------------- Teachers

class TeachersVm : AdminListViewModel<List<TeacherProfile>>({ AdminRepository.teachers() })

class MemberSearchVm : ViewModel() {
    private val _results = MutableStateFlow<List<Profile>>(emptyList())
    val results: StateFlow<List<Profile>> = _results.asStateFlow()

    fun search(query: String) {
        viewModelScope.launch {
            if (query.isBlank()) {
                _results.value = emptyList()
                return@launch
            }
            runCatching { AdminRepository.users(search = query) }
                .onSuccess { found -> _results.value = found.filter { it.role == "STUDENT" }.take(6) }
        }
    }
}

/**
 * The only door into a teaching account.
 *
 * Members sign up as learners; the owner (or an admin with teacher rights) picks one, sets the
 * share they keep, and the server promotes the account in a single audited step.
 */
@Composable
private fun NewTeacherCard(onCreate: (String, String, Double?) -> Unit) {
    val search: MemberSearchVm = viewModel()
    val results by search.results.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<Profile?>(null) }
    var headline by remember { mutableStateOf("") }
    var share by remember { mutableStateOf("") }

    InkCard(borderColor = Ink.Amber.copy(alpha = 0.25f)) {
        Text(tr(StrAdmin.newTeacher), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(tr(StrAdmin.newTeacherPolicy), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        InkField(
            query,
            {
                query = it
                picked = null
                search.search(it)
            },
            tr(StrAdmin.searchMember),
        )

        if (picked == null && query.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            if (results.isEmpty()) {
                Text(tr(StrAdmin.noMatches), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
            } else {
                results.forEach { member ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                picked = member
                                query = member.displayName
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Avatar(member.avatarUrl, member.displayName, 32.dp)
                        Column {
                            Text(member.displayName, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                            Text(member.email.orEmpty(), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        picked?.let { member ->
            Spacer(Modifier.height(10.dp))
            InkField(headline, { headline = it }, tr(StrAdmin.headline))
            Spacer(Modifier.height(8.dp))
            InkField(
                share,
                { share = it.filter(Char::isDigit).take(3) },
                tr(StrAdmin.teacherSharePct),
                keyboardType = KeyboardType.Number,
            )
            Spacer(Modifier.height(14.dp))
            PrimaryAction(tr(StrAdmin.makeTeacher)) {
                val keptByTeacher = share.toIntOrNull()?.coerceIn(0, 100)
                onCreate(member.id, headline, keptByTeacher?.let { it / 100.0 })
                query = ""; headline = ""; share = ""; picked = null
            }
        }
    }
}

@Composable
fun AdminTeachersScreen(navController: NavHostController, session: SessionViewModel) {
    val vm: TeachersVm = viewModel()
    val sessionState by session.state.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf<TeacherProfile?>(null) }

    confirmDelete?.let { teacher ->
        ConfirmDialog(
            title = tr(StrAdmin.deleteTeacher),
            body = tr(StrAdmin.deleteTeacherConfirm),
            confirmLabel = tr(StrAdmin.deleteTeacher),
            destructive = true,
            onDismiss = { confirmDelete = null },
            onConfirm = {
                vm.act { AdminRepository.manageTeacher(teacher.id, "DELETE") }
                confirmDelete = null
            },
        )
    }

    AdminScaffold(tr(StrAdmin.teachers), navController, vm) { teachers ->
        item {
            NewTeacherCard { userId, headline, commission ->
                vm.act { AdminRepository.createTeacher(userId, headline, commission) }
            }
        }
        item {
            Text(
                tr(StrAdmin.teachersPolicy),
                color = Ink.TextMuted,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        if (teachers.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noTeachers), tr(StrAdmin.noTeachersBody)) }
        }
        items(teachers, key = { it.id }) { teacher ->
            var commission by remember(teacher.id) {
                mutableStateOf(teacher.commissionRate?.let { (it * 100).toInt().toString() } ?: "")
            }
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Avatar(teacher.photoUrl ?: teacher.profile?.avatarUrl, teacher.profile?.fullName, 38.dp)
                        Column {
                            Text(
                                teacher.profile?.fullName ?: tr(StrAdmin.teacherLabel),
                                color = Ink.TextPrimary,
                                style = MaterialTheme.typography.titleSmall,
                            )
                            Text(
                                trf(StrAdmin.studentsCount, teacher.studentsCount),
                                color = Ink.TextMuted,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                    StatusPill(teacher.status)
                }
                Spacer(Modifier.height(10.dp))
                ToggleRow(tr(StrAdmin.openForNewStudents), teacher.acceptingNewStudents) { value ->
                    vm.act { AdminRepository.setTeacherFlags(teacher.id, value, null, null, null) }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) {
                        InkField(
                            commission,
                            { commission = it.filter(Char::isDigit).take(3) },
                            tr(StrAdmin.teacherSharePct),
                            keyboardType = KeyboardType.Number,
                        )
                    }
                    SecondaryAction(tr(StrAdmin.save)) {
                        val value = commission.toIntOrNull()?.coerceIn(0, 100)?.div(100.0)
                        vm.act { AdminRepository.setTeacherFlags(teacher.id, null, null, null, value) }
                    }
                }

                // A suspended teacher is either brought back or removed — the owner decides.
                if (teacher.status == "SUSPENDED" && sessionState.isOwner) {
                    Spacer(Modifier.height(12.dp))
                    Divider()
                    Spacer(Modifier.height(10.dp))
                    Text(
                        tr(StrAdmin.suspendedTeacherNote),
                        color = Ink.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SecondaryAction(tr(StrAdmin.reactivateTeacher), Modifier.weight(1f)) {
                            vm.act { AdminRepository.manageTeacher(teacher.id, "REACTIVATE") }
                        }
                        SecondaryAction(
                            tr(StrAdmin.deleteTeacher),
                            Modifier.weight(1f),
                            tint = Ink.Coral,
                        ) { confirmDelete = teacher }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Content review

class ReviewVm : AdminListViewModel<List<Course>>({ AdminRepository.coursesForReview(null) })

@Composable
fun AdminReviewScreen(navController: NavHostController) {
    val vm: ReviewVm = viewModel()
    var note by remember { mutableStateOf("") }

    AdminScaffold(tr(StrAdmin.contentReview), navController, vm) { courses ->
        if (courses.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noCourses), tr(StrAdmin.noCoursesBody)) }
        }
        items(courses, key = { "c-${it.id}" }) { course ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        course.title,
                        color = Ink.TextPrimary,
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f),
                    )
                    StatusPill(course.status)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "${course.teacher?.fullName ?: tr(StrAdmin.teacherLabel)} · " +
                        if (course.isFreeCourse) tr(Str.free) else formatMoney(course.basePrice, course.baseCurrency),
                    color = Ink.TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(12.dp))
                ToggleRow(tr(StrAdmin.featuredOnHome), course.isFeatured) { value ->
                    vm.act { AdminRepository.setCourseFeatured(course.id, value) }
                }
                Spacer(Modifier.height(8.dp))
                if (course.status == "PENDING_REVIEW") {
                    InkField(note, { note = it }, tr(StrAdmin.reviewNote))
                    Spacer(Modifier.height(10.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (course.status) {
                        "PENDING_REVIEW", "APPROVED" -> {
                            SecondaryAction(tr(StrAdmin.publish), Modifier.weight(1f)) {
                                vm.act { AdminRepository.reviewContent("COURSE", course.id, "PUBLISH", note) }
                            }
                            SecondaryAction(tr(StrAdmin.reject), Modifier.weight(1f)) {
                                vm.act { AdminRepository.reviewContent("COURSE", course.id, "REJECT", note) }
                            }
                        }
                        "PUBLISHED" -> SecondaryAction(tr(StrAdmin.suspend), Modifier.weight(1f)) {
                            vm.act { AdminRepository.reviewContent("COURSE", course.id, "SUSPEND", note) }
                        }
                        "SUSPENDED" -> SecondaryAction(tr(StrAdmin.republish), Modifier.weight(1f)) {
                            vm.act { AdminRepository.reviewContent("COURSE", course.id, "PUBLISH", note) }
                        }
                        else -> Unit
                    }
                }
            }
        }

    }
}

// ---------------------------------------------------------------- Pricing

class PricingVm : AdminListViewModel<List<CountryPricing>>({ AdminRepository.countryPricing() })

@Composable
fun AdminPricingScreen(navController: NavHostController) {
    val vm: PricingVm = viewModel()
    var code by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("") }
    var multiplier by remember { mutableStateOf("1") }
    var roundTo by remember { mutableStateOf("5") }
    var discount by remember { mutableStateOf("0") }

    AdminScaffold(tr(StrAdmin.countryPricing), navController, vm) { rows ->
        item {
            InkCard {
                Text(tr(StrAdmin.addUpdateCountry), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    tr(StrAdmin.pricingPolicy),
                    color = Ink.TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) {
                        InkField(code, { code = it.uppercase().take(2) }, tr(StrAdmin.country))
                    }
                    Box(Modifier.weight(1f)) {
                        InkField(currency, { currency = it.uppercase().take(3) }, tr(StrAdmin.currency))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) {
                        InkField(multiplier, { multiplier = it.filter { c -> c.isDigit() || c == '.' } }, tr(StrAdmin.rateField), keyboardType = KeyboardType.Decimal)
                    }
                    Box(Modifier.weight(1f)) {
                        InkField(roundTo, { roundTo = it.filter { c -> c.isDigit() || c == '.' } }, tr(StrAdmin.roundTo), keyboardType = KeyboardType.Decimal)
                    }
                    Box(Modifier.weight(1f)) {
                        InkField(discount, { discount = it.filter { c -> c.isDigit() || c == '.' } }, tr(StrAdmin.discPct), keyboardType = KeyboardType.Decimal)
                    }
                }
                Spacer(Modifier.height(14.dp))
                PrimaryAction(tr(StrAdmin.saveCountryPricing), enabled = code.length == 2 && currency.length == 3) {
                    vm.act {
                        AdminRepository.saveCountryPricing(
                            CountryPricing(
                                countryCode = code,
                                currency = currency,
                                fxMultiplier = multiplier.toDoubleOrNull() ?: 1.0,
                                roundTo = roundTo.toDoubleOrNull() ?: 1.0,
                                discountPercent = discount.toDoubleOrNull() ?: 0.0,
                            ),
                        )
                    }
                    code = ""; currency = ""
                }
            }
        }

        if (rows.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noCountryRules), tr(StrAdmin.noCountryRulesBody)) }
        }
        items(rows, key = { it.countryCode }) { row ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${row.countryCode} · ${row.currency}", color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                    Text(
                        tr(StrAdmin.remove),
                        color = Ink.Coral,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.clickable { vm.act { AdminRepository.deleteCountryPricing(row.countryCode) } },
                    )
                }
                Spacer(Modifier.height(8.dp))
                KeyValueRow(tr(StrAdmin.multiplier), "× ${row.fxMultiplier}")
                KeyValueRow(tr(StrAdmin.roundedTo), row.roundTo.toString())
                KeyValueRow(tr(StrAdmin.discount), "${row.discountPercent}%")
            }
        }
    }
}

// ---------------------------------------------------------------- Coupons

class CouponsVm : AdminListViewModel<List<Coupon>>({ AdminRepository.coupons() })

@Composable
fun AdminCouponsScreen(navController: NavHostController, session: SessionViewModel) {
    val vm: CouponsVm = viewModel()
    val sessionState by session.state.collectAsStateWithLifecycle()
    var code by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("PERCENT") }
    var amount by remember { mutableStateOf("") }
    var maxUses by remember { mutableStateOf("") }

    // Which coupon is open for editing, and the confirm step before one is removed.
    var editingId by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf<Coupon?>(null) }

    confirmDelete?.let { coupon ->
        ConfirmDialog(
            title = "${tr(StrAdmin.deleteCoupon)} · ${coupon.code}",
            body = tr(StrAdmin.deleteCouponConfirm),
            confirmLabel = tr(StrAdmin.deleteCoupon),
            destructive = true,
            onDismiss = { confirmDelete = null },
            onConfirm = {
                coupon.id?.let { id -> vm.act { AdminRepository.deleteCoupon(id) } }
                confirmDelete = null
            },
        )
    }

    AdminScaffold(tr(StrAdmin.coupons), navController, vm) { coupons ->
        item {
            InkCard {
                Text(tr(StrAdmin.newCoupon), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                InkField(code, { code = it.uppercase() }, tr(StrAdmin.code))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("PERCENT", "FIXED").forEach { option ->
                        Pill(
                            codeLabel(option),
                            Modifier.clickable { kind = option },
                            background = if (kind == option) Ink.AmberSoft else Ink.SurfaceHigh,
                            foreground = if (kind == option) Ink.Amber else Ink.TextMuted,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) {
                        InkField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, tr(StrAdmin.amount), keyboardType = KeyboardType.Decimal)
                    }
                    Box(Modifier.weight(1f)) {
                        InkField(maxUses, { maxUses = it.filter(Char::isDigit) }, tr(StrAdmin.maxUses), keyboardType = KeyboardType.Number)
                    }
                }
                Spacer(Modifier.height(14.dp))
                PrimaryAction(tr(StrAdmin.createCoupon), enabled = code.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0) {
                    vm.act {
                        AdminRepository.saveCoupon(code, kind, amount.toDoubleOrNull() ?: 0.0, maxUses.toIntOrNull(), null)
                    }
                    code = ""; amount = ""; maxUses = ""
                }
            }
        }

        if (coupons.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noCoupons), tr(StrAdmin.noCouponsBody)) }
        }
        items(coupons, key = { it.id ?: it.code }) { coupon ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(coupon.code, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                    Pill(
                        if (coupon.kind == "PERCENT") "${coupon.amount.toInt()}%" else coupon.amount.toString(),
                    )
                }
                Spacer(Modifier.height(8.dp))
                KeyValueRow(tr(StrAdmin.used), "${coupon.usedCount}${coupon.maxUses?.let { " / $it" } ?: ""}")
                coupon.expiresAt?.let { KeyValueRow(tr(StrAdmin.expires), formatDate(it)) }
                Spacer(Modifier.height(6.dp))
                ToggleRow(tr(StrAdmin.activeLabel), coupon.isActive) { value ->
                    coupon.id?.let { id -> vm.act { AdminRepository.setCouponActive(id, value) } }
                }

                if (coupon.id != null && sessionState.can("coupons.manage")) {
                    if (editingId == coupon.id) {
                        CouponEditor(
                            coupon = coupon,
                            onCancel = { editingId = null },
                            onSave = { newCode, newKind, newAmount, newMax ->
                                vm.act {
                                    AdminRepository.updateCoupon(coupon.id, newCode, newKind, newAmount, newMax)
                                }
                                editingId = null
                            },
                        )
                    } else {
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SecondaryAction(tr(StrAdmin.editCoupon), Modifier.weight(1f)) {
                                editingId = coupon.id
                            }
                            SecondaryAction(
                                tr(StrAdmin.deleteCoupon),
                                Modifier.weight(1f),
                                tint = Ink.Coral,
                            ) { confirmDelete = coupon }
                        }
                    }
                }
            }
        }
    }
}

/** Inline edit form for one coupon; the code itself stays editable so typos can be fixed. */
@Composable
private fun CouponEditor(
    coupon: Coupon,
    onCancel: () -> Unit,
    onSave: (String, String, Double, Int?) -> Unit,
) {
    var code by remember(coupon.id) { mutableStateOf(coupon.code) }
    var kind by remember(coupon.id) { mutableStateOf(coupon.kind) }
    var amount by remember(coupon.id) {
        mutableStateOf(coupon.amount.toString().removeSuffix(".0"))
    }
    var maxUses by remember(coupon.id) { mutableStateOf(coupon.maxUses?.toString().orEmpty()) }

    Spacer(Modifier.height(12.dp))
    Divider()
    Spacer(Modifier.height(12.dp))
    Text(tr(StrAdmin.editCoupon), color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
    Spacer(Modifier.height(10.dp))
    InkField(code, { code = it.uppercase() }, tr(StrAdmin.code))
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("PERCENT", "FIXED").forEach { option ->
            Pill(
                codeLabel(option),
                Modifier.clickable { kind = option },
                background = if (kind == option) Ink.AmberSoft else Ink.SurfaceHigh,
                foreground = if (kind == option) Ink.Amber else Ink.TextMuted,
            )
        }
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f)) {
            InkField(
                amount,
                { amount = it.filter { c -> c.isDigit() || c == '.' } },
                tr(StrAdmin.amount),
                keyboardType = KeyboardType.Decimal,
            )
        }
        Box(Modifier.weight(1f)) {
            InkField(
                maxUses,
                { maxUses = it.filter(Char::isDigit) },
                tr(StrAdmin.maxUses),
                keyboardType = KeyboardType.Number,
            )
        }
    }
    Spacer(Modifier.height(12.dp))
    PrimaryAction(
        tr(StrAdmin.saveCoupon),
        enabled = code.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0,
    ) {
        onSave(code.trim(), kind, amount.toDoubleOrNull() ?: 0.0, maxUses.toIntOrNull())
    }
    Spacer(Modifier.height(8.dp))
    SecondaryAction(tr(StrAdmin.cancel), Modifier.fillMaxWidth()) { onCancel() }
}

// ---------------------------------------------------------------- Finance

data class FinanceData(val orders: List<Order>, val refunds: List<RefundRow>)

class FinanceVm : AdminListViewModel<FinanceData>({
    FinanceData(AdminRepository.orders(), AdminRepository.refunds())
})

@Composable
fun AdminFinanceScreen(navController: NavHostController) {
    val vm: FinanceVm = viewModel()
    var refundFor by remember { mutableStateOf<String?>(null) }
    var refundAmount by remember { mutableStateOf("") }
    var refundReason by remember { mutableStateOf("") }
    var refundKind by remember { mutableStateOf("REFUND") }

    AdminScaffold(tr(StrAdmin.ordersRefunds), navController, vm) { data ->
        item { SectionHeader(tr(StrAdmin.orders)) }
        if (data.orders.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noOrders), tr(StrAdmin.noOrdersBody)) }
        }
        items(data.orders, key = { it.id }) { order ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        formatMoney(order.totalAmount, order.currency),
                        color = Ink.Amber,
                        style = MaterialTheme.typography.titleMedium,
                    )
                    StatusPill(order.status)
                }
                Spacer(Modifier.height(8.dp))
                KeyValueRow(tr(StrAdmin.type), order.itemType)
                KeyValueRow(tr(StrAdmin.country), order.countryCode)
                KeyValueRow(tr(StrAdmin.teacherShare), formatMoney(order.teacherAmount, order.currency))
                KeyValueRow(tr(StrAdmin.platformShare), formatMoney(order.platformAmount, order.currency))
                KeyValueRow(tr(StrAdmin.commissionUsed), "${(order.commissionRate * 100).toInt()}%")
                KeyValueRow(tr(StrAdmin.date), formatDate(order.paidAt ?: order.createdAt))
                if (order.refundedAmount > 0) {
                    KeyValueRow(tr(StrAdmin.refunded), formatMoney(order.refundedAmount, order.currency), valueColor = Ink.Coral)
                }

                if (order.status == "PAID" || order.status == "PARTIALLY_REFUNDED") {
                    Spacer(Modifier.height(12.dp))
                    if (refundFor == order.id) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("REFUND", "CHARGEBACK").forEach { option ->
                                Pill(
                                    codeLabel(option),
                                    Modifier.clickable { refundKind = option },
                                    background = if (refundKind == option) Ink.CoralSoft else Ink.SurfaceHigh,
                                    foreground = if (refundKind == option) Ink.Coral else Ink.TextMuted,
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        InkField(refundAmount, { refundAmount = it.filter { c -> c.isDigit() || c == '.' } }, tr(StrAdmin.amount), keyboardType = KeyboardType.Decimal)
                        Spacer(Modifier.height(8.dp))
                        InkField(refundReason, { refundReason = it }, tr(StrAdmin.reason))
                        Spacer(Modifier.height(12.dp))
                        PrimaryAction(
                            trf(StrAdmin.processKind, statusLabel(refundKind).lowercase(java.util.Locale.US)),
                            enabled = (refundAmount.toDoubleOrNull() ?: 0.0) > 0,
                        ) {
                            vm.act {
                                AdminRepository.refund(
                                    order.id,
                                    refundAmount.toDoubleOrNull() ?: 0.0,
                                    refundKind,
                                    refundReason,
                                )
                            }
                            refundFor = null; refundAmount = ""; refundReason = ""
                        }
                        Spacer(Modifier.height(8.dp))
                        SecondaryAction(tr(StrAdmin.cancel), Modifier.fillMaxWidth()) { refundFor = null }
                    } else {
                        SecondaryAction(tr(StrAdmin.refundChargeback), Modifier.fillMaxWidth()) {
                            refundFor = order.id
                            refundAmount = (order.totalAmount - order.refundedAmount).toString()
                        }
                    }
                }
            }
        }

        if (data.refunds.isNotEmpty()) {
            item { SectionHeader(tr(StrAdmin.refundHistory)) }
            items(data.refunds, key = { it.id }) { refund ->
                InkCard(contentPadding = PaddingValues(14.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column {
                            Text(refund.kind, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                            Text(formatDate(refund.createdAt), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            formatMoney(refund.amount, refund.currency),
                            color = Ink.Coral,
                            style = MaterialTheme.typography.titleSmall,
                        )
                    }
                    if (!refund.reason.isNullOrBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(refund.reason, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Payouts

class PayoutsVm : AdminListViewModel<List<Payout>>({ AdminRepository.payouts(null) })

@Composable
fun AdminPayoutsScreen(navController: NavHostController) {
    val vm: PayoutsVm = viewModel()
    var reference by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AdminScaffold(tr(StrAdmin.withdrawals), navController, vm) { payouts ->
        if (payouts.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noWithdrawals), tr(StrAdmin.noWithdrawalsBody)) }
        }
        items(payouts, key = { it.id }) { payout ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Avatar(payout.teacher?.avatarUrl, payout.teacher?.fullName, 36.dp)
                        Column {
                            Text(
                                payout.teacher?.fullName ?: tr(StrAdmin.teacherLabel),
                                color = Ink.TextPrimary,
                                style = MaterialTheme.typography.titleSmall,
                            )
                            Text(
                                formatMoney(payout.amount, payout.currency),
                                color = Ink.Amber,
                                style = MaterialTheme.typography.titleMedium,
                            )
                        }
                    }
                    StatusPill(payout.status)
                }
                Spacer(Modifier.height(8.dp))
                payout.method?.let { KeyValueRow(tr(StrAdmin.method), it) }
                payout.destination?.let { KeyValueRow(tr(StrAdmin.destination), it) }
                KeyValueRow(tr(StrAdmin.requested), formatDate(payout.requestedAt))

                Spacer(Modifier.height(12.dp))
                when (payout.status) {
                    "PENDING" -> {
                        InkField(note, { note = it }, tr(StrAdmin.decisionNote))
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            SecondaryAction(tr(StrAdmin.approve), Modifier.weight(1f)) {
                                vm.act { AdminRepository.reviewPayout(payout.id, "APPROVE", "", note) }
                                note = ""
                            }
                            SecondaryAction(tr(StrAdmin.reject), Modifier.weight(1f)) {
                                vm.act { AdminRepository.reviewPayout(payout.id, "REJECT", "", note) }
                                note = ""
                            }
                        }
                    }
                    "APPROVED" -> {
                        InkField(reference, { reference = it }, tr(StrAdmin.transferReference))
                        Spacer(Modifier.height(10.dp))
                        PrimaryAction(tr(StrAdmin.markAsPaid), enabled = reference.isNotBlank()) {
                            vm.act { AdminRepository.reviewPayout(payout.id, "PAID", reference, "") }
                            reference = ""
                        }
                    }
                    else -> payout.reference?.let { KeyValueRow(tr(StrAdmin.reference), it) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Users & admins

class UsersVm : AdminListViewModel<List<Profile>>({ AdminRepository.users() })

@Composable
fun AdminUsersScreen(navController: NavHostController, session: SessionViewModel) {
    val vm: UsersVm = viewModel()
    val sessionState by session.state.collectAsStateWithLifecycle()
    var expanded by remember { mutableStateOf<String?>(null) }
    var granted by remember { mutableStateOf<Set<String>>(emptySet()) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    AdminScaffold(tr(StrAdmin.users), navController, vm) { users ->
        if (sessionState.isOwner) {
            item {
                Text(
                    tr(StrAdmin.adminsPolicy),
                    color = Ink.TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        if (users.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noUsers), tr(StrAdmin.noUsersBody)) }
        }
        items(users, key = { it.id }) { user ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Avatar(user.avatarUrl, user.displayName, 36.dp)
                        Column {
                            Text(user.displayName, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                            Text(user.email.orEmpty(), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Pill(user.role)
                }
                Spacer(Modifier.height(10.dp))
                KeyValueRow(tr(StrAdmin.statusLabel), user.status)
                user.currentLevel?.let { KeyValueRow(tr(StrAdmin.levelLabel), it) }

                val isSelf = user.id == sessionState.profile?.id

                if (user.role != "OWNER" && !isSelf) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SecondaryAction(
                            if (user.status == "ACTIVE") tr(StrAdmin.suspend) else tr(StrAdmin.reactivate),
                            Modifier.weight(1f),
                        ) {
                            vm.act {
                                AdminRepository.setUserStatus(
                                    user.id,
                                    if (user.status == "ACTIVE") "SUSPENDED" else "ACTIVE",
                                    tr(StrAdmin.changedFromConsole),
                                )
                            }
                        }
                        if (sessionState.isOwner) {
                            SecondaryAction(tr(StrAdmin.permissions), Modifier.weight(1f)) {
                                expanded = if (expanded == user.id) null else user.id
                                if (expanded == user.id) {
                                    scope.launch { granted = AdminRepository.permissionsOf(user.id) }
                                }
                            }
                        }
                    }

                    // Appointing and standing down admins is the owner's alone.
                    if (sessionState.isOwner) {
                        Spacer(Modifier.height(10.dp))
                        if (user.role == "ADMIN") {
                            SecondaryAction(
                                tr(StrAdmin.removeAdmin),
                                Modifier.fillMaxWidth(),
                                tint = Ink.Coral,
                            ) {
                                vm.act { AdminRepository.setUserRole(user.id, "STUDENT", tr(StrAdmin.changedFromConsole)) }
                                expanded = null
                            }
                        } else {
                            SecondaryAction(tr(StrAdmin.makeAdmin), Modifier.fillMaxWidth()) {
                                vm.act { AdminRepository.setUserRole(user.id, "ADMIN", tr(StrAdmin.changedFromConsole)) }
                                expanded = user.id
                                scope.launch { granted = AdminRepository.permissionsOf(user.id) }
                            }
                        }
                    }
                }

                if (expanded == user.id && sessionState.isOwner) {
                    Spacer(Modifier.height(12.dp))
                    Divider()
                    Spacer(Modifier.height(10.dp))
                    Text(tr(StrAdmin.adminAccess), color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        tr(StrAdmin.permissionsPolicy),
                        color = Ink.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill(
                            tr(StrAdmin.selectAll),
                            Modifier.clickable {
                                granted = AdminRepository.ALL_PERMISSIONS.map { it.first }.toSet()
                            },
                            background = Ink.SurfaceHigh,
                            foreground = Ink.TextSecondary,
                        )
                        Pill(
                            tr(StrAdmin.clearAll),
                            Modifier.clickable { granted = emptySet() },
                            background = Ink.SurfaceHigh,
                            foreground = Ink.TextSecondary,
                        )
                        Pill(trf(StrAdmin.permissionsCount, granted.size))
                    }
                    Spacer(Modifier.height(8.dp))
                    AdminRepository.ALL_PERMISSIONS.forEach { (key, label) ->
                        ToggleRow(label, key in granted) { value ->
                            granted = if (value) granted + key else granted - key
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    PrimaryAction(tr(StrAdmin.savePermissions)) {
                        vm.act { AdminRepository.setPermissions(user.id, granted) }
                        expanded = null
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- CMS

data class CmsData(val banners: List<Banner>, val categories: List<com.rork.pro.data.Category>)

class CmsVm : AdminListViewModel<CmsData>({ CmsData(AdminRepository.banners(), AdminRepository.categories()) })

@Composable
fun AdminCmsScreen(navController: NavHostController) {
    val vm: CmsVm = viewModel()
    var title by remember { mutableStateOf("") }
    var subtitle by remember { mutableStateOf("") }
    var image by remember { mutableStateOf("") }
    var cta by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var categoryName by remember { mutableStateOf("") }

    AdminScaffold(tr(StrAdmin.homeContent), navController, vm) { data ->
        item {
            InkCard {
                Text(tr(StrAdmin.newHomeBanner), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                InkField(title, { title = it }, tr(StrAdmin.headline))
                Spacer(Modifier.height(8.dp))
                InkField(subtitle, { subtitle = it }, tr(StrAdmin.subtitle))
                Spacer(Modifier.height(8.dp))
                InkField(image, { image = it }, tr(StrAdmin.imageUrl))
                Spacer(Modifier.height(8.dp))
                InkField(cta, { cta = it }, tr(StrAdmin.buttonLabel))
                Spacer(Modifier.height(8.dp))
                InkField(target, { target = it }, tr(StrAdmin.bannerTarget))
                Spacer(Modifier.height(14.dp))
                PrimaryAction(tr(StrAdmin.publishBanner), enabled = title.isNotBlank()) {
                    vm.act { AdminRepository.saveBanner(null, title, subtitle, image, cta, target, true) }
                    title = ""; subtitle = ""; image = ""; cta = ""; target = ""
                }
            }
        }

        items(data.banners, key = { it.id }) { banner ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        banner.title,
                        color = Ink.TextPrimary,
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        tr(StrAdmin.delete),
                        color = Ink.Coral,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.clickable { vm.act { AdminRepository.deleteBanner(banner.id) } },
                    )
                }
                Spacer(Modifier.height(8.dp))
                ToggleRow(tr(StrAdmin.activeLabel), banner.isActive) { value ->
                    vm.act {
                        AdminRepository.saveBanner(
                            banner.id,
                            banner.title,
                            banner.subtitle.orEmpty(),
                            banner.imageUrl.orEmpty(),
                            banner.ctaLabel.orEmpty(),
                            banner.ctaTarget.orEmpty(),
                            value,
                        )
                    }
                }
            }
        }

        item { SectionHeader(tr(StrAdmin.categories)) }
        item {
            InkCard {
                InkField(categoryName, { categoryName = it }, tr(StrAdmin.categoryName))
                Spacer(Modifier.height(12.dp))
                PrimaryAction(tr(StrAdmin.addCategory), enabled = categoryName.isNotBlank()) {
                    vm.act {
                        AdminRepository.saveCategory(categoryName, categoryName, data.categories.size)
                    }
                    categoryName = ""
                }
            }
        }
        items(data.categories, key = { it.id }) { category ->
            InkCard(contentPadding = PaddingValues(14.dp)) {
                Text(category.name, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
            }
        }
    }
}

// ---------------------------------------------------------------- Ads

class AdsVm : AdminListViewModel<List<AdmobPlacement>>({ AdminRepository.adPlacements() })

@Composable
fun AdminAdsScreen(navController: NavHostController) {
    val vm: AdsVm = viewModel()
    var screen by remember { mutableStateOf("HOME") }
    var format by remember { mutableStateOf("BANNER") }
    var unit by remember { mutableStateOf("") }
    var frequency by remember { mutableStateOf("1") }

    AdminScaffold(tr(StrAdmin.admob), navController, vm) { placements ->
        item {
            InkCard {
                Text(tr(StrAdmin.adsPolicyTitle), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    tr(StrAdmin.adsPolicyBody),
                    color = Ink.TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        item {
            InkCard {
                Text(tr(StrAdmin.newPlacement), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("HOME", "COURSE_LIST", "COURSE_DETAILS", "FREE_LESSON", "SEARCH", "CATEGORIES")) { option ->
                        Pill(
                            codeLabel(option),
                            Modifier.clickable { screen = option },
                            background = if (screen == option) Ink.AmberSoft else Ink.SurfaceHigh,
                            foreground = if (screen == option) Ink.Amber else Ink.TextMuted,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("BANNER", "NATIVE", "INTERSTITIAL", "REWARDED").forEach { option ->
                        Pill(
                            codeLabel(option),
                            Modifier.clickable { format = option },
                            background = if (format == option) Ink.AmberSoft else Ink.SurfaceHigh,
                            foreground = if (format == option) Ink.Amber else Ink.TextMuted,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                InkField(unit, { unit = it }, tr(StrAdmin.adUnitId))
                Spacer(Modifier.height(8.dp))
                InkField(frequency, { frequency = it.filter(Char::isDigit) }, tr(StrAdmin.frequency), keyboardType = KeyboardType.Number)
                Spacer(Modifier.height(14.dp))
                PrimaryAction(tr(StrAdmin.addPlacement), enabled = unit.isNotBlank()) {
                    vm.act {
                        AdminRepository.saveAdPlacement(null, screen, "", format, unit, frequency.toIntOrNull() ?: 1, false)
                    }
                    unit = ""
                }
            }
        }

        if (placements.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noPlacements), tr(StrAdmin.noPlacementsBody)) }
        }
        items(placements, key = { it.id ?: it.adUnitId }) { placement ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${placement.screen} · ${placement.format}", color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                        Text(placement.adUnitId, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        tr(StrAdmin.delete),
                        color = Ink.Coral,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.clickable {
                            placement.id?.let { id -> vm.act { AdminRepository.deleteAdPlacement(id) } }
                        },
                    )
                }
                Spacer(Modifier.height(8.dp))
                ToggleRow(tr(StrAdmin.enabledLabel), placement.isEnabled) { value ->
                    vm.act {
                        AdminRepository.saveAdPlacement(
                            placement.id,
                            placement.screen,
                            placement.section.orEmpty(),
                            placement.format,
                            placement.adUnitId,
                            placement.frequency,
                            value,
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Settings

class SettingsVm : AdminListViewModel<List<AppSetting>>({ AdminRepository.settings() })

@Composable
fun AdminSettingsScreen(navController: NavHostController, session: SessionViewModel) {
    val vm: SettingsVm = viewModel()
    val sessionState by session.state.collectAsStateWithLifecycle()

    AdminScaffold(tr(StrAdmin.platformSettings), navController, vm) { settings ->
        if (sessionState.isOwner) {
            item { ForceUpdateCard(settings) { key, value -> vm.act { AdminRepository.saveSetting(key, value) } } }
        }
        item {
            Text(
                tr(StrAdmin.settingsPolicy),
                color = Ink.TextMuted,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        items(settings, key = { it.key }) { setting ->
            var value by remember(setting.key) {
                mutableStateOf(setting.value.toString().trim('"'))
            }
            InkCard {
                Text(setting.key, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                if (!setting.description.isNullOrBlank()) {
                    Text(setting.description, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) {
                        InkField(value, { value = it }, tr(StrAdmin.valueLabel))
                    }
                    SecondaryAction(tr(StrAdmin.save)) {
                        val json = when {
                            value.equals("true", true) || value.equals("false", true) -> value.lowercase()
                            value.toDoubleOrNull() != null -> value
                            else -> "\"$value\""
                        }
                        vm.act { AdminRepository.saveSetting(setting.key, json) }
                    }
                }
            }
        }
    }
}

/**
 * The owner's switch for forcing everyone onto a newer build.
 *
 * The switch alone does nothing until a minimum build number is set, so it is saved together
 * with the number, the message learners read, and where they go to get the update.
 */
@Composable
private fun ForceUpdateCard(settings: List<AppSetting>, onSave: (String, String) -> Unit) {
    fun read(key: String): String =
        settings.firstOrNull { it.key == key }?.value?.toString()?.trim('"').orEmpty()

    val storedOn = read(UpdateKeys.FORCE) == "true"
    var forced by remember(storedOn) { mutableStateOf(storedOn) }
    var minBuild by remember(settings) {
        mutableStateOf(read(UpdateKeys.MIN_BUILD).takeIf { it.isNotBlank() } ?: BuildConfig.VERSION_CODE.toString())
    }
    var message by remember(settings) { mutableStateOf(read(UpdateKeys.MESSAGE)) }
    var link by remember(settings) { mutableStateOf(read(UpdateKeys.URL)) }

    InkCard(borderColor = if (forced) Ink.Amber.copy(alpha = 0.45f) else Ink.Hairline) {
        Text(tr(StrAdmin.appUpdates), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(tr(StrAdmin.forceUpdatePolicy), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        ToggleRow(tr(StrAdmin.forceUpdate), forced) { forced = it }
        Spacer(Modifier.height(6.dp))
        InkField(
            minBuild,
            { minBuild = it.filter(Char::isDigit) },
            tr(StrAdmin.minimumBuild),
            keyboardType = KeyboardType.Number,
        )
        Text(
            trf(StrAdmin.thisBuild, BuildConfig.VERSION_CODE.toString()),
            color = Ink.TextMuted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp),
        )
        Spacer(Modifier.height(8.dp))
        InkField(message, { message = it }, tr(StrAdmin.updateMessageField), singleLine = false, minLines = 2)
        Spacer(Modifier.height(8.dp))
        InkField(link, { link = it }, tr(StrAdmin.updateLinkField))
        Spacer(Modifier.height(14.dp))
        PrimaryAction(tr(StrAdmin.saveUpdateRule)) {
            onSave(UpdateKeys.FORCE, forced.toString())
            onSave(UpdateKeys.MIN_BUILD, (minBuild.toIntOrNull() ?: BuildConfig.VERSION_CODE).toString())
            onSave(UpdateKeys.MESSAGE, "\"${message.trim().replace("\"", "'")}\"")
            onSave(UpdateKeys.URL, "\"${link.trim()}\"")
        }
    }
}

// ---------------------------------------------------------------- Placement tests

data class TestsData(val tests: List<PlacementTest>, val counts: Map<String, Int>)

class TestsVm : AdminListViewModel<TestsData>({
    val tests = AdminRepository.tests()
    TestsData(tests, tests.associate { it.id to AdminRepository.questionCount(it.id) })
})

@Composable
fun AdminTestsScreen(navController: NavHostController) {
    val vm: TestsVm = viewModel()
    var editingTestId by remember { mutableStateOf<String?>(null) }
    var deleteTestTarget by remember { mutableStateOf<PlacementTest?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var questionCount by remember { mutableStateOf("20") }
    var minutes by remember { mutableStateOf("20") }

    var questionFor by remember { mutableStateOf<String?>(null) }
    var prompt by remember { mutableStateOf("") }
    var options by remember { mutableStateOf("") }
    var correct by remember { mutableStateOf("") }
    var acceptedText by remember { mutableStateOf("") }
    var skill by remember { mutableStateOf("GRAMMAR") }
    var difficulty by remember { mutableStateOf("3") }
    var kind by remember { mutableStateOf("SINGLE") }
    var explanation by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var audioUrl by remember { mutableStateOf("") }
    var videoUrl by remember { mutableStateOf("") }

    AdminScaffold(tr(StrAdmin.placementTests), navController, vm) { data ->
        item {
            InkCard {
                Text(
                    if (editingTestId == null) tr(StrAdmin.newTest) else tr(StrAdmin.editTest),
                    color = Ink.TextPrimary,
                    style = MaterialTheme.typography.titleMedium,
                )
                Spacer(Modifier.height(12.dp))
                InkField(title, { title = it }, tr(StrAdmin.titleField))
                Spacer(Modifier.height(8.dp))
                InkField(description, { description = it }, tr(StrAdmin.descriptionField), singleLine = false, minLines = 2)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) {
                        InkField(questionCount, { questionCount = it.filter(Char::isDigit) }, tr(StrAdmin.questions), keyboardType = KeyboardType.Number)
                    }
                    Box(Modifier.weight(1f)) {
                        InkField(minutes, { minutes = it.filter(Char::isDigit) }, tr(StrAdmin.minutes), keyboardType = KeyboardType.Number)
                    }
                }
                Spacer(Modifier.height(14.dp))
                PrimaryAction(
                    if (editingTestId == null) tr(StrAdmin.createAdaptiveTest) else tr(StrAdmin.saveTest),
                    enabled = title.isNotBlank(),
                ) {
                    vm.act {
                        AdminRepository.saveTest(
                            editingTestId, title, description, true,
                            questionCount.toIntOrNull() ?: 20,
                            (minutes.toIntOrNull() ?: 20) * 60,
                            50.0,
                        )
                    }
                    editingTestId = null
                    title = ""; description = ""; questionCount = "20"; minutes = "20"
                }
                if (editingTestId != null) {
                    Spacer(Modifier.height(8.dp))
                    SecondaryAction(tr(StrAdmin.cancel), Modifier.fillMaxWidth()) {
                        editingTestId = null
                        title = ""; description = ""; questionCount = "20"; minutes = "20"
                    }
                }
            }
        }

        if (data.tests.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noTests), tr(StrAdmin.noTestsBody)) }
        }
        items(data.tests, key = { it.id }) { test ->
            val count = data.counts[test.id] ?: 0
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(test.title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    StatusPill(test.status)
                }
                Spacer(Modifier.height(8.dp))
                KeyValueRow(tr(StrAdmin.questionsInBank), count.toString())
                KeyValueRow(tr(StrAdmin.askedPerAttempt), test.questionCount.toString())
                KeyValueRow(tr(StrAdmin.adaptive), if (test.isAdaptive) tr(StrAdmin.yes) else tr(StrAdmin.noWord))

                Spacer(Modifier.height(12.dp))
                if (questionFor == test.id) {
                    InkField(prompt, { prompt = it }, tr(StrAdmin.question), singleLine = false, minLines = 2)
                    Spacer(Modifier.height(8.dp))

                    Text(tr(StrAdmin.questionKind), color = Ink.TextSecondary, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("SINGLE", "TRUE_FALSE", "TEXT")) { option ->
                            Pill(
                                codeLabel(option),
                                Modifier.clickable {
                                    kind = option
                                    if (option == "TRUE_FALSE") {
                                        options = "True, False"
                                    } else if (option == "TEXT") {
                                        options = ""
                                    }
                                },
                                background = if (kind == option) Ink.AmberSoft else Ink.SurfaceHigh,
                                foreground = if (kind == option) Ink.Amber else Ink.TextMuted,
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))

                    if (kind == "TEXT") {
                        InkField(acceptedText, { acceptedText = it }, tr(StrAdmin.correctAnswerText))
                    } else {
                        InkField(options, { options = it }, tr(StrAdmin.optionsCommaSeparated))
                        Spacer(Modifier.height(8.dp))
                        InkField(correct, { correct = it.filter(Char::isDigit) }, tr(StrAdmin.correctOptionNumber), keyboardType = KeyboardType.Number)
                    }
                    Spacer(Modifier.height(8.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("GRAMMAR", "VOCABULARY", "READING", "LISTENING", "WRITING")) { option ->
                            Pill(
                                codeLabel(option),
                                Modifier.clickable { skill = option },
                                background = if (skill == option) Ink.AmberSoft else Ink.SurfaceHigh,
                                foreground = if (skill == option) Ink.Amber else Ink.TextMuted,
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    InkField(difficulty, { difficulty = it.filter(Char::isDigit).take(1) }, tr(StrAdmin.difficultyRange), keyboardType = KeyboardType.Number)

                    // Media is optional — anything left blank simply is not shown to the learner.
                    Spacer(Modifier.height(12.dp))
                    Text(tr(StrAdmin.questionMedia), color = Ink.TextSecondary, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    TestMediaField(
                        tr(StrAdmin.questionImageUrl),
                        imageUrl,
                        { imageUrl = it },
                        "image/*",
                        "placement/${test.id}",
                        tr(StrTeacher.chooseFromPhone),
                    )
                    Spacer(Modifier.height(8.dp))
                    TestMediaField(
                        tr(StrAdmin.questionAudioUrl),
                        audioUrl,
                        { audioUrl = it },
                        "audio/*",
                        "placement/${test.id}",
                        tr(StrTeacher.chooseFromPhone),
                    )
                    Spacer(Modifier.height(8.dp))
                    TestMediaField(
                        tr(StrAdmin.questionVideoUrl),
                        videoUrl,
                        { videoUrl = it },
                        "video/*",
                        "placement/${test.id}",
                        tr(StrTeacher.chooseFromPhone),
                    )
                    Spacer(Modifier.height(8.dp))
                    InkField(explanation, { explanation = it }, tr(StrAdmin.questionExplanation))

                    Spacer(Modifier.height(12.dp))
                    val list = options.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    val accepted = acceptedText.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    PrimaryAction(
                        tr(StrAdmin.addQuestion),
                        enabled = prompt.isNotBlank() &&
                            if (kind == "TEXT") accepted.isNotEmpty() else list.size >= 2 && correct.isNotBlank(),
                    ) {
                        val index = (correct.toIntOrNull() ?: 1) - 1
                        vm.act {
                            AdminRepository.addQuestion(
                                testId = test.id,
                                kind = kind,
                                skill = skill,
                                difficulty = (difficulty.toIntOrNull() ?: 3).coerceIn(1, 6),
                                prompt = prompt,
                                options = if (kind == "TEXT") emptyList() else list,
                                correctIndexes = if (kind == "TEXT") emptyList() else listOf(index.coerceIn(0, list.lastIndex)),
                                correctText = accepted,
                                explanation = explanation,
                                imageUrl = imageUrl,
                                audioUrl = audioUrl,
                                videoUrl = videoUrl,
                            )
                        }
                        prompt = ""; options = ""; correct = ""; acceptedText = ""
                        explanation = ""; imageUrl = ""; audioUrl = ""; videoUrl = ""
                    }
                    Spacer(Modifier.height(8.dp))
                    SecondaryAction(tr(StrAdmin.close), Modifier.fillMaxWidth()) { questionFor = null }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SecondaryAction(tr(StrAdmin.editTest), Modifier.weight(1f)) {
                            editingTestId = test.id
                            title = test.title
                            description = test.description.orEmpty()
                            questionCount = test.questionCount.toString()
                            minutes = (test.timeLimitSeconds / 60).coerceAtLeast(1).toString()
                        }
                        SecondaryAction(tr(StrAdmin.deleteTest), Modifier.weight(1f), tint = Ink.Coral) {
                            deleteTestTarget = test
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SecondaryAction(tr(StrAdmin.addQuestion), Modifier.weight(1f)) { questionFor = test.id }
                        SecondaryAction(
                            if (test.status == "PUBLISHED") tr(StrAdmin.unpublish) else tr(StrAdmin.publish),
                            Modifier.weight(1f),
                            enabled = test.status == "PUBLISHED" || count > 0,
                        ) {
                            vm.act {
                                AdminRepository.setTestStatus(
                                    test.id,
                                    if (test.status == "PUBLISHED") "UNPUBLISHED" else "PUBLISHED",
                                )
                            }
                        }
                    }
                    if (test.status != "PUBLISHED" && count == 0) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            tr(StrAdmin.publishTestFirst),
                            color = Ink.TextMuted,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }

    deleteTestTarget?.let { test ->
        ConfirmDialog(
            tr(StrAdmin.deleteTest),
            tr(StrAdmin.deleteTestConfirm),
            tr(StrAdmin.deleteTest),
            onDismiss = { deleteTestTarget = null },
            onConfirm = {
                vm.act { AdminRepository.deleteTest(test.id) }
                deleteTestTarget = null
                if (editingTestId == test.id) {
                    editingTestId = null
                    title = ""; description = ""
                }
            },
            destructive = true,
        )
    }
}

// ---------------------------------------------------------------- Moderation

class ModerationVm : AdminListViewModel<List<Review>>({ AdminRepository.reviews(null) })

@Composable
fun AdminModerationScreen(navController: NavHostController) {
    val vm: ModerationVm = viewModel()

    AdminScaffold(tr(StrAdmin.reviews), navController, vm) { reviews ->
        if (reviews.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noReviews), tr(StrAdmin.noReviewsBody)) }
        }
        items(reviews, key = { it.id }) { review ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        review.author?.fullName ?: tr(StrAdmin.student),
                        color = Ink.TextPrimary,
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Pill("★ ${review.rating}")
                }
                if (!review.body.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(review.body, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryAction(if (review.isHidden) tr(StrAdmin.restore) else tr(StrAdmin.hide), Modifier.weight(1f)) {
                        vm.act { AdminRepository.setReviewHidden(review.id, !review.isHidden, tr(StrAdmin.moderated)) }
                    }
                    SecondaryAction(tr(StrAdmin.delete), Modifier.weight(1f)) {
                        vm.act { AdminRepository.deleteReview(review.id) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Support

class AdminSupportVm : AdminListViewModel<List<SupportTicket>>({ AdminRepository.tickets(null) })

@Composable
fun AdminSupportScreen(navController: NavHostController) {
    val vm: AdminSupportVm = viewModel()

    AdminScaffold(tr(StrAdmin.supportTickets), navController, vm) { tickets ->
        if (tickets.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.noTickets), tr(StrAdmin.noTicketsBody)) }
        }
        items(tickets, key = { it.id }) { ticket ->
            InkCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        ticket.subject,
                        color = Ink.TextPrimary,
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f),
                    )
                    StatusPill(ticket.status)
                }
                Spacer(Modifier.height(6.dp))
                Text(formatDate(ticket.createdAt), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryAction(tr(StrAdmin.assignToMe), Modifier.weight(1f)) {
                        vm.act { AdminRepository.setTicketStatus(ticket.id, "ASSIGNED") }
                    }
                    SecondaryAction(tr(StrAdmin.resolve), Modifier.weight(1f)) {
                        vm.act { AdminRepository.setTicketStatus(ticket.id, "RESOLVED") }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Audit

class AuditVm : AdminListViewModel<List<AuditLog>>({ AdminRepository.auditLogs() })

@Composable
fun AdminAuditScreen(navController: NavHostController) {
    val vm: AuditVm = viewModel()

    AdminScaffold(tr(StrAdmin.auditLog), navController, vm) { logs ->
        if (logs.isEmpty()) {
            item { EmptyBlock(tr(StrAdmin.nothingLogged), tr(StrAdmin.nothingLoggedBody)) }
        }
        items(logs, key = { it.id }) { log ->
            InkCard(contentPadding = PaddingValues(14.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(log.action, color = Ink.Amber, style = MaterialTheme.typography.titleSmall)
                    Text(formatDate(log.createdAt), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "${log.actor?.fullName ?: tr(StrAdmin.systemActor)} (${log.actorRole ?: "-"}) → " +
                        "${log.targetType ?: ""} ${log.targetId?.take(8) ?: ""}",
                    color = Ink.TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Announcements

class AnnounceVm : AdminListViewModel<Unit>({ }) {
    private val _sent = MutableStateFlow<Int?>(null)
    val sent: StateFlow<Int?> = _sent.asStateFlow()

    fun send(audience: String, title: String, body: String) {
        _sent.value = null
        act { _sent.value = AdminRepository.broadcast(audience, title, body) }
    }

    fun clearSent() { _sent.value = null }
}

/**
 * One important message to one audience.
 *
 * Announcements land in the same notification history every learner already has, so nothing
 * here is a separate, noisier channel — and the sender sees exactly how many people it reached.
 */
@Composable
fun AdminAnnouncementsScreen(navController: NavHostController) {
    val vm: AnnounceVm = viewModel()
    val sent by vm.sent.collectAsStateWithLifecycle()
    var audience by remember { mutableStateOf("ALL") }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }

    val audiences = listOf(
        "ALL" to tr(StrAdmin.audienceAll),
        "STUDENTS" to tr(StrAdmin.audienceStudents),
        "TEACHERS" to tr(StrAdmin.audienceTeachers),
        "STAFF" to tr(StrAdmin.audienceStaff),
    )

    AdminScaffold(tr(StrAdmin.announcements), navController, vm) {
        item {
            InkCard {
                Text(tr(StrAdmin.announcementPolicy), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Text(tr(StrAdmin.audience), color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(audiences) { (key, label) ->
                        Pill(
                            label,
                            Modifier.clickable { audience = key },
                            background = if (audience == key) Ink.AmberSoft else Ink.SurfaceHigh,
                            foreground = if (audience == key) Ink.Amber else Ink.TextMuted,
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                InkField(title, { title = it }, tr(StrAdmin.announcementTitle))
                Spacer(Modifier.height(8.dp))
                InkField(body, { body = it }, tr(StrAdmin.announcementBody), singleLine = false, minLines = 3)
                sent?.let { count ->
                    Spacer(Modifier.height(10.dp))
                    Text(trf(StrAdmin.announcementSent, count), color = Ink.Teal, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(14.dp))
                PrimaryAction(tr(StrAdmin.sendAnnouncement), enabled = title.isNotBlank()) {
                    vm.send(audience, title, body)
                    title = ""; body = ""
                }
            }
        }
    }
}
