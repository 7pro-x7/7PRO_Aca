package com.rork.pro.data

import com.rork.pro.BuildConfig
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.functions.Functions
import io.github.jan.supabase.functions.functions
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject

/** Single Supabase client for the whole app. */
object Backend {
    /**
     * Deep link the Google sign-in browser hands control back through.
     *
     * Must match the redirect URL allowed on the Supabase project and the intent filter in the
     * manifest, otherwise the browser finishes the sign-in but never returns to the app.
     */
    const val AUTH_SCHEME: String = "sevenpro"
    const val AUTH_HOST: String = "auth"

    val json: Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
        explicitNulls = false
        coerceInputValues = true
    }

    val client: SupabaseClient by lazy {
        createSupabaseClient(
            supabaseUrl = BuildConfig.SUPABASE_URL,
            supabaseKey = BuildConfig.SUPABASE_ANON_KEY,
        ) {
            install(Auth) {
                scheme = AUTH_SCHEME
                host = AUTH_HOST
            }
            install(Postgrest)
            install(Functions)
            install(Storage)
            defaultSerializer = io.github.jan.supabase.serializer.KotlinXSerializer(json)
        }
    }

    val isConfigured: Boolean
        get() = BuildConfig.SUPABASE_URL.isNotBlank() && BuildConfig.SUPABASE_ANON_KEY.isNotBlank()

    val auth get() = client.auth
    val db get() = client.postgrest
    val storage get() = client.storage

    val currentUserId: String?
        get() = runCatching { client.auth.currentUserOrNull()?.id }.getOrNull()

    /** Calls a Postgres function and decodes the JSON result. */
    suspend inline fun <reified T> rpc(name: String, params: JsonObject = buildJsonObject { }): T {
        return client.postgrest.rpc(name, params).decodeAs()
    }

    suspend fun rpcRaw(name: String, params: JsonObject = buildJsonObject { }): JsonElement {
        val raw = client.postgrest.rpc(name, params).data
        return if (raw.isBlank()) JsonNull else json.parseToJsonElement(raw)
    }

    suspend fun rpcVoid(name: String, params: JsonObject = buildJsonObject { }) {
        client.postgrest.rpc(name, params)
    }

    /** Invokes an edge function and returns the parsed JSON body. */
    suspend fun invokeFunction(slug: String, body: JsonObject): JsonElement {
        val response = client.functions.invoke(slug) {
            contentType(ContentType.Application.Json)
            setBody(body)
        }
        val text = response.bodyAsText()
        return if (text.isBlank()) JsonNull else json.parseToJsonElement(text)
    }
}
