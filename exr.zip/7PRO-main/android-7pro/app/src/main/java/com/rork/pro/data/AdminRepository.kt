package com.rork.pro.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.query.Order as SortOrder
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** Owner / Admin console. Every mutation is a permission-checked server function. */
object AdminRepository {

    val ALL_PERMISSIONS: List<Pair<String, String>> = listOf(
        "users.manage" to "Manage users & account status",
        "teachers.manage" to "Approve teachers & availability",
        "courses.manage" to "Review & publish courses",
        "notifications.manage" to "Send announcements",
        "pricing.manage" to "Country pricing & overrides",
        "coupons.manage" to "Coupons & promotions",
        "finance.read" to "View financial records",
        "finance.manage" to "Refunds & chargebacks",
        "payouts.manage" to "Approve & pay withdrawals",
        "reviews.manage" to "Moderate reviews",
        "support.manage" to "Support tickets",
        "tests.manage" to "Placement tests",
        "cms.manage" to "Home content & banners",
        "ads.manage" to "AdMob configuration",
        "settings.manage" to "Platform settings",
        "analytics.read" to "Analytics dashboards",
        "audit.read" to "Audit logs",
    )

    suspend fun analytics(country: String? = null, teacherId: String? = null): JsonObject =
        Backend.rpcRaw(
            "owner_analytics",
            buildJsonObject {
                put("p_from", null as String?)
                put("p_to", null as String?)
                put("p_country", country)
                put("p_teacher", teacherId)
            },
        ) as JsonObject

    // ---------- teachers ----------

    /**
     * Owner-only lifecycle actions on a teaching account.
     *
     * Both branches touch several tables at once (profile role, teaching profile, catalogue),
     * so the whole change is made server-side in one audited step.
     *
     * @param action `REACTIVATE` to lift a suspension, `DELETE` to remove the teaching account.
     */
    suspend fun manageTeacher(teacherId: String, action: String, note: String = "") {
        Backend.rpcVoid(
            "manage_teacher",
            buildJsonObject {
                put("p_teacher", teacherId)
                put("p_action", action)
                put("p_note", note.trim().takeIf { it.isNotBlank() })
            },
        )
    }

    /**
     * Turns a registered member into a teacher.
     *
     * Teachers cannot sign themselves up any more, so this owner/admin action is the only way a
     * teaching account is ever created. The commission the owner types here is the share the
     * platform keeps and is stored on the teaching profile, never on the client.
     */
    suspend fun createTeacher(userId: String, headline: String, commission: Double?) {
        Backend.rpcVoid(
            "create_teacher",
            buildJsonObject {
                put("p_user", userId)
                put("p_headline", headline.trim().takeIf { it.isNotBlank() })
                put("p_commission", commission)
            },
        )
    }

    suspend fun teachers(): List<TeacherProfile> =
        Backend.client.from("teacher_profiles")
            .select(Columns.raw("*, profile:profiles!teacher_profiles_id_fkey(id, full_name, avatar_url)")) {
                order("created_at", SortOrder.DESCENDING)
            }
            .decodeList()

    suspend fun setTeacherFlags(
        teacherId: String,
        accepting: Boolean?,
        liveEnabled: Boolean?,
        canManageTests: Boolean?,
        commission: Double?,
    ) {
        Backend.rpcVoid(
            "set_teacher_flags",
            buildJsonObject {
                put("p_teacher", teacherId)
                put("p_accepting", accepting)
                put("p_live_enabled", liveEnabled)
                put("p_can_manage_tests", canManageTests)
                put("p_commission", commission)
            },
        )
    }

    // ---------- content review ----------
    suspend fun coursesForReview(status: String?): List<Course> =
        Backend.client.from("courses")
            .select(Columns.raw("*, teacher:profiles!courses_teacher_id_fkey(id, full_name, avatar_url)")) {
                filter { status?.let { eq("status", it) } }
                order("created_at", SortOrder.DESCENDING)
                limit(100)
            }
            .decodeList()

    suspend fun reviewContent(kind: String, id: String, decision: String, note: String) {
        Backend.rpcVoid(
            "review_content",
            buildJsonObject {
                put("p_kind", kind)
                put("p_id", id)
                put("p_decision", decision)
                put("p_note", note)
            },
        )
    }

    suspend fun setCourseFeatured(courseId: String, featured: Boolean) {
        Backend.client.from("courses")
            .update(buildJsonObject { put("is_featured", featured) }) { filter { eq("id", courseId) } }
    }

    suspend fun setCourseCommission(courseId: String, rate: Double?) {
        Backend.client.from("courses")
            .update(buildJsonObject { put("commission_rate", rate) }) { filter { eq("id", courseId) } }
    }

    // ---------- pricing ----------
    suspend fun countryPricing(): List<CountryPricing> =
        Backend.client.from("country_pricing").select { order("country_code", SortOrder.ASCENDING) }.decodeList()

    suspend fun saveCountryPricing(row: CountryPricing) {
        val code = row.countryCode.uppercase()
        val payload = buildJsonObject {
            put("country_code", code)
            put("currency", row.currency.uppercase())
            put("fx_multiplier", row.fxMultiplier)
            put("round_to", row.roundTo)
            put("discount_percent", row.discountPercent)
            put("region_group", row.regionGroup)
            put("is_active", row.isActive)
        }
        val existing = Backend.client.from("country_pricing")
            .select { filter { eq("country_code", code) } }
            .decodeList<CountryPricing>()
        if (existing.isEmpty()) {
            Backend.client.from("country_pricing").insert(payload)
        } else {
            Backend.client.from("country_pricing").update(payload) { filter { eq("country_code", code) } }
        }
    }

    suspend fun deleteCountryPricing(code: String) {
        Backend.client.from("country_pricing").delete { filter { eq("country_code", code) } }
    }

    // ---------- coupons ----------
    suspend fun coupons(): List<Coupon> =
        Backend.client.from("coupons").select { order("created_at", SortOrder.DESCENDING) }.decodeList()

    suspend fun saveCoupon(code: String, kind: String, amount: Double, maxUses: Int?, expiresAt: String?) {
        Backend.client.from("coupons").insert(
            buildJsonObject {
                put("code", code.uppercase())
                put("kind", kind)
                put("amount", amount)
                put("max_uses", maxUses)
                put("expires_at", expiresAt)
                put("created_by", Backend.currentUserId)
            },
        )
    }

    /** Rewrites an existing coupon. Redemptions already made keep pointing at it. */
    suspend fun updateCoupon(id: String, code: String, kind: String, amount: Double, maxUses: Int?) {
        Backend.client.from("coupons").update(
            buildJsonObject {
                put("code", code.uppercase().trim())
                put("kind", kind)
                put("amount", amount)
                put("max_uses", maxUses)
            },
        ) { filter { eq("id", id) } }
    }

    suspend fun deleteCoupon(id: String) {
        Backend.client.from("coupons").delete { filter { eq("id", id) } }
    }

    suspend fun setCouponActive(id: String, active: Boolean) {
        Backend.client.from("coupons")
            .update(buildJsonObject { put("is_active", active) }) { filter { eq("id", id) } }
    }

    // ---------- finance ----------
    suspend fun orders(status: String? = null, limit: Long = 100): List<Order> =
        Backend.client.from("orders")
            .select {
                filter { status?.let { eq("status", it) } }
                order("created_at", SortOrder.DESCENDING)
                limit(limit)
            }
            .decodeList()

    suspend fun refund(orderId: String, amount: Double, kind: String, reason: String) {
        Backend.rpcVoid(
            "process_refund",
            buildJsonObject {
                put("p_order_id", orderId)
                put("p_amount", amount)
                put("p_kind", kind)
                put("p_reason", reason)
            },
        )
    }

    suspend fun refunds(): List<RefundRow> =
        Backend.client.from("refunds").select { order("created_at", SortOrder.DESCENDING); limit(100) }.decodeList()

    suspend fun payouts(status: String? = null): List<Payout> =
        Backend.client.from("payouts")
            .select(Columns.raw("*, teacher:profiles!payouts_teacher_id_fkey(id, full_name, avatar_url)")) {
                filter { status?.let { eq("status", it) } }
                order("requested_at", SortOrder.DESCENDING)
            }
            .decodeList()

    suspend fun reviewPayout(payoutId: String, decision: String, reference: String, note: String) {
        Backend.rpcVoid(
            "review_payout",
            buildJsonObject {
                put("p_payout_id", payoutId)
                put("p_decision", decision)
                put("p_reference", reference)
                put("p_note", note)
            },
        )
    }

    // ---------- users & admins ----------
    suspend fun users(role: String? = null, search: String? = null): List<Profile> =
        Backend.client.from("profiles")
            .select {
                filter {
                    role?.let { eq("role", it) }
                    search?.takeIf { it.isNotBlank() }?.let { ilike("full_name", "%$it%") }
                }
                order("created_at", SortOrder.DESCENDING)
                limit(100)
            }
            .decodeList()

    suspend fun permissionsOf(userId: String): Set<String> =
        Backend.client.from("admin_permissions")
            .select { filter { eq("user_id", userId) } }
            .decodeList<AdminPermission>()
            .map { it.permission }
            .toSet()

    suspend fun setPermissions(userId: String, permissions: Set<String>) {
        Backend.rpcVoid(
            "set_admin_permissions",
            buildJsonObject {
                put("p_user", userId)
                put("p_permissions", JsonArray(permissions.map { JsonPrimitive(it) }))
            },
        )
    }

    /**
     * Appoints an admin, or takes the role away again (owner only).
     *
     * Permissions travel with the role: dropping someone out of `ADMIN` clears every permission
     * they held, so revoking access is a single action rather than a checklist.
     */
    suspend fun setUserRole(userId: String, role: String, reason: String = "") {
        Backend.rpcVoid(
            "set_user_role",
            buildJsonObject {
                put("p_user", userId)
                put("p_role", role)
                put("p_reason", reason.trim().takeIf { it.isNotBlank() })
            },
        )
    }

    suspend fun setUserStatus(userId: String, status: String, reason: String) {
        Backend.rpcVoid(
            "set_user_status",
            buildJsonObject {
                put("p_user", userId)
                put("p_status", status)
                put("p_reason", reason)
            },
        )
    }

    /**
     * Sends one important announcement to a whole audience.
     *
     * @return how many people it reached, so the sender sees the real result.
     */
    suspend fun broadcast(audience: String, title: String, body: String): Int {
        val result = Backend.rpcRaw(
            "broadcast_notification",
            buildJsonObject {
                put("p_audience", audience)
                put("p_kind", "ANNOUNCEMENT")
                put("p_title", title.trim())
                put("p_body", body.trim())
                put("p_data", buildJsonObject { })
            },
        )
        return runCatching {
            (result as JsonObject)["sent"]?.toString()?.trim('"')?.toIntOrNull() ?: 0
        }.getOrDefault(0)
    }

    // ---------- CMS / settings / ads ----------
    suspend fun banners(): List<Banner> =
        Backend.client.from("cms_banners").select { order("sort_order", SortOrder.ASCENDING) }.decodeList()

    suspend fun saveBanner(id: String?, title: String, subtitle: String, imageUrl: String, ctaLabel: String, ctaTarget: String, active: Boolean) {
        val payload = buildJsonObject {
            put("placement", "HOME_HERO")
            put("title", title)
            put("subtitle", subtitle.ifBlank { null })
            put("image_url", imageUrl.ifBlank { null })
            put("cta_label", ctaLabel.ifBlank { null })
            put("cta_target", ctaTarget.ifBlank { null })
            put("is_active", active)
        }
        if (id == null) {
            Backend.client.from("cms_banners").insert(payload)
        } else {
            Backend.client.from("cms_banners").update(payload) { filter { eq("id", id) } }
        }
    }

    suspend fun deleteBanner(id: String) {
        Backend.client.from("cms_banners").delete { filter { eq("id", id) } }
    }

    suspend fun categories(): List<Category> =
        Backend.client.from("categories").select { order("sort_order", SortOrder.ASCENDING) }.decodeList()

    suspend fun saveCategory(name: String, slug: String, sortOrder: Int) {
        val normalized = slug.lowercase().trim().replace(' ', '-')
        val payload = buildJsonObject {
            put("name", name)
            put("slug", normalized)
            put("sort_order", sortOrder)
        }
        val existing = Backend.client.from("categories")
            .select { filter { eq("slug", normalized) } }
            .decodeList<Category>()
        if (existing.isEmpty()) {
            Backend.client.from("categories").insert(payload)
        } else {
            Backend.client.from("categories").update(payload) { filter { eq("slug", normalized) } }
        }
    }

    suspend fun settings(): List<AppSetting> =
        Backend.client.from("app_settings").select { order("key", SortOrder.ASCENDING) }.decodeList()

    suspend fun saveSetting(key: String, rawValue: String) {
        val parsed = runCatching { Backend.json.parseToJsonElement(rawValue) }
            .getOrElse { JsonPrimitive(rawValue) }
        Backend.rpcVoid(
            "upsert_setting",
            buildJsonObject {
                put("p_key", key)
                put("p_value", parsed)
            },
        )
    }

    suspend fun adPlacements(): List<AdmobPlacement> =
        Backend.client.from("admob_placements").select { order("sort_order", SortOrder.ASCENDING) }.decodeList()

    suspend fun saveAdPlacement(id: String?, screen: String, section: String, format: String, adUnitId: String, frequency: Int, enabled: Boolean) {
        val payload = buildJsonObject {
            put("screen", screen)
            put("section", section.ifBlank { null })
            put("format", format)
            put("ad_unit_id", adUnitId)
            put("frequency", frequency)
            put("is_enabled", enabled)
        }
        if (id == null) {
            Backend.client.from("admob_placements").insert(payload)
        } else {
            Backend.client.from("admob_placements").update(payload) { filter { eq("id", id) } }
        }
    }

    suspend fun deleteAdPlacement(id: String) {
        Backend.client.from("admob_placements").delete { filter { eq("id", id) } }
    }

    // ---------- moderation, support, audit ----------
    suspend fun reviews(hidden: Boolean? = null): List<Review> =
        Backend.client.from("reviews")
            .select(Columns.raw("*, author:profiles!reviews_user_id_fkey(id, full_name, avatar_url)")) {
                filter { hidden?.let { eq("is_hidden", it) } }
                order("created_at", SortOrder.DESCENDING)
                limit(100)
            }
            .decodeList()

    suspend fun setReviewHidden(id: String, hidden: Boolean, reason: String) {
        Backend.client.from("reviews").update(
            buildJsonObject {
                put("is_hidden", hidden)
                put("hidden_by", Backend.currentUserId)
                put("hidden_reason", reason.ifBlank { null })
            },
        ) { filter { eq("id", id) } }
    }

    suspend fun deleteReview(id: String) {
        Backend.client.from("reviews").delete { filter { eq("id", id) } }
    }

    suspend fun tickets(status: String? = null): List<SupportTicket> =
        Backend.client.from("support_tickets")
            .select {
                filter { status?.let { eq("status", it) } }
                order("created_at", SortOrder.DESCENDING)
            }
            .decodeList()

    suspend fun setTicketStatus(id: String, status: String) {
        Backend.client.from("support_tickets").update(
            buildJsonObject {
                put("status", status)
                if (status == "ASSIGNED") put("assigned_to", Backend.currentUserId)
            },
        ) { filter { eq("id", id) } }
    }

    suspend fun auditLogs(): List<AuditLog> =
        Backend.client.from("audit_logs")
            .select(Columns.raw("*, actor:profiles!audit_logs_actor_id_fkey(id, full_name, avatar_url)")) {
                order("created_at", SortOrder.DESCENDING)
                limit(150)
            }
            .decodeList()

    // ---------- placement tests ----------
    suspend fun tests(): List<PlacementTest> =
        Backend.client.from("placement_tests").select {
            filter { eq("scope", "PUBLIC") }
            order("created_at", SortOrder.DESCENDING)
        }.decodeList()

    suspend fun teacherExercises(): List<PlacementTest> =
        Backend.client.from("placement_tests")
            .select(Columns.raw("*, owner:profiles!placement_tests_owner_id_fkey(id, full_name, avatar_url)")) {
                filter { eq("scope", "TEACHER") }
                order("created_at", SortOrder.DESCENDING)
            }
            .decodeList()

    suspend fun saveTest(
        id: String?,
        title: String,
        description: String,
        adaptive: Boolean,
        questionCount: Int,
        timeLimit: Int,
        passingScore: Double,
        scope: String = "PUBLIC",
    ): PlacementTest {
        val payload = buildJsonObject {
            put("title", title)
            put("description", description.ifBlank { null })
            put("is_adaptive", adaptive)
            put("question_count", questionCount)
            put("time_limit_seconds", timeLimit)
            put("passing_score", passingScore)
            put("scope", scope)
            if (id == null) put("owner_id", Backend.currentUserId)
        }
        return if (id == null) {
            Backend.client.from("placement_tests").insert(payload) { select() }.decodeSingle()
        } else {
            Backend.client.from("placement_tests").update(payload) {
                select()
                filter { eq("id", id) }
            }.decodeSingle()
        }
    }

    suspend fun setTestStatus(id: String, status: String) {
        Backend.client.from("placement_tests")
            .update(buildJsonObject { put("status", status) }) { filter { eq("id", id) } }
    }

    suspend fun deleteTest(id: String) {
        Backend.client.from("placement_tests").delete { filter { eq("id", id) } }
    }

    suspend fun questionCount(testId: String): Int =
        Backend.client.from("test_questions").select { filter { eq("test_id", testId) } }.decodeList<JsonObject>().size

    /**
     * Adds one question to a test's bank.
     *
     * Media is entirely optional: a question can be plain text, or carry any combination of an
     * image, an audio clip and a video, and the runner shows exactly what was attached.
     */
    suspend fun addQuestion(
        testId: String,
        kind: String,
        skill: String,
        difficulty: Int,
        prompt: String,
        options: List<String>,
        correctIndexes: List<Int>,
        correctText: List<String> = emptyList(),
        points: Double = 1.0,
        explanation: String = "",
        imageUrl: String = "",
        audioUrl: String = "",
        videoUrl: String = "",
    ) {
        Backend.client.from("test_questions").insert(
            buildJsonObject {
                put("test_id", testId)
                put("kind", kind)
                put("skill", skill)
                put("difficulty", difficulty)
                put("prompt", prompt.trim())
                put("options", JsonArray(options.map { JsonPrimitive(it) }))
                put("correct_indexes", JsonArray(correctIndexes.map { JsonPrimitive(it) }))
                put("correct_text", JsonArray(correctText.map { JsonPrimitive(it) }))
                put("points", points)
                put("explanation", explanation.trim().ifBlank { null })
                put("media_image_url", imageUrl.trim().ifBlank { null })
                put("media_audio_url", audioUrl.trim().ifBlank { null })
                put("media_video_url", videoUrl.trim().ifBlank { null })
            },
        )
    }

    suspend fun questions(testId: String): List<JsonObject> =
        Backend.client.from("test_questions")
            .select {
                filter { eq("test_id", testId) }
                order("difficulty", SortOrder.ASCENDING)
            }
            .decodeList()

    suspend fun deleteQuestion(id: String) {
        Backend.client.from("test_questions").delete { filter { eq("id", id) } }
    }
}
