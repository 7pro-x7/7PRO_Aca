package com.rork.pro.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** One ad slot the owner switched on for a screen. */
@Serializable
data class AdPlacement(
    val id: String? = null,
    val section: String? = null,
    val format: String = "BANNER",
    @SerialName("ad_unit_id") val adUnitId: String = "",
)

/**
 * Whether this user may see ads on this screen, and which units to request.
 *
 * Eligibility is decided entirely on the server: ads are switched off globally by the owner,
 * hidden on paid content, and never shown to someone with paid access.
 */
@Serializable
data class AdConfig(
    val enabled: Boolean = false,
    val reason: String? = null,
    val placements: List<AdPlacement> = emptyList(),
) {
    fun banner(): AdPlacement? =
        placements.firstOrNull { it.format == "BANNER" && it.adUnitId.isNotBlank() }
            .takeIf { enabled }
}

object AdsRepository {

    /** @param courseId set when the screen belongs to a course, so paid content stays ad-free. */
    suspend fun config(screen: String, courseId: String? = null): AdConfig =
        Backend.rpc(
            "ad_config",
            buildJsonObject {
                put("p_screen", screen)
                put("p_course_id", courseId)
            },
        )
}
