package com.rork.pro.data

import com.rork.pro.ui.i18n.Tr
import com.rork.pro.ui.i18n.tr
import java.io.IOException

/**
 * UI-safe representation of a failure. Never leaks internals to the screen.
 *
 * The text is stored as a bilingual [Tr] and resolved on read, so an error that is already
 * on screen re-renders in the new language the moment the user switches.
 */
data class AppError(
    val code: String,
    val phrase: Tr,
    val retryable: Boolean = true,
    val detail: String? = null,
) {
    val message: String
        get() = if (!detail.isNullOrBlank()) "${tr(phrase)} ($detail)" else tr(phrase)
}

object ErrorText {
    val offline = Tr(
        "You appear to be offline. Check your connection and try again.",
        "يبدو أنك غير متصل بالإنترنت. تحقق من اتصالك وحاول مرة أخرى.",
    )
    val unknown = Tr("Something went wrong. Please try again.", "حدث خطأ ما. يرجى المحاولة مرة أخرى.")
    val badCredentials = Tr("That email or password is not correct.", "البريد الإلكتروني أو كلمة المرور غير صحيحة.")
    val emailTaken = Tr("An account with this email already exists.", "يوجد حساب بهذا البريد الإلكتروني بالفعل.")
    val emailUnconfirmed = Tr(
        "Please confirm your email address, then sign in.",
        "يرجى تأكيد بريدك الإلكتروني ثم تسجيل الدخول.",
    )
    val googleUnavailable = Tr(
        "Google sign-in is not switched on yet. The platform owner needs to connect Google in the backend.",
        "لم يتم تفعيل تسجيل الدخول عبر Google بعد. يجب على مالك المنصة ربط Google في الخادم.",
    )
    val signInCancelled = Tr("Sign-in was cancelled.", "تم إلغاء تسجيل الدخول.")
    val weakPassword = Tr(
        "Please choose a longer password (at least 6 characters).",
        "يرجى اختيار كلمة مرور أطول (٦ أحرف على الأقل).",
    )
    val duplicate = Tr("That record already exists.", "هذا السجل موجود بالفعل.")
    val forbidden = Tr("You do not have permission to do that.", "ليس لديك صلاحية للقيام بذلك.")
    val notConfigured = Tr(
        "The backend is not configured for this build.",
        "لم يتم إعداد الخادم لهذه النسخة من التطبيق.",
    )
    val sessionExpired = Tr(
        "Your session expired. Please sign in again.",
        "انتهت جلستك. يرجى تسجيل الدخول مرة أخرى.",
    )
    val actionUnavailable = Tr(
        "This action is not available in this version of the app. Please update to the latest version.",
        "هذا الإجراء غير متاح في هذه النسخة من التطبيق. يرجى التحديث إلى أحدث نسخة.",
    )
    val offlineKeepWorking = Tr(
        "You are offline. Showing your saved data — some actions will not work until you reconnect.",
        "أنت غير متصل بالإنترنت. نعرض بياناتك المحفوظة — بعض الإجراءات لن تعمل حتى تعود الاتصال.",
    )
    val belowMinimum = Tr("You need at least %s to withdraw.", "تحتاج إلى %s على الأقل للسحب.")
    val insufficientBalance = Tr("Your available balance is only %s.", "رصيدك المتاح هو %s فقط.")
}

private val FRIENDLY: Map<String, Tr> = mapOf(
    "COURSE_NOT_AVAILABLE" to Tr("This course is no longer available.", "هذه الدورة لم تعد متاحة."),
    "TEACHER_NOT_ACCEPTING_STUDENTS" to Tr(
        "This teacher is not accepting new students right now.",
        "هذا المعلم لا يقبل طلابًا جددًا في الوقت الحالي.",
    ),
    "GROUP_FULL" to Tr(
        "This group is full. Join the waitlist to be notified when a seat opens.",
        "هذه المجموعة ممتلئة. انضم إلى قائمة الانتظار ليصلك إشعار عند توفر مقعد.",
    ),
    "GROUP_HAS_SEATS" to Tr(
        "This group still has seats — you can join directly.",
        "لا تزال هناك مقاعد في هذه المجموعة — يمكنك الانضمام مباشرة.",
    ),
    "GROUP_NOT_FOUND" to Tr("That group could not be found.", "تعذر العثور على هذه المجموعة."),
    "ALREADY_ENROLLED" to Tr("You already have access to this course.", "لديك بالفعل إمكانية الوصول إلى هذه الدورة."),
    "ACCOUNT_NOT_ACTIVE" to Tr(
        "Your account is suspended. Contact support for help.",
        "حسابك موقوف. تواصل مع الدعم للمساعدة.",
    ),
    "GATEWAY_NOT_CONFIGURED" to Tr(
        "Payments are not switched on yet. The platform owner needs to connect the payment gateway.",
        "لم يتم تفعيل المدفوعات بعد. يجب على مالك المنصة ربط بوابة الدفع.",
    ),
    "GATEWAY_UNAVAILABLE" to Tr(
        "The payment page could not be opened. Please try again.",
        "تعذر فتح صفحة الدفع. يرجى المحاولة مرة أخرى.",
    ),
    "UNAUTHORIZED" to Tr("Please sign in again to continue.", "يرجى تسجيل الدخول مرة أخرى للمتابعة."),
    "FORBIDDEN" to ErrorText.forbidden,
    "NO_COURSE_ACCESS" to Tr("You need to purchase this course first.", "عليك شراء هذه الدورة أولاً."),
    "REVIEW_REQUIRES_PURCHASE" to Tr(
        "Only students who purchased this course can review it.",
        "يمكن فقط للطلاب الذين اشتروا هذه الدورة تقييمها.",
    ),
    "REVIEW_REQUIRES_RELATIONSHIP" to Tr(
        "You can review a teacher after studying with them.",
        "يمكنك تقييم المعلم بعد الدراسة معه.",
    ),
    "ATTEMPT_LIMIT_REACHED" to Tr(
        "You have used all attempts for this test.",
        "لقد استخدمت جميع محاولاتك في هذا الاختبار.",
    ),
    "TEST_NOT_AVAILABLE" to Tr("This test is not published yet.", "لم يتم نشر هذا الاختبار بعد."),
    "TEST_HAS_NO_QUESTIONS" to Tr(
        "This test has no questions yet. The academy needs to add questions before it can be taken.",
        "لا توجد أسئلة في هذا الاختبار بعد. على الأكاديمية إضافة الأسئلة قبل إمكانية خوضه.",
    ),
    "ATTEMPT_NOT_FOUND" to Tr(
        "That attempt could not be found. Start the test again.",
        "تعذر العثور على هذه المحاولة. ابدأ الاختبار من جديد.",
    ),
    "ATTEMPT_CLOSED" to Tr(
        "This attempt is already finished. Open your result to see the score.",
        "انتهت هذه المحاولة بالفعل. افتح نتيجتك للاطلاع على الدرجة.",
    ),
    "PAYOUT_ALREADY_OPEN" to Tr("You already have a withdrawal in review.", "لديك بالفعل طلب سحب قيد المراجعة."),
    "CANNOT_MODIFY_OWNER" to Tr("The platform owner account cannot be modified.", "لا يمكن تعديل حساب مالك المنصة."),
    "REFUND_EXCEEDS_ORDER" to Tr(
        "The refund is larger than the original payment.",
        "قيمة الاسترداد أكبر من قيمة الدفعة الأصلية.",
    ),
    "ORDER_NOT_REFUNDABLE" to Tr("This order cannot be refunded.", "لا يمكن استرداد قيمة هذا الطلب."),
    "TARGET_NOT_TEACHER" to Tr("The selected account is not an approved teacher.", "الحساب المحدد ليس معلمًا معتمدًا."),
    "COURSE_NEEDS_TITLE" to Tr(
        "Give the course a title before publishing it.",
        "أضف عنوانًا للدورة قبل نشرها.",
    ),
    "COURSE_NEEDS_LESSON" to Tr(
        "Add at least one lesson before publishing this course.",
        "أضف درسًا واحدًا على الأقل قبل نشر هذه الدورة.",
    ),
    "COURSE_HAS_STUDENTS" to Tr(
        "Students are enrolled in this course, so it cannot be deleted. Archive it instead.",
        "يوجد طلاب ملتحقون بهذه الدورة، لذلك لا يمكن حذفها. أرشفها بدلاً من ذلك.",
    ),
    "COURSE_HAS_ORDERS" to Tr(
        "This course has paid orders, so it cannot be deleted. Archive it instead.",
        "لهذه الدورة طلبات مدفوعة، لذلك لا يمكن حذفها. أرشفها بدلاً من ذلك.",
    ),
    "COURSE_NOT_FOUND" to Tr("That course could not be found.", "تعذر العثور على هذه الدورة."),
    "FILE_TOO_LARGE" to Tr(
        "That file is larger than the 50 MB upload limit. Paste a link instead.",
        "حجم هذا الملف أكبر من حد الرفع البالغ ٥٠ ميجابايت. الصق رابطًا بدلاً من ذلك.",
    ),
    "FILE_UNREADABLE" to Tr(
        "That file could not be read. Please pick another one.",
        "تعذر قراءة هذا الملف. يرجى اختيار ملف آخر.",
    ),
)

/** Maps any throwable into a stable, human-readable error. */
fun Throwable.toAppError(): AppError {
    val raw = message ?: "Something went wrong."

    if (this is IOException || raw.contains("Unable to resolve host") || raw.contains("timeout", true) ||
        raw.contains("Failed to connect", true) || raw.contains("Network", true)
    ) {
        return AppError("OFFLINE", ErrorText.offline, true)
    }

    FRIENDLY.keys.firstOrNull { raw.contains(it) }?.let { key ->
        val extra = raw.substringAfter("$key:", "").takeWhile { it != '"' && it != '\n' }.trim()
        return AppError(
            code = key,
            phrase = FRIENDLY.getValue(key),
            retryable = key !in setOf("FORBIDDEN", "ALREADY_ENROLLED"),
            detail = extra.takeIf { it.isNotBlank() },
        )
    }

    if (raw.contains("BELOW_MINIMUM")) {
        val min = raw.substringAfter("BELOW_MINIMUM:").takeWhile { it.isDigit() || it == '.' }
        return AppError("BELOW_MINIMUM", formatted(ErrorText.belowMinimum, min), false)
    }
    if (raw.contains("INSUFFICIENT_BALANCE")) {
        val bal = raw.substringAfter("INSUFFICIENT_BALANCE:").takeWhile { it.isDigit() || it == '.' }
        return AppError("INSUFFICIENT_BALANCE", formatted(ErrorText.insufficientBalance, bal), false)
    }
    if (raw.contains("Invalid login credentials", true)) {
        return AppError("BAD_CREDENTIALS", ErrorText.badCredentials, false)
    }
    if (raw.contains("User already registered", true)) {
        return AppError("EMAIL_TAKEN", ErrorText.emailTaken, false)
    }
    if (raw.contains("Email not confirmed", true)) {
        return AppError("EMAIL_UNCONFIRMED", ErrorText.emailUnconfirmed, false)
    }
    // Supabase answers this way when the Google provider has not been configured on the project.
    if (raw.contains("provider is not enabled", true) || raw.contains("Unsupported provider", true)) {
        return AppError("GOOGLE_UNAVAILABLE", ErrorText.googleUnavailable, false)
    }
    if (raw.contains("Password should be", true)) {
        return AppError("WEAK_PASSWORD", ErrorText.weakPassword, false)
    }
    if (raw.contains("duplicate key", true)) {
        return AppError("DUPLICATE", ErrorText.duplicate, false)
    }
    if (raw.contains("row-level security", true) || raw.contains("permission denied", true)) {
        return AppError("FORBIDDEN", ErrorText.forbidden, false)
    }
    // The server rejected the call shape itself (renamed or re-signed function).
    // Surfacing it as "unknown" hides a real defect, so name it explicitly.
    if (raw.contains("PGRST202") || raw.contains("schema cache", true)) {
        return AppError("ACTION_UNAVAILABLE", ErrorText.actionUnavailable, false)
    }
    return AppError("UNKNOWN", ErrorText.unknown, true)
}

/** Builds a bilingual phrase with a runtime value substituted into both translations. */
private fun formatted(phrase: Tr, value: String): Tr =
    Tr(phrase.en.replace("%s", value), phrase.ar.replace("%s", value))

/** Simple async state holder used across every screen. */
sealed interface Async<out T> {
    data object Loading : Async<Nothing>
    data class Success<T>(val value: T) : Async<T>
    data class Failure(val error: AppError) : Async<Nothing>
}

inline fun <T> Async<T>.valueOrNull(): T? = (this as? Async.Success<T>)?.value
