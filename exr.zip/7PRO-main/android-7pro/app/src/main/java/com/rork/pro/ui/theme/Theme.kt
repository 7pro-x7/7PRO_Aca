package com.rork.pro.ui.theme

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.rork.pro.ui.i18n.AppLanguage

/** How 7PRO decides between its night and day palettes. */
enum class ThemeMode(val key: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    companion object {
        fun fromKey(key: String?): ThemeMode = entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

/**
 * Holds the chosen appearance for the whole app.
 *
 * [dark] is Compose state, so every `Ink` colour re-reads it and the entire UI repaints the
 * instant the user flips the switch — no restart, no screen rebuild.
 */
object AppAppearance {

    private const val PREFS = "7pro.prefs"
    private const val KEY_THEME = "theme_mode"

    var mode: ThemeMode by mutableStateOf(ThemeMode.SYSTEM)
        private set

    /** Resolved appearance. Follows the device until the user picks a side. */
    var dark: Boolean by mutableStateOf(true)
        internal set

    fun init(context: Context) {
        mode = ThemeMode.fromKey(prefs(context).getString(KEY_THEME, null))
    }

    fun set(context: Context, value: ThemeMode) {
        mode = value
        prefs(context).edit().putString(KEY_THEME, value.key).apply()
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}

/**
 * "Night Academy" — 7PRO's visual identity, in both appearances.
 *
 * Amber stays the one accent in either mode; only the surfaces and text invert, so the brand
 * reads the same by day and by night.
 */
object Ink {
    private val dark: Boolean get() = AppAppearance.dark

    val Canvas: Color get() = if (dark) Color(0xFF0B1220) else Color(0xFFF6F7FA)
    val Surface: Color get() = if (dark) Color(0xFF16202F) else Color(0xFFFFFFFF)
    val SurfaceHigh: Color get() = if (dark) Color(0xFF1D2939) else Color(0xFFECEFF5)
    val Hairline: Color get() = if (dark) Color(0xFF26344A) else Color(0xFFDCE2EC)

    val TextPrimary: Color get() = if (dark) Color(0xFFF1F5F9) else Color(0xFF0B1220)
    val TextSecondary: Color get() = if (dark) Color(0xFF8FA3BC) else Color(0xFF4C5D75)
    val TextMuted: Color get() = if (dark) Color(0xFF62748E) else Color(0xFF77869C)

    val Amber: Color get() = if (dark) Color(0xFFF5A623) else Color(0xFFB4780B)
    val AmberPressed: Color get() = if (dark) Color(0xFFC77F12) else Color(0xFF8E5E06)
    val AmberSoft: Color get() = if (dark) Color(0x1FF5A623) else Color(0x24F5A623)

    val Teal: Color get() = if (dark) Color(0xFF2DD4BF) else Color(0xFF0E8C7C)
    val TealSoft: Color get() = if (dark) Color(0x1F2DD4BF) else Color(0x242DD4BF)
    val Coral: Color get() = if (dark) Color(0xFFF97066) else Color(0xFFD5372A)
    val CoralSoft: Color get() = if (dark) Color(0x1FF97066) else Color(0x24F97066)
    val Sky: Color get() = if (dark) Color(0xFF57A9FF) else Color(0xFF1B6ED0)
    val SkySoft: Color get() = if (dark) Color(0x1F57A9FF) else Color(0x2457A9FF)

    /** Second stop of the app background wash, a touch deeper than the canvas. */
    val CanvasDeep: Color get() = if (dark) Color(0xFF0D1626) else Color(0xFFEDF0F6)

    /** Contrast colour for text and icons drawn on top of amber. */
    val OnAmber: Color get() = if (dark) Color(0xFF1A1206) else Color(0xFFFFFFFF)
}

private fun sevenProColors(dark: Boolean) = if (dark) {
    darkColorScheme(
        primary = Ink.Amber,
        onPrimary = Ink.OnAmber,
        primaryContainer = Ink.AmberSoft,
        onPrimaryContainer = Ink.Amber,
        secondary = Ink.Teal,
        onSecondary = Color(0xFF04211D),
        secondaryContainer = Ink.TealSoft,
        onSecondaryContainer = Ink.Teal,
        tertiary = Ink.Sky,
        background = Ink.Canvas,
        onBackground = Ink.TextPrimary,
        surface = Ink.Surface,
        onSurface = Ink.TextPrimary,
        surfaceVariant = Ink.SurfaceHigh,
        onSurfaceVariant = Ink.TextSecondary,
        surfaceContainer = Ink.Surface,
        surfaceContainerHigh = Ink.SurfaceHigh,
        surfaceContainerHighest = Ink.SurfaceHigh,
        surfaceContainerLow = Ink.Surface,
        surfaceContainerLowest = Ink.Canvas,
        outline = Ink.Hairline,
        outlineVariant = Ink.Hairline,
        error = Ink.Coral,
        onError = Color(0xFF2A0B08),
        errorContainer = Ink.CoralSoft,
        onErrorContainer = Ink.Coral,
        scrim = Color(0xCC060B14),
    )
} else {
    lightColorScheme(
        primary = Ink.Amber,
        onPrimary = Ink.OnAmber,
        primaryContainer = Ink.AmberSoft,
        onPrimaryContainer = Ink.Amber,
        secondary = Ink.Teal,
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Ink.TealSoft,
        onSecondaryContainer = Ink.Teal,
        tertiary = Ink.Sky,
        background = Ink.Canvas,
        onBackground = Ink.TextPrimary,
        surface = Ink.Surface,
        onSurface = Ink.TextPrimary,
        surfaceVariant = Ink.SurfaceHigh,
        onSurfaceVariant = Ink.TextSecondary,
        surfaceContainer = Ink.Surface,
        surfaceContainerHigh = Ink.SurfaceHigh,
        surfaceContainerHighest = Ink.SurfaceHigh,
        surfaceContainerLow = Ink.Surface,
        surfaceContainerLowest = Ink.Canvas,
        outline = Ink.Hairline,
        outlineVariant = Ink.Hairline,
        error = Ink.Coral,
        onError = Color(0xFFFFFFFF),
        errorContainer = Ink.CoralSoft,
        onErrorContainer = Ink.Coral,
        scrim = Color(0x99101828),
    )
}

private val SevenProTypography = Typography(
    displayLarge = TextStyle(fontSize = 44.sp, lineHeight = 48.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp),
    displaySmall = TextStyle(fontSize = 32.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp),
    headlineSmall = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontSize = 19.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.5.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, textAlign = TextAlign.Start),
)

object Dimens {
    val screenPadding = 20.dp
    val cardRadius = 20.dp
    val chipRadius = 999.dp
    val gap = 12.dp
    val sectionGap = 26.dp
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (AppAppearance.mode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    AppAppearance.dark = dark

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            // Light appearance needs dark status/navigation icons to stay readable.
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    // Layout direction follows the language, so Arabic mirrors the entire UI.
    CompositionLocalProvider(LocalLayoutDirection provides AppLanguage.current.layoutDirection) {
        MaterialTheme(
            colorScheme = sevenProColors(dark),
            typography = SevenProTypography,
            content = content,
        )
    }
}
