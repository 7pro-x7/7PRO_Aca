package com.rork.pro.ui.screens.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.rork.pro.data.AdminRepository
import com.rork.pro.data.AppError
import com.rork.pro.data.Async
import com.rork.pro.data.PlacementTest
import com.rork.pro.data.toAppError
import com.rork.pro.ui.components.ConfirmDialog
import com.rork.pro.ui.components.EmptyBlock
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.PrimaryAction
import com.rork.pro.ui.components.Refreshable
import com.rork.pro.ui.components.SecondaryAction
import com.rork.pro.ui.components.StatusPill
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.screens.auth.InkField
import com.rork.pro.ui.screens.test.TestMediaField
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import com.rork.pro.ui.i18n.StrAdmin
import com.rork.pro.ui.i18n.StrTeacher
import com.rork.pro.ui.i18n.tr
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private data class AdminExercisesData(
    val exercises: List<PlacementTest>,
    val counts: Map<String, Int>,
)

private class AdminExercisesViewModel : ViewModel() {
    private val _state = kotlinx.coroutines.flow.MutableStateFlow<Async<AdminExercisesData>>(Async.Loading)
    val state: kotlinx.coroutines.flow.StateFlow<Async<AdminExercisesData>> = _state.asStateFlow()
    private val _error = kotlinx.coroutines.flow.MutableStateFlow<AppError?>(null)
    val error: kotlinx.coroutines.flow.StateFlow<AppError?> = _error.asStateFlow()
    private val _busy = kotlinx.coroutines.flow.MutableStateFlow(false)
    val busy: kotlinx.coroutines.flow.StateFlow<Boolean> = _busy.asStateFlow()
    private val _refreshing = kotlinx.coroutines.flow.MutableStateFlow(false)
    val refreshing: kotlinx.coroutines.flow.StateFlow<Boolean> = _refreshing.asStateFlow()

    init { load() }

    fun load(quiet: Boolean = false) {
        viewModelScope.launch {
            if (!quiet) _state.value = Async.Loading
            runCatching {
                val exercises = AdminRepository.teacherExercises()
                AdminExercisesData(exercises, exercises.associate { it.id to AdminRepository.questionCount(it.id) })
            }.onSuccess { _state.value = Async.Success(it) }
                .onFailure { if (!quiet) _state.value = Async.Failure(it.toAppError()) }
            _refreshing.value = false
        }
    }

    fun refresh() {
        _refreshing.value = true
        load(quiet = true)
    }

    fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            runCatching { block() }.onFailure { _error.value = it.toAppError() }
            _busy.value = false
            load()
        }
    }

    fun clearError() { _error.value = null }
}

@Composable
fun AdminExercisesScreen(navController: NavHostController) {
    val vm: AdminExercisesViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()

    var editingId by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var questionCount by remember { mutableStateOf("10") }
    var minutes by remember { mutableStateOf("15") }
    var questionFor by remember { mutableStateOf<String?>(null) }
    var prompt by remember { mutableStateOf("") }
    var options by remember { mutableStateOf("") }
    var correct by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var audioUrl by remember { mutableStateOf("") }
    var videoUrl by remember { mutableStateOf("") }
    var mediaError by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<PlacementTest?>(null) }

    fun clearForm() {
        editingId = null; title = ""; description = ""; questionCount = "10"; minutes = "15"
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        DetailHeader(tr(StrAdmin.teacherExercises), onBack = { navController.popBackStack() })
        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load() }
            is Async.Success -> Refreshable(refreshing, { vm.refresh() }) {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = Dimens.screenPadding, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Text(tr(StrAdmin.teacherExercisesSub), color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(10.dp))
                        InkCard(borderColor = Ink.Amber.copy(alpha = 0.3f)) {
                            Text(if (editingId == null) tr(StrTeacher.newExercise) else tr(StrAdmin.editExercise), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(12.dp))
                            InkField(title, { title = it }, tr(StrAdmin.titleField))
                            Spacer(Modifier.height(8.dp))
                            InkField(description, { description = it }, tr(StrAdmin.descriptionField), singleLine = false, minLines = 2)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(Modifier.weight(1f)) {
                                    InkField(questionCount, { questionCount = it.filter(Char::isDigit) }, tr(StrAdmin.questions), keyboardType = KeyboardType.Number)
                                }
                                Box(Modifier.weight(1f)) {
                                    InkField(minutes, { minutes = it.filter(Char::isDigit) }, tr(StrAdmin.minutes), keyboardType = KeyboardType.Number)
                                }
                            }
                            error?.let {
                                Spacer(Modifier.height(8.dp))
                                Text(it.message, color = Ink.Coral, style = MaterialTheme.typography.bodySmall)
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PrimaryAction(
                                    if (editingId == null) tr(StrTeacher.createExercise) else tr(StrAdmin.saveTest),
                                    Modifier.weight(1f),
                                    enabled = title.isNotBlank(),
                                    loading = busy,
                                ) {
                                    vm.act {
                                        AdminRepository.saveTest(
                                            editingId,
                                            title,
                                            description,
                                            false,
                                            questionCount.toIntOrNull() ?: 10,
                                            (minutes.toIntOrNull() ?: 15) * 60,
                                            50.0,
                                            "TEACHER",
                                        )
                                    }
                                    clearForm()
                                }
                                if (editingId != null) SecondaryAction(tr(StrTeacher.cancel), Modifier.weight(1f)) { clearForm() }
                            }
                        }
                    }
                    if (s.value.exercises.isEmpty()) {
                        item { EmptyBlock(tr(StrAdmin.noTeacherExercises), tr(StrAdmin.noTeacherExercisesBody)) }
                    }
                    items(s.value.exercises, key = { it.id }) { exercise ->
                        val count = s.value.counts[exercise.id] ?: 0
                        InkCard(borderColor = if (exercise.status == "PUBLISHED") Ink.Teal.copy(alpha = 0.5f) else Ink.Hairline) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text(exercise.title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        "${tr(StrAdmin.ownerLabel)}: ${exercise.owner?.fullName ?: exercise.ownerId.orEmpty()}",
                                        color = Ink.TextMuted,
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                                StatusPill(exercise.status)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("${tr(StrAdmin.questionsInBank)}: $count / ${exercise.questionCount}", color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SecondaryAction(tr(StrAdmin.editExercise), Modifier.weight(1f)) {
                                    editingId = exercise.id
                                    title = exercise.title
                                    description = exercise.description.orEmpty()
                                    questionCount = exercise.questionCount.toString()
                                    minutes = (exercise.timeLimitSeconds / 60).coerceAtLeast(1).toString()
                                }
                                SecondaryAction(tr(StrAdmin.deleteExercise), Modifier.weight(1f), tint = Ink.Coral) { deleteTarget = exercise }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SecondaryAction(
                                    if (exercise.status == "PUBLISHED") tr(StrAdmin.unpublish) else tr(StrAdmin.publish),
                                    Modifier.weight(1f),
                                    enabled = exercise.status == "PUBLISHED" || count > 0,
                                ) {
                                    vm.act {
                                        AdminRepository.setTestStatus(
                                            exercise.id,
                                            if (exercise.status == "PUBLISHED") "DRAFT" else "PUBLISHED",
                                        )
                                    }
                                }
                                SecondaryAction(
                                    if (questionFor == exercise.id) tr(StrAdmin.close) else tr(StrAdmin.addQuestion),
                                    Modifier.weight(1f),
                                ) { questionFor = if (questionFor == exercise.id) null else exercise.id }
                            }
                            if (questionFor == exercise.id) {
                                Spacer(Modifier.height(12.dp))
                                InkField(prompt, { prompt = it }, tr(StrAdmin.question), singleLine = false, minLines = 2)
                                Spacer(Modifier.height(8.dp))
                                InkField(options, { options = it }, tr(StrAdmin.optionsCommaSeparated))
                                Spacer(Modifier.height(8.dp))
                                InkField(correct, { correct = it.filter(Char::isDigit) }, tr(StrAdmin.correctOptionNumber), keyboardType = KeyboardType.Number)
                                Spacer(Modifier.height(10.dp))
                                TestMediaField(tr(StrTeacher.image), imageUrl, { imageUrl = it }, "image/*", "exercises/${exercise.id}", tr(StrTeacher.chooseFromPhone), onError = { mediaError = it })
                                TestMediaField(tr(StrTeacher.audio), audioUrl, { audioUrl = it }, "audio/*", "exercises/${exercise.id}", tr(StrTeacher.chooseFromPhone), onError = { mediaError = it })
                                TestMediaField(tr(StrTeacher.video), videoUrl, { videoUrl = it }, "video/*", "exercises/${exercise.id}", tr(StrTeacher.chooseFromPhone), onError = { mediaError = it })
                                if (mediaError.isNotBlank()) Text(mediaError, color = Ink.Coral, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(10.dp))
                                PrimaryAction(
                                    tr(StrAdmin.addQuestion),
                                    enabled = prompt.isNotBlank() && options.split(",").count { it.isNotBlank() } >= 2 && correct.isNotBlank(),
                                    loading = busy,
                                ) {
                                    val list = options.split(",").map { it.trim() }.filter { it.isNotBlank() }
                                    vm.act {
                                        AdminRepository.addQuestion(
                                            exercise.id,
                                            "SINGLE",
                                            "GENERAL",
                                            3,
                                            prompt,
                                            list,
                                            listOf(((correct.toIntOrNull() ?: 1) - 1).coerceIn(0, list.lastIndex)),
                                            imageUrl = imageUrl,
                                            audioUrl = audioUrl,
                                            videoUrl = videoUrl,
                                        )
                                    }
                                    prompt = ""; options = ""; correct = ""; imageUrl = ""; audioUrl = ""; videoUrl = ""; mediaError = ""
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteTarget?.let { exercise ->
        ConfirmDialog(
            tr(StrAdmin.deleteExercise),
            tr(StrAdmin.deleteExerciseConfirm),
            tr(StrAdmin.deleteExercise),
            onDismiss = { deleteTarget = null },
            onConfirm = {
                vm.act { AdminRepository.deleteTest(exercise.id) }
                deleteTarget = null
                if (editingId == exercise.id) clearForm()
            },
            destructive = true,
        )
    }
}