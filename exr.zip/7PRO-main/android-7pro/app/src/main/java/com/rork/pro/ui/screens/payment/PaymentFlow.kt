package com.rork.pro.ui.screens.payment

import android.annotation.SuppressLint
import android.content.Intent
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.net.toUri
import com.rork.pro.data.CommerceRepository
import com.rork.pro.data.PaymentMethod
import com.rork.pro.ui.components.PrimaryAction
import com.rork.pro.ui.components.SecondaryAction
import com.rork.pro.ui.components.formatMoney
import com.rork.pro.ui.i18n.StrPay
import com.rork.pro.ui.i18n.Tr
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.delay

/** What the learner is about to pay for, as priced by the server. */
data class PaymentSummary(
    val title: String,
    val listPrice: Double,
    val discount: Double,
    val total: Double,
    val currency: String,
)

private data class MethodLook(val icon: ImageVector, val name: Tr, val sub: Tr)

private fun lookOf(kind: String): MethodLook? = when (kind) {
    "CARD" -> MethodLook(Icons.Default.CreditCard, StrPay.methodCard, StrPay.methodCardSub)
    "WALLET" -> MethodLook(Icons.Default.AccountBalanceWallet, StrPay.methodWallet, StrPay.methodWalletSub)
    "INSTAPAY" -> MethodLook(Icons.Default.AccountBalance, StrPay.methodInstapay, StrPay.methodInstapaySub)
    "MEEZA" -> MethodLook(Icons.Default.Payments, StrPay.methodMeeza, StrPay.methodMeezaSub)
    "KIOSK" -> MethodLook(Icons.Default.Storefront, StrPay.methodKiosk, StrPay.methodKioskSub)
    "INSTALLMENT" -> MethodLook(Icons.Default.Schedule, StrPay.methodInstallment, StrPay.methodInstallmentSub)
    else -> null
}

/**
 * The 7PRO payment sheet.
 *
 * Every option here is read from the platform's own gateway account, so the learner sees exactly
 * the methods that can really be charged — card, mobile wallet, InstaPay, Meeza, kiosk — and
 * nothing that would fail at the gateway. When the account exposes only its default integration
 * the list is empty and the sheet simply confirms the amount.
 */
@Composable
fun PaymentSheet(
    summary: PaymentSummary,
    working: Boolean,
    onDismiss: () -> Unit,
    onPay: (String?) -> Unit,
) {
    var methods by remember { mutableStateOf<List<PaymentMethod>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(summary.currency) {
        loading = true
        runCatching { CommerceRepository.paymentMethods(summary.currency) }
            .onSuccess { list ->
                methods = list
                selected = list.firstOrNull { it.kind == "CARD" }?.id ?: list.firstOrNull()?.id
            }
        loading = false
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Ink.Canvas, Ink.CanvasDeep)))
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = tr(StrPay.cancelPayment), tint = Ink.TextPrimary)
                }
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Ink.Amber, fontWeight = FontWeight.Black)) { append("7") }
                        withStyle(SpanStyle(color = Ink.TextPrimary, fontWeight = FontWeight.Black)) { append("PRO") }
                    },
                    fontSize = 19.sp,
                )
                Spacer(Modifier.width(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        tint = Ink.Teal,
                        modifier = Modifier.size(13.dp),
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(tr(StrPay.checkoutTitle), color = Ink.Teal, style = MaterialTheme.typography.bodySmall)
                }
            }

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = Dimens.screenPadding),
            ) {
                Text(
                    tr(StrPay.title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = Ink.TextPrimary,
                )

                Spacer(Modifier.height(16.dp))
                SummaryCard(summary)

                Spacer(Modifier.height(20.dp))
                Text(tr(StrPay.chooseMethod), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))

                when {
                    loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Ink.Amber)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            tr(StrPay.loadingMethods),
                            color = Ink.TextSecondary,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }

                    methods.isEmpty() -> Text(
                        tr(StrPay.securedBy),
                        color = Ink.TextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                    )

                    else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        methods.forEach { method ->
                            MethodRow(method, method.id == selected) { selected = method.id }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
            }

            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Dimens.screenPadding)
                    .padding(bottom = 14.dp),
            ) {
                PrimaryAction(
                    trf(StrPay.payNow, formatMoney(summary.total, summary.currency)),
                    enabled = !loading,
                    loading = working,
                ) { onPay(selected) }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        tint = Ink.TextMuted,
                        modifier = Modifier.size(13.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        tr(StrPay.securedBy),
                        color = Ink.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(summary: PaymentSummary) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Ink.Surface)
            .border(1.dp, Ink.Hairline, RoundedCornerShape(18.dp))
            .padding(16.dp),
    ) {
        Text(tr(StrPay.orderSummary), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(6.dp))
        Text(summary.title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium, maxLines = 2)

        Spacer(Modifier.height(14.dp))
        AmountRow(tr(StrPay.listPrice), formatMoney(summary.listPrice, summary.currency), Ink.TextSecondary)
        if (summary.discount > 0) {
            Spacer(Modifier.height(6.dp))
            AmountRow(tr(StrPay.discount), "− ${formatMoney(summary.discount, summary.currency)}", Ink.Teal)
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Ink.Hairline))
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(tr(StrPay.totalDue), color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
            Text(
                formatMoney(summary.total, summary.currency),
                color = Ink.Amber,
                style = MaterialTheme.typography.headlineSmall,
            )
        }
    }
}

@Composable
private fun AmountRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = color, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun MethodRow(method: PaymentMethod, selected: Boolean, onSelect: () -> Unit) {
    val look = lookOf(method.kind)
    val scale by animateFloatAsState(if (selected) 1f else 0.995f, tween(140), label = "method")

    Row(
        Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Ink.AmberSoft else Ink.Surface)
            .border(
                1.dp,
                if (selected) Ink.Amber else Ink.Hairline,
                RoundedCornerShape(16.dp),
            )
            .clickable(onClick = onSelect)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (selected) Ink.Amber else Ink.SurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                look?.icon ?: Icons.Default.Payments,
                contentDescription = null,
                tint = if (selected) Ink.OnAmber else Ink.TextSecondary,
                modifier = Modifier.size(21.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                look?.let { tr(it.name) } ?: method.label,
                color = Ink.TextPrimary,
                style = MaterialTheme.typography.titleSmall,
            )
            Text(
                look?.let { tr(it.sub) } ?: method.label,
                color = Ink.TextMuted,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
            )
        }
        Box(
            Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (selected) Ink.Amber else Color.Transparent)
                .border(1.dp, if (selected) Ink.Amber else Ink.Hairline, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Ink.OnAmber,
                    modifier = Modifier.size(14.dp),
                )
            }
        }
    }
}

/**
 * The gateway's own payment page, hosted inside 7PRO.
 *
 * Payment is only ever confirmed by the server: the page is watched purely for progress, while
 * the order itself is polled until the verified webhook marks it paid. That keeps a page that
 * merely *looks* successful from unlocking anything.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HostedCheckout(
    url: String,
    orderId: String,
    onDone: (Boolean) -> Unit,
) {
    var progress by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("PENDING") }
    val context = LocalContext.current

    LaunchedEffect(orderId) {
        if (orderId.isBlank()) return@LaunchedEffect
        while (status == "PENDING") {
            delay(3000)
            val order = runCatching { CommerceRepository.order(orderId) }.getOrNull()
            status = order?.status ?: status
        }
    }

    Dialog(
        onDismissRequest = { onDone(status == "PAID") },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Ink.Canvas)
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { onDone(status == "PAID") }) {
                    Icon(Icons.Default.Close, contentDescription = tr(StrPay.cancelPayment), tint = Ink.TextPrimary)
                }
                Column(Modifier.weight(1f)) {
                    Text(tr(StrPay.checkoutTitle), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                    Text(
                        tr(StrPay.doNotClose),
                        color = Ink.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                    )
                }
                Icon(
                    Icons.Default.Lock,
                    contentDescription = null,
                    tint = Ink.Teal,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(end = 2.dp),
                )
                Spacer(Modifier.width(10.dp))
            }

            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = Ink.Amber,
                    trackColor = Ink.SurfaceHigh,
                )
            }

            Box(Modifier.weight(1f)) {
                when (status) {
                    "PAID" -> ResultPanel(
                        success = true,
                        onPrimary = { onDone(true) },
                    )

                    "PENDING" -> AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { viewContext ->
                            WebView(viewContext).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                )
                                webViewClient = WebViewClient()
                                webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                        progress = newProgress
                                    }
                                }
                                with(settings) {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    loadWithOverviewMode = true
                                    useWideViewPort = true
                                }
                                loadUrl(url)
                            }
                        },
                        onRelease = { view ->
                            view.loadUrl("about:blank")
                            view.destroy()
                        },
                    )

                    else -> ResultPanel(success = false, onPrimary = { onDone(false) })
                }
            }

            if (status == "PENDING") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = Dimens.screenPadding, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = Ink.Amber)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        tr(StrPay.waitingConfirmation),
                        color = Ink.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        tr(StrPay.openInBrowser),
                        color = Ink.TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.clickable {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, url.toUri())) }
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun ResultPanel(success: Boolean, onPrimary: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = Dimens.screenPadding),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(if (success) Ink.TealSoft else Ink.CoralSoft),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (success) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = if (success) Ink.Teal else Ink.Coral,
                modifier = Modifier.size(44.dp),
            )
        }
        Spacer(Modifier.height(20.dp))
        Text(
            tr(if (success) StrPay.paymentConfirmed else StrPay.paymentFailed),
            style = MaterialTheme.typography.headlineSmall,
            color = Ink.TextPrimary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            tr(if (success) StrPay.accessUnlocked else StrPay.paymentFailedBody),
            color = Ink.TextSecondary,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(26.dp))
        if (success) {
            PrimaryAction(tr(StrPay.startLearning), onClick = onPrimary)
        } else {
            SecondaryAction(tr(StrPay.tryAgain), Modifier.fillMaxWidth(), onClick = onPrimary)
        }
    }
}
