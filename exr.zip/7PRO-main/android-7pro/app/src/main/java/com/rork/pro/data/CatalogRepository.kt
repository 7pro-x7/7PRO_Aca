package com.rork.pro.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

private const val TEACHER_JOIN = "teacher:profiles!courses_teacher_id_fkey(id, full_name, avatar_url)"

/** Read access to the published catalogue: banners, categories, courses and teachers. */
object CatalogRepository {

    suspend fun banners(placement: String = "HOME_HERO"): List<Banner> =
        Backend.client.from("cms_banners")
            .select {
                filter {
                    eq("placement", placement)
                    eq("is_active", true)
                }
                order("sort_order", Order.ASCENDING)
            }
            .decodeList()

    suspend fun categories(): List<Category> =
        Backend.client.from("categories")
            .select {
                filter { eq("is_active", true) }
                order("sort_order", Order.ASCENDING)
            }
            .decodeList()

    suspend fun publishedCourses(
        categoryId: String? = null,
        level: String? = null,
        search: String? = null,
        featuredOnly: Boolean = false,
        limit: Long = 40,
    ): List<Course> =
        Backend.client.from("courses")
            .select(Columns.raw("*, $TEACHER_JOIN")) {
                filter {
                    eq("status", "PUBLISHED")
                    categoryId?.let { eq("category_id", it) }
                    level?.let { eq("level", it) }
                    if (featuredOnly) eq("is_featured", true)
                    search?.takeIf { it.isNotBlank() }?.let { ilike("title", "%$it%") }
                }
                order("is_featured", Order.DESCENDING)
                order("rating_avg", Order.DESCENDING)
                limit(limit)
            }
            .decodeList()

    suspend fun course(id: String): Course? =
        Backend.client.from("courses")
            .select(Columns.raw("*, $TEACHER_JOIN")) { filter { eq("id", id) } }
            .decodeSingleOrNull()

    suspend fun lessons(courseId: String): List<Lesson> =
        Backend.client.from("lessons")
            .select {
                filter { eq("course_id", courseId) }
                order("sort_order", Order.ASCENDING)
            }
            .decodeList()

    /** Curriculum sections used to group the lesson list. Empty for courses that never used them. */
    suspend fun courseSections(courseId: String): List<CourseSection> =
        Backend.client.from("course_sections")
            .select {
                filter { eq("course_id", courseId) }
                order("sort_order", Order.ASCENDING)
            }
            .decodeList()

    suspend fun trackCourseView(courseId: String) {
        runCatching { Backend.rpcVoid("track_course_view", buildJsonObject { put("p_course_id", courseId) }) }
    }

    /** Only OWNER-approved teachers who are open for new students are bookable. */
    suspend fun bookableTeachers(level: String? = null): List<TeacherProfile> =
        Backend.client.from("teacher_profiles")
            .select(Columns.raw("*, profile:profiles!teacher_profiles_id_fkey(id, full_name, avatar_url)")) {
                filter {
                    eq("status", "APPROVED")
                    eq("accepting_new_students", true)
                    level?.let { contains("subjects", listOf(it)) }
                }
                order("rating_avg", Order.DESCENDING)
            }
            .decodeList()

    suspend fun teacherProfile(teacherId: String): TeacherProfile? =
        Backend.client.from("teacher_profiles")
            .select(Columns.raw("*, profile:profiles!teacher_profiles_id_fkey(id, full_name, avatar_url)")) {
                filter { eq("id", teacherId) }
            }
            .decodeSingleOrNull()

    suspend fun teacherCourses(teacherId: String): List<Course> =
        Backend.client.from("courses")
            .select(Columns.raw("*, $TEACHER_JOIN")) {
                filter {
                    eq("teacher_id", teacherId)
                    eq("status", "PUBLISHED")
                }
                order("rating_avg", Order.DESCENDING)
            }
            .decodeList()

    suspend fun reviewsFor(
        teacherId: String? = null,
        courseId: String? = null,
        limit: Long = 20,
    ): List<Review> =
        Backend.client.from("reviews")
            .select(Columns.raw("*, author:profiles!reviews_user_id_fkey(id, full_name, avatar_url)")) {
                filter {
                    eq("is_hidden", false)
                    teacherId?.let { eq("teacher_id", it) }
                    courseId?.let { eq("course_id", it) }
                }
                order("created_at", Order.DESCENDING)
                limit(limit)
            }
            .decodeList()

    suspend fun submitReview(
        targetType: String,
        rating: Int,
        body: String,
        teacherId: String? = null,
        courseId: String? = null,
    ) {
        val userId = Backend.currentUserId ?: error("UNAUTHORIZED")
        Backend.client.from("reviews").insert(
            buildJsonObject {
                put("user_id", userId)
                put("target_type", targetType)
                put("rating", rating)
                put("body", body)
                teacherId?.let { put("teacher_id", it) }
                courseId?.let { put("course_id", it) }
            },
        )
    }

    suspend fun publishedTests(): List<PlacementTest> =
        Backend.client.from("placement_tests")
            .select {
                filter {
                    eq("status", "PUBLISHED")
                    eq("scope", "PUBLIC")
                }
                order("created_at", Order.DESCENDING)
            }
            .decodeList()

    suspend fun exerciseTeachers(): List<TeacherProfile> =
        Backend.client.from("teacher_profiles")
            .select(Columns.raw("*, profile:profiles!teacher_profiles_id_fkey(id, full_name, avatar_url)")) {
                filter { eq("status", "APPROVED") }
                order("rating_avg", Order.DESCENDING)
            }
            .decodeList()

    suspend fun publishedTeacherExercises(teacherId: String): List<PlacementTest> =
        Backend.client.from("placement_tests")
            .select {
                filter {
                    eq("status", "PUBLISHED")
                    eq("scope", "TEACHER")
                    eq("owner_id", teacherId)
                }
                order("created_at", Order.DESCENDING)
            }
            .decodeList()

    suspend fun settings(): Map<String, String> =
        Backend.client.from("app_settings").select().decodeList<AppSetting>()
            .associate { it.key to it.value.toString().trim('"') }
}
