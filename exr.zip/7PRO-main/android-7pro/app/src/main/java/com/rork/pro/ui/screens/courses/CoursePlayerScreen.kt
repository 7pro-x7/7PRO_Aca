package com.rork.pro.ui.screens.courses

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.rork.pro.data.Async
import com.rork.pro.data.CatalogRepository
import com.rork.pro.data.Course
import com.rork.pro.data.CourseSection
import com.rork.pro.data.Enrollment
import com.rork.pro.data.LearningRepository
import com.rork.pro.data.Lesson
import com.rork.pro.data.LessonProgress
import com.rork.pro.data.LessonQuiz
import com.rork.pro.data.QuizResult
import com.rork.pro.data.toAppError
import com.rork.pro.ui.components.AdBanner
import com.rork.pro.ui.components.Divider
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LessonMedia
import com.rork.pro.ui.components.LessonVideo
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.Pill
import com.rork.pro.ui.components.PrimaryAction
import com.rork.pro.ui.components.SecondaryAction
import com.rork.pro.ui.components.SkillBar
import com.rork.pro.ui.components.resolveLessonMedia
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.rork.pro.ui.i18n.trf
import com.rork.pro.ui.i18n.StrCourses
import com.rork.pro.ui.i18n.tr

data class PlayerData(
    val course: Course,
    val lessons: List<Lesson>,
    val sections: List<CourseSection>,
    val progress: Map<String, LessonProgress>,
    val enrollment: Enrollment?,
    val certificateSerial: String?,
)

class CoursePlayerViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<PlayerData>>(Async.Loading)
    val state: StateFlow<Async<PlayerData>> = _state.asStateFlow()

    private val _quizzes = MutableStateFlow<List<LessonQuiz>>(emptyList())
    val quizzes: StateFlow<List<LessonQuiz>> = _quizzes.asStateFlow()

    private val _quizResult = MutableStateFlow<QuizResult?>(null)
    val quizResult: StateFlow<QuizResult?> = _quizResult.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun load(courseId: String) {
        viewModelScope.launch {
            _state.value = Async.Loading
            runCatching {
                val course = CatalogRepository.course(courseId) ?: error("COURSE_NOT_AVAILABLE")
                val enrollment = LearningRepository.enrollment(courseId)
                val certificate = com.rork.pro.data.CommerceRepository.myCertificates()
                    .firstOrNull { it.courseTitle == course.title }
                PlayerData(
                    course = course,
                    lessons = CatalogRepository.lessons(courseId),
                    sections = CatalogRepository.courseSections(courseId),
                    progress = LearningRepository.progressFor(courseId).associateBy { it.lessonId },
                    enrollment = enrollment,
                    certificateSerial = certificate?.serial,
                )
            }.onSuccess { _state.value = Async.Success(it) }
                .onFailure { _state.value = Async.Failure(it.toAppError()) }
        }
    }

    fun openQuiz(lessonId: String) {
        viewModelScope.launch {
            _quizResult.value = null
            runCatching { LearningRepository.quizzes(lessonId) }
                .onSuccess { _quizzes.value = it }
                .onFailure { _quizzes.value = emptyList() }
        }
    }

    fun closeQuiz() {
        _quizzes.value = emptyList()
        _quizResult.value = null
    }

    fun toggleComplete(courseId: String, lessonId: String, completed: Boolean, watchedSeconds: Int) {
        viewModelScope.launch {
            _busy.value = true
            runCatching { LearningRepository.markProgress(lessonId, watchedSeconds, completed) }
            _busy.value = false
            load(courseId)
        }
    }

    fun submitQuiz(courseId: String, lessonId: String, answers: Map<String, List<Int>>) {
        viewModelScope.launch {
            _busy.value = true
            runCatching { LearningRepository.submitQuiz(lessonId, answers) }
                .onSuccess { _quizResult.value = it }
            _busy.value = false
            load(courseId)
        }
    }
}

@Composable
fun CoursePlayerScreen(navController: NavHostController, courseId: String) {
    val vm: CoursePlayerViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val quizzes by vm.quizzes.collectAsStateWithLifecycle()
    val quizResult by vm.quizResult.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedLessonId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(courseId) { vm.load(courseId) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        DetailHeader(tr(StrCourses.learning), onBack = { navController.popBackStack() })

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load(courseId) }
            is Async.Success -> {
                val data = s.value
                val active = data.lessons.firstOrNull { it.id == selectedLessonId }
                    ?: data.lessons.firstOrNull { data.progress[it.id]?.isCompleted != true }
                    ?: data.lessons.firstOrNull()

                LazyColumn(
                    contentPadding = PaddingValues(bottom = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    item {
                        Column(Modifier.padding(horizontal = Dimens.screenPadding)) {
                            Text(
                                data.course.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = Ink.TextPrimary,
                            )
                            Spacer(Modifier.height(12.dp))
                            SkillBar(tr(StrCourses.courseTitle), data.enrollment?.progressPercent ?: 0.0)
                        }
                    }

                    // Free lessons may carry a banner; paid content never does (server-decided).
                    item {
                        AdBanner(
                            "FREE_LESSON",
                            Modifier.padding(horizontal = Dimens.screenPadding),
                            courseId = data.course.id,
                        )
                    }

                    if (data.certificateSerial != null) {
                        item {
                            InkCard(
                                Modifier.padding(horizontal = Dimens.screenPadding),
                                borderColor = Ink.Teal.copy(alpha = 0.4f),
                            ) {
                                Text(tr(StrCourses.certificateIssued), color = Ink.Teal, style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    trf(StrCourses.serialNumber, data.certificateSerial),
                                    color = Ink.TextSecondary,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }
                    }

                    if (active != null) {
                        item {
                            ActiveLessonCard(
                                lesson = active,
                                completed = data.progress[active.id]?.isCompleted == true,
                                busy = busy,
                                modifier = Modifier.padding(horizontal = Dimens.screenPadding),
                                onOpenMedia = { url ->
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, url.toUri()))
                                    }
                                },
                                onToggleComplete = { done ->
                                    vm.toggleComplete(courseId, active.id, done, active.durationSeconds)
                                },
                                onOpenQuiz = { vm.openQuiz(active.id) },
                            )
                        }
                    }

                    if (quizzes.isNotEmpty()) {
                        item {
                            QuizCard(
                                quizzes = quizzes,
                                result = quizResult,
                                busy = busy,
                                modifier = Modifier.padding(horizontal = Dimens.screenPadding),
                                onSubmit = { answers -> active?.let { vm.submitQuiz(courseId, it.id, answers) } },
                                onClose = { vm.closeQuiz() },
                            )
                        }
                    }

                    item {
                        Text(
                            tr(StrCourses.lessons),
                            style = MaterialTheme.typography.titleLarge,
                            color = Ink.TextPrimary,
                            modifier = Modifier.padding(horizontal = Dimens.screenPadding),
                        )
                    }

                    groupLessons(data.sections, data.lessons).forEach { group ->
                        group.section?.let { section ->
                            item(key = "section-${section.id}") {
                                Text(
                                    section.title,
                                    color = Ink.Amber,
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.padding(
                                        start = Dimens.screenPadding,
                                        end = Dimens.screenPadding,
                                        top = 6.dp,
                                    ),
                                )
                            }
                        }
                        items(group.lessons, key = { it.id }) { lesson ->
                            PlaylistRow(
                                lesson = lesson,
                                completed = data.progress[lesson.id]?.isCompleted == true,
                                active = lesson.id == active?.id,
                                modifier = Modifier.padding(horizontal = Dimens.screenPadding),
                            ) {
                                selectedLessonId = lesson.id
                                vm.closeQuiz()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveLessonCard(
    lesson: Lesson,
    completed: Boolean,
    busy: Boolean,
    modifier: Modifier = Modifier,
    onOpenMedia: (String) -> Unit,
    onToggleComplete: (Boolean) -> Unit,
    onOpenQuiz: () -> Unit,
) {
    InkCard(modifier = modifier) {
        Text(lesson.title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleLarge)
        if (!lesson.description.isNullOrBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(lesson.description, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
        if (!lesson.content.isNullOrBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(lesson.content, color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(14.dp))

        val media = lesson.videoUrl?.takeIf { it.isNotBlank() } ?: lesson.documentUrl
        if (!media.isNullOrBlank()) {
            val resolved = remember(media) { resolveLessonMedia(media) }
            val playable = !lesson.videoUrl.isNullOrBlank() && resolved !is LessonMedia.Link
            if (playable) {
                LessonVideo(resolved, Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                SecondaryAction(
                    tr(StrCourses.openExternally),
                    Modifier.fillMaxWidth(),
                ) { onOpenMedia(media) }
            } else {
                PrimaryAction(
                    if (!lesson.videoUrl.isNullOrBlank()) tr(StrCourses.playLesson) else tr(StrCourses.openDocument),
                ) { onOpenMedia(media) }
            }
            Spacer(Modifier.height(10.dp))
        }

        if (lesson.kind == "QUIZ") {
            SecondaryAction(tr(StrCourses.openQuiz), Modifier.fillMaxWidth(), onClick = onOpenQuiz)
            Spacer(Modifier.height(10.dp))
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = completed,
                onCheckedChange = { if (!busy) onToggleComplete(it) },
                colors = CheckboxDefaults.colors(
                    checkedColor = Ink.Amber,
                    uncheckedColor = Ink.Hairline,
                    checkmarkColor = Ink.Canvas,
                ),
            )
            Text(
                if (completed) tr(StrCourses.completed) else tr(StrCourses.markComplete),
                color = if (completed) Ink.Teal else Ink.TextSecondary,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun QuizCard(
    quizzes: List<LessonQuiz>,
    result: QuizResult?,
    busy: Boolean,
    modifier: Modifier = Modifier,
    onSubmit: (Map<String, List<Int>>) -> Unit,
    onClose: () -> Unit,
) {
    val answers = remember(quizzes) { mutableStateMapOf<String, Int>() }

    InkCard(modifier = modifier, borderColor = Ink.Amber.copy(alpha = 0.3f)) {
        Text(tr(StrCourses.lessonQuiz), color = Ink.TextPrimary, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(10.dp))

        quizzes.forEachIndexed { index, quiz ->
            Text(
                "${index + 1}. ${quiz.question}",
                color = Ink.TextPrimary,
                style = MaterialTheme.typography.titleSmall,
            )
            Spacer(Modifier.height(8.dp))
            quiz.options.forEachIndexed { optionIndex, option ->
                val selected = answers[quiz.id] == optionIndex
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) Ink.AmberSoft else Ink.SurfaceHigh)
                        .clickable { answers[quiz.id] = optionIndex }
                        .padding(horizontal = 12.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        if (selected) Icons.Default.CheckCircle else Icons.Default.Circle,
                        null,
                        tint = if (selected) Ink.Amber else Ink.TextMuted,
                        modifier = Modifier.size(17.dp),
                    )
                    Spacer(Modifier.size(10.dp))
                    Text(option, color = Ink.TextPrimary, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (result != null) {
            Divider()
            Spacer(Modifier.height(12.dp))
            Text(
                trf(if (result.passed) StrCourses.quizPassed else StrCourses.quizNotPassed, result.percent.toInt()),
                color = if (result.passed) Ink.Teal else Ink.Coral,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(12.dp))
            SecondaryAction(tr(StrCourses.close), Modifier.fillMaxWidth(), onClick = onClose)
        } else {
            PrimaryAction(
                tr(StrCourses.submitAnswers),
                enabled = answers.size == quizzes.size,
                loading = busy,
            ) {
                onSubmit(answers.mapValues { listOf(it.value) })
            }
        }
    }
}

@Composable
private fun PlaylistRow(
    lesson: Lesson,
    completed: Boolean,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    InkCard(
        modifier = modifier,
        onClick = onClick,
        color = if (active) Ink.SurfaceHigh else Ink.Surface,
        contentPadding = PaddingValues(13.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(
                when {
                    completed -> Icons.Default.CheckCircle
                    lesson.kind == "DOCUMENT" -> Icons.Default.Description
                    else -> Icons.Default.PlayArrow
                },
                null,
                tint = if (completed) Ink.Teal else Ink.Amber,
                modifier = Modifier.size(20.dp),
            )
            Text(
                lesson.title,
                color = Ink.TextPrimary,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            if (lesson.durationSeconds > 0) {
                Text(
                    trf(StrCourses.minutesShort, lesson.durationSeconds / 60),
                    color = Ink.TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}
