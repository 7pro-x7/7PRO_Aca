package com.rork.pro.ui.screens.teacher

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.rork.pro.data.Async
import com.rork.pro.data.CourseScope
import com.rork.pro.data.TeacherBalance
import com.rork.pro.data.TeacherRepository
import com.rork.pro.data.toAppError
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.Refreshable
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.formatMoney
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.screens.studio.StudioRoutes
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import com.rork.pro.ui.i18n.StrTeacher
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf

object TeacherRoutes {
    const val STUDIO = "teacher/studio"
    const val EARNINGS = "teacher/earnings"
    const val EXERCISES = "teacher/exercises"
}

fun NavGraphBuilder.teacherGraph(navController: NavHostController, session: SessionViewModel) {
    composable(TeacherRoutes.STUDIO) { TeacherStudioScreen(navController, session) }
    composable(TeacherRoutes.EARNINGS) { TeacherEarningsScreen(navController) }
    composable(TeacherRoutes.EXERCISES) { TeacherExercisesScreen(navController) }
}

data class StudioData(val analytics: JsonObject, val balance: TeacherBalance)

class TeacherStudioViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<StudioData>>(Async.Loading)
    val state: StateFlow<Async<StudioData>> = _state.asStateFlow()

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    init { load() }

    fun refresh() {
        _refreshing.value = true
        load(quiet = true)
    }

    fun load(quiet: Boolean = false) {
        viewModelScope.launch {
            if (!quiet) _state.value = Async.Loading
            runCatching { StudioData(TeacherRepository.analytics(), TeacherRepository.balance()) }
                .onSuccess { _state.value = Async.Success(it) }
                .onFailure { if (!quiet) _state.value = Async.Failure(it.toAppError()) }
            _refreshing.value = false
        }
    }
}

fun JsonObject.num(key: String): Double =
    runCatching { this[key]?.jsonPrimitive?.content?.toDoubleOrNull() ?: 0.0 }.getOrDefault(0.0)

fun JsonObject.int(key: String): Int = num(key).toInt()

@Composable
fun TeacherStudioScreen(navController: NavHostController, session: SessionViewModel) {
    val vm: TeacherStudioViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val sessionState by session.state.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { vm.load() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        DetailHeader(tr(StrTeacher.teacherStudio), onBack = { navController.popBackStack() })

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load() }
            is Async.Success -> Refreshable(refreshing, { vm.refresh() }) {
                val a = s.value.analytics
                val balance = s.value.balance
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = Dimens.screenPadding, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    item {
                        val teacher = sessionState.teacherProfile
                        InkCard(borderColor = Ink.Amber.copy(alpha = 0.25f)) {
                            Text(
                                tr(StrTeacher.availableBalance),
                                color = Ink.TextSecondary,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                formatMoney(balance.available, balance.currency),
                                color = Ink.Amber,
                                style = MaterialTheme.typography.displaySmall,
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                MiniStat(tr(StrTeacher.pending), formatMoney(balance.pending, balance.currency))
                                MiniStat(tr(StrTeacher.withdrawn), formatMoney(balance.paid, balance.currency))
                            }
                            if (teacher?.commissionRate != null) {
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    trf(StrTeacher.yourShare, (teacher.commissionRate * 100).toInt()),
                                    color = Ink.Teal,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }
                    }

                    item { SectionHeader(tr(StrTeacher.performance)) }

                    item {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.height(240.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            userScrollEnabled = false,
                        ) {
                            val tiles = listOf(
                                tr(StrTeacher.students) to a.int("students").toString(),
                                tr(StrTeacher.enrollments) to a.int("enrollments").toString(),
                                tr(StrTeacher.coursesLive) to a.int("courses_published").toString(),
                                tr(StrTeacher.courseRevenue) to formatMoney(a.num("course_revenue"), balance.currency),
                                tr(StrTeacher.yourEarnings) to formatMoney(a.num("earnings"), balance.currency),
                                tr(StrTeacher.platformShare) to formatMoney(a.num("platform_share"), balance.currency),
                                tr(StrTeacher.completion) to "${a.num("completion_rate").toInt()}%",
                                tr(StrTeacher.ratingLabel) to if (a.int("rating_count") > 0) {
                                    String.format(java.util.Locale.US, "%.1f", a.num("rating"))
                                } else "—",
                            )
                            items(tiles) { (label, value) ->
                                InkCard(contentPadding = PaddingValues(14.dp)) {
                                    Text(value, color = Ink.TextPrimary, style = MaterialTheme.typography.titleLarge, maxLines = 1)
                                    Text(label, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }

                    item { SectionHeader(tr(StrTeacher.manage)) }

                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            StudioRow(Icons.Default.MenuBook, tr(StrTeacher.coursesTitle), tr(StrTeacher.coursesSub)) {
                                navController.navigate(StudioRoutes.courses(CourseScope.MINE))
                            }
                            StudioRow(Icons.Default.Quiz, tr(StrTeacher.exercisesTitle), tr(StrTeacher.exercisesSub)) {
                                navController.navigate(TeacherRoutes.EXERCISES)
                            }
                            StudioRow(Icons.Default.Payments, tr(StrTeacher.earningsTitle), tr(StrTeacher.earningsSub)) {
                                navController.navigate(TeacherRoutes.EARNINGS)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column {
        Text(value, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
        Text(label, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun StudioRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Ink.Surface)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Ink.AmberSoft),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Ink.Amber, modifier = Modifier.size(19.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
        }
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            null,
            tint = Ink.TextMuted,
            modifier = Modifier.size(20.dp),
        )
    }
}
