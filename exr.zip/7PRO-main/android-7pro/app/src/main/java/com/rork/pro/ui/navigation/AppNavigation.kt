package com.rork.pro.ui.navigation

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.rememberNavController
import com.rork.pro.BuildConfig
import com.rork.pro.data.SessionCache
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.screens.admin.adminGraph
import com.rork.pro.ui.screens.auth.AuthScreen
import com.rork.pro.ui.screens.courses.CourseDetailScreen
import com.rork.pro.ui.screens.courses.CoursePlayerScreen
import com.rork.pro.ui.screens.courses.CoursesScreen
import com.rork.pro.ui.screens.home.HomeScreen
import com.rork.pro.ui.screens.profile.CertificatesScreen
import com.rork.pro.ui.screens.profile.EditProfileScreen
import com.rork.pro.ui.screens.profile.NotificationsScreen
import com.rork.pro.ui.screens.profile.OrdersScreen
import com.rork.pro.ui.screens.profile.ProfileScreen
import com.rork.pro.ui.screens.profile.SupportScreen
import com.rork.pro.ui.screens.test.PlacementResultScreen
import com.rork.pro.ui.screens.test.PlacementRunnerScreen
import com.rork.pro.ui.screens.test.PlacementStartScreen
import com.rork.pro.ui.screens.update.UpdateRequiredScreen
import com.rork.pro.ui.screens.studio.studioGraph
import com.rork.pro.ui.screens.teacher.teacherGraph
import com.rork.pro.ui.theme.Ink
import com.rork.pro.ui.i18n.StrNav
import com.rork.pro.ui.i18n.tr

/**
 * Where a tapped notification wants the app to go.
 *
 * The notification is handled by the activity long before the navigator exists, so the route is
 * parked here and consumed once — reopening the app later never replays an old tap.
 */
object PendingRoute {
    private var route: String? by mutableStateOf(null)

    fun set(value: String) {
        route = value
    }

    fun consume(): String? {
        val current = route
        route = null
        return current
    }

    val pending: String? get() = route
}

object Routes {
    const val HOME = "home"
    const val COURSES = "courses"
    const val PROFILE = "profile"

    const val COURSE_DETAIL = "course/{courseId}"
    const val COURSE_PLAYER = "player/{courseId}"

    const val TEST_START = "test-start"
    const val TEST_RUN = "test-run/{testId}"
    const val TEST_RESULT = "test-result/{attemptId}"

    const val ORDERS = "orders"
    const val CERTIFICATES = "certificates"
    const val NOTIFICATIONS = "notifications"
    const val SUPPORT = "support"
    const val EDIT_PROFILE = "edit-profile"

    fun courseDetail(id: String) = "course/$id"
    fun coursePlayer(id: String) = "player/$id"
    fun testRun(id: String) = "test-run/$id"
    fun testResult(id: String) = "test-result/$id"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab(Routes.HOME, tr(StrNav.homeTab), Icons.Default.Home),
    Tab(Routes.COURSES, tr(StrNav.coursesTab), Icons.Default.MenuBook),
    Tab(Routes.TEST_START, tr(StrNav.testTab), Icons.Default.Quiz),
    Tab(Routes.PROFILE, tr(StrNav.profileTab), Icons.Default.Person),
)

@Composable
fun AppNavigation() {
    val session: SessionViewModel = viewModel()
    val state by session.state.collectAsStateWithLifecycle()

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Ink.Canvas, Ink.Canvas, Ink.CanvasDeep),
                ),
            ),
    ) {
        when {
            // An outdated build is stopped before anything else, signed in or not.
            state.update.blocks(BuildConfig.VERSION_CODE) ->
                UpdateRequiredScreen(state.update) { session.refreshUpdateRule() }
            state.booting -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                LoadingBlock(label = "7PRO")
            }
            !state.signedIn -> AuthScreen(session)
            else -> MainScaffold(session)
        }
    }
}

@Composable
private fun MainScaffold(session: SessionViewModel) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBar = currentRoute in TABS.map { it.route }

    // Reopen on the tab the user left off on. Read once, so navigating away from a tab
    // during this session never re-anchors the graph underneath the user.
    val startTab = remember {
        SessionCache.lastTab()?.takeIf { saved -> TABS.any { it.route == saved } } ?: Routes.HOME
    }

    LaunchedEffect(currentRoute) {
        if (TABS.any { it.route == currentRoute }) {
            SessionCache.setLastTab(currentRoute.orEmpty())
        }
    }

    // Deep link from a device notification: open the screen it is about.
    val pendingRoute = PendingRoute.pending
    LaunchedEffect(pendingRoute) {
        val target = PendingRoute.consume() ?: return@LaunchedEffect
        runCatching { navController.navigate(target) }
    }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        bottomBar = { if (showBar) BottomBar(navController, currentRoute) },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startTab,
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = if (showBar) padding.calculateBottomPadding() else 0.dp),
        ) {
            studentGraph(navController, session)
            teacherGraph(navController, session)
            studioGraph(navController, session)
            adminGraph(navController, session)
        }
    }
}

private fun NavGraphBuilder.studentGraph(navController: NavHostController, session: SessionViewModel) {
    composable(Routes.HOME) { HomeScreen(navController, session) }
    composable(Routes.COURSES) { CoursesScreen(navController) }
    composable(Routes.PROFILE) { ProfileScreen(navController, session) }

    composable(Routes.COURSE_DETAIL) { entry ->
        CourseDetailScreen(navController, entry.arguments?.getString("courseId").orEmpty())
    }
    composable(Routes.COURSE_PLAYER) { entry ->
        CoursePlayerScreen(navController, entry.arguments?.getString("courseId").orEmpty())
    }

    composable(Routes.TEST_START) { PlacementStartScreen(navController) }
    composable(Routes.TEST_RUN) { entry ->
        PlacementRunnerScreen(navController, entry.arguments?.getString("testId").orEmpty())
    }
    composable(Routes.TEST_RESULT) { entry ->
        PlacementResultScreen(navController, entry.arguments?.getString("attemptId").orEmpty(), session)
    }

    composable(Routes.ORDERS) { OrdersScreen(navController) }
    composable(Routes.CERTIFICATES) { CertificatesScreen(navController) }
    composable(Routes.NOTIFICATIONS) { NotificationsScreen(navController, session) }
    composable(Routes.SUPPORT) { SupportScreen(navController) }
    composable(Routes.EDIT_PROFILE) { EditProfileScreen(navController, session) }
}

@Composable
private fun BottomBar(navController: NavHostController, currentRoute: String?) {
    NavigationBar(
        containerColor = Ink.Surface,
        contentColor = Ink.TextSecondary,
        tonalElevation = 0.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        TABS.forEach { tab ->
            val selected = currentRoute == tab.route
            val scale by animateFloatAsState(if (selected) 1.08f else 1f, tween(180), label = "tab")
            NavigationBarItem(
                selected = selected,
                onClick = {
                    if (!selected) {
                        navController.navigate(tab.route) {
                            // Anchored to the graph's real start destination, which is now the
                            // restored tab rather than always Home.
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = {
                    Icon(
                        tab.icon,
                        contentDescription = tab.label,
                        modifier = Modifier
                            .size(23.dp)
                            .scale(scale),
                    )
                },
                label = {
                    Text(tab.label, style = MaterialTheme.typography.labelMedium)
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Ink.Amber,
                    selectedTextColor = Ink.Amber,
                    unselectedIconColor = Ink.TextMuted,
                    unselectedTextColor = Ink.TextMuted,
                    indicatorColor = Ink.AmberSoft,
                ),
            )
        }
    }
}

/** Shared top bar for every non-tab destination. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun DetailHeader(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: @Composable (() -> Unit)? = null,
) {
    Column(modifier.fillMaxWidth()) {
        androidx.compose.material3.TopAppBar(
            title = {
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    color = Ink.TextPrimary,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
            },
            navigationIcon = {
                androidx.compose.material3.IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = tr(StrNav.back),
                        tint = Ink.TextPrimary,
                    )
                }
            },
            actions = { trailing?.invoke() },
            colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
                containerColor = androidx.compose.ui.graphics.Color.Transparent,
                titleContentColor = Ink.TextPrimary,
            ),
        )
    }
}
