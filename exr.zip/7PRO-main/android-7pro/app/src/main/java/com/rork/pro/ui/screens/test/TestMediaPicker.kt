package com.rork.pro.ui.screens.test

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.rork.pro.data.MediaRepository
import com.rork.pro.ui.components.SecondaryAction
import com.rork.pro.ui.screens.auth.InkField
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.launch

/**
 * The test system owns its media picker so course and profile forms stay untouched.
 * GetContent opens the native phone picker for images, video and audio without requesting
 * broad storage permissions.
 */
@Composable
fun TestMediaField(
    label: String,
    url: String,
    onUrlChange: (String) -> Unit,
    mimeType: String,
    folder: String,
    chooseLabel: String,
    onError: (String) -> Unit = {},
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var uploading by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            scope.launch {
                uploading = true
                runCatching {
                    MediaRepository.upload(MediaRepository.read(context, it), folder)
                }.onSuccess(onUrlChange)
                    .onFailure { error -> onError(error.message.orEmpty()) }
                uploading = false
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SecondaryAction(
            if (uploading) "…" else "$chooseLabel · $label",
            Modifier.fillMaxWidth(),
            enabled = !uploading,
            tint = if (uploading) Ink.TextMuted else Ink.Amber,
        ) { picker.launch(mimeType) }
        InkField(url, onUrlChange, label)
        Spacer(Modifier.height(2.dp))
    }
}