package com.rork.pro.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.Avatar
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LevelBadge
import com.rork.pro.ui.components.Pill
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.StatusPill
import com.rork.pro.ui.navigation.Routes
import com.rork.pro.ui.screens.admin.AdminRoutes
import com.rork.pro.ui.screens.teacher.TeacherRoutes
import com.rork.pro.ui.theme.AppAppearance
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import com.rork.pro.ui.theme.ThemeMode
import com.rork.pro.ui.i18n.AppLanguage
import com.rork.pro.ui.i18n.Lang
import com.rork.pro.ui.i18n.Str
import com.rork.pro.ui.i18n.StrProfile
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf

@Composable
fun ProfileScreen(navController: NavHostController, session: SessionViewModel) {
    val state by session.state.collectAsStateWithLifecycle()
    val profile = state.profile
    var languageSheetOpen by remember { mutableStateOf(false) }
    var themeSheetOpen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { session.refreshNotifications() }

    if (themeSheetOpen) {
        AppearanceDialog(onDismiss = { themeSheetOpen = false })
    }

    if (languageSheetOpen) {
        LanguageDialog(onDismiss = { languageSheetOpen = false })
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text(
                tr(StrProfile.profile),
                style = MaterialTheme.typography.headlineMedium,
                color = Ink.TextPrimary,
                modifier = Modifier.padding(horizontal = Dimens.screenPadding, vertical = 10.dp),
            )
        }

        item {
            InkCard(Modifier.padding(horizontal = Dimens.screenPadding)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Avatar(profile?.avatarUrl, profile?.displayName, 58.dp)
                    Column(Modifier.weight(1f)) {
                        Text(
                            profile?.displayName ?: tr(StrProfile.learner),
                            color = Ink.TextPrimary,
                            style = MaterialTheme.typography.titleLarge,
                        )
                        Text(
                            profile?.email.orEmpty(),
                            color = Ink.TextMuted,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Icon(
                        Icons.Default.Edit,
                        tr(StrProfile.editProfile),
                        tint = Ink.TextSecondary,
                        modifier = Modifier
                            .size(22.dp)
                            .clickable { navController.navigate(Routes.EDIT_PROFILE) },
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (profile?.currentLevel != null) {
                        LevelBadge(profile.currentLevel)
                    } else {
                        Pill(tr(StrProfile.noLevelYet))
                    }
                    Pill(
                        profile?.role?.lowercase()?.replaceFirstChar { it.uppercase() } ?: tr(StrProfile.student),
                        background = Color(0x1F8FA3BC),
                        foreground = Ink.TextSecondary,
                    )
                    if (profile?.status != null && profile.status != "ACTIVE") {
                        StatusPill(profile.status)
                    }
                }
            }
        }

        if (state.maintenance) {
            item {
                InkCard(
                    Modifier.padding(horizontal = Dimens.screenPadding),
                    borderColor = Ink.Coral.copy(alpha = 0.4f),
                ) {
                    Text(tr(StrProfile.maintenanceOn), color = Ink.Coral, style = MaterialTheme.typography.titleMedium)
                    if (state.maintenanceMessage.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(state.maintenanceMessage, color = Ink.TextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        item {
            SectionHeader(tr(StrProfile.learning), Modifier.padding(horizontal = Dimens.screenPadding))
        }
        item {
            Column(
                Modifier.padding(horizontal = Dimens.screenPadding),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                MenuRow(Icons.Default.Assessment, tr(StrProfile.placementTest), tr(StrProfile.placementTestSub)) {
                    navController.navigate(Routes.TEST_START)
                }
                MenuRow(Icons.Default.CardMembership, tr(StrProfile.certificates), tr(StrProfile.certificatesSub)) {
                    navController.navigate(Routes.CERTIFICATES)
                }
                MenuRow(Icons.Default.ReceiptLong, tr(StrProfile.paymentsOrders), tr(StrProfile.paymentsOrdersSub)) {
                    navController.navigate(Routes.ORDERS)
                }
                MenuRow(
                    Icons.Default.Notifications,
                    tr(StrProfile.notifications),
                    if (state.unreadCount > 0) trf(StrProfile.unreadCount, state.unreadCount) else tr(StrProfile.allCaughtUp),
                ) { navController.navigate(Routes.NOTIFICATIONS) }
                MenuRow(Icons.Default.SupportAgent, tr(StrProfile.support), tr(StrProfile.supportSub)) {
                    navController.navigate(Routes.SUPPORT)
                }
            }
        }

        if (state.isTeacher || state.isStaff) {
            item {
                SectionHeader(tr(StrProfile.teaching), Modifier.padding(horizontal = Dimens.screenPadding))
            }
            item {
                Column(
                    Modifier.padding(horizontal = Dimens.screenPadding),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (state.isTeacher) {
                        MenuRow(Icons.Default.WorkspacePremium, tr(StrProfile.teacherStudio), tr(StrProfile.teacherStudioSub)) {
                            navController.navigate(TeacherRoutes.STUDIO)
                        }
                    }
                    if (state.isStaff) {
                        MenuRow(
                            Icons.Default.AdminPanelSettings,
                            if (state.isOwner) tr(StrProfile.ownerConsole) else tr(StrProfile.adminConsole),
                            tr(StrProfile.consoleSub),
                        ) { navController.navigate(AdminRoutes.CONSOLE) }
                    }
                }
            }
        }

        item {
            SectionHeader(tr(Str.settings), Modifier.padding(horizontal = Dimens.screenPadding))
        }
        item {
            Column(
                Modifier.padding(horizontal = Dimens.screenPadding),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                MenuRow(
                    Icons.Default.Language,
                    tr(Str.language),
                    AppLanguage.current.nativeLabel,
                ) { languageSheetOpen = true }
                MenuRow(
                    Icons.Default.DarkMode,
                    tr(StrProfile.appearance),
                    themeLabel(AppAppearance.mode),
                ) { themeSheetOpen = true }
            }
        }

        item {
            Column(Modifier.padding(horizontal = Dimens.screenPadding)) {
                Spacer(Modifier.height(10.dp))
                MenuRow(Icons.AutoMirrored.Filled.Logout, tr(StrProfile.signOut), null, danger = true) {
                    session.signOut()
                }
            }
        }
    }
}

private fun themeLabel(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> tr(StrProfile.themeSystem)
    ThemeMode.LIGHT -> tr(StrProfile.themeLight)
    ThemeMode.DARK -> tr(StrProfile.themeDark)
}

/** Light / dark switch. The choice is remembered on this device and applies instantly. */
@Composable
private fun AppearanceDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ink.Surface,
        titleContentColor = Ink.TextPrimary,
        textContentColor = Ink.TextSecondary,
        title = { Text(tr(StrProfile.appearance), style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr(StrProfile.appearanceSubtitle), style = MaterialTheme.typography.bodySmall, color = Ink.TextMuted)
                Spacer(Modifier.height(4.dp))
                ThemeMode.entries.forEach { mode ->
                    val selected = AppAppearance.mode == mode
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (selected) Ink.AmberSoft else Ink.SurfaceHigh)
                            .clickable {
                                AppAppearance.set(context, mode)
                                onDismiss()
                            }
                            .padding(horizontal = 14.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            themeLabel(mode),
                            color = if (selected) Ink.Amber else Ink.TextPrimary,
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.weight(1f),
                        )
                        if (selected) {
                            Icon(Icons.Default.Check, null, tint = Ink.Amber, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(tr(Str.close), color = Ink.Amber)
            }
        },
    )
}

/** Manual language switch. The choice is saved and always beats device auto-detection. */
@Composable
private fun LanguageDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ink.Surface,
        titleContentColor = Ink.TextPrimary,
        textContentColor = Ink.TextSecondary,
        title = { Text(tr(Str.language), style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr(Str.languageSubtitle), style = MaterialTheme.typography.bodySmall, color = Ink.TextMuted)
                Spacer(Modifier.height(4.dp))
                Lang.entries.forEach { lang ->
                    val selected = AppLanguage.current == lang
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (selected) Ink.AmberSoft else Ink.SurfaceHigh)
                            .clickable {
                                AppLanguage.set(context, lang)
                                onDismiss()
                            }
                            .padding(horizontal = 14.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            lang.nativeLabel,
                            color = if (selected) Ink.Amber else Ink.TextPrimary,
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.weight(1f),
                        )
                        if (selected) {
                            Icon(Icons.Default.Check, null, tint = Ink.Amber, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                if (!AppLanguage.isExplicit) {
                    Text(
                        tr(Str.followDevice),
                        style = MaterialTheme.typography.bodySmall,
                        color = Ink.TextMuted,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(tr(Str.done), color = Ink.Amber) }
        },
    )
}

@Composable
private fun MenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String?,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Ink.Surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (danger) Ink.CoralSoft else Ink.AmberSoft),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = if (danger) Ink.Coral else Ink.Amber, modifier = Modifier.size(19.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = if (danger) Ink.Coral else Ink.TextPrimary,
                style = MaterialTheme.typography.titleSmall,
            )
            if (subtitle != null) {
                Text(subtitle, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
            }
        }
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            null,
            tint = Ink.TextMuted,
            modifier = Modifier.size(20.dp),
        )
    }
}
