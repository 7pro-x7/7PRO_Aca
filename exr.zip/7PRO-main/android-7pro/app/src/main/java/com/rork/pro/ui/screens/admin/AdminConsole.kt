package com.rork.pro.ui.screens.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.rork.pro.data.AdminRepository
import com.rork.pro.data.Async
import com.rork.pro.data.CourseScope
import com.rork.pro.data.toAppError
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.formatMoney
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.screens.studio.StudioRoutes
import com.rork.pro.ui.screens.teacher.StudioRow
import com.rork.pro.ui.screens.teacher.int
import com.rork.pro.ui.screens.teacher.num
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import com.rork.pro.ui.i18n.StrAdminHub
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf

object AdminRoutes {
    const val CONSOLE = "admin/console"
    const val TEACHERS = "admin/teachers"
    const val ANNOUNCE = "admin/announce"
    const val REVIEW = "admin/review"
    const val PRICING = "admin/pricing"
    const val COUPONS = "admin/coupons"
    const val FINANCE = "admin/finance"
    const val PAYOUTS = "admin/payouts"
    const val USERS = "admin/users"
    const val CMS = "admin/cms"
    const val ADS = "admin/ads"
    const val SETTINGS = "admin/settings"
    const val TESTS = "admin/tests"
    const val EXERCISES = "admin/exercises"
    const val MODERATION = "admin/moderation"
    const val SUPPORT = "admin/support"
    const val AUDIT = "admin/audit"
}

fun NavGraphBuilder.adminGraph(navController: NavHostController, session: SessionViewModel) {
    composable(AdminRoutes.CONSOLE) { AdminConsoleScreen(navController, session) }
    composable(AdminRoutes.TEACHERS) { AdminTeachersScreen(navController, session) }
    composable(AdminRoutes.ANNOUNCE) { AdminAnnouncementsScreen(navController) }
    composable(AdminRoutes.REVIEW) { AdminReviewScreen(navController) }
    composable(AdminRoutes.PRICING) { AdminPricingScreen(navController) }
    composable(AdminRoutes.COUPONS) { AdminCouponsScreen(navController, session) }
    composable(AdminRoutes.FINANCE) { AdminFinanceScreen(navController) }
    composable(AdminRoutes.PAYOUTS) { AdminPayoutsScreen(navController) }
    composable(AdminRoutes.USERS) { AdminUsersScreen(navController, session) }
    composable(AdminRoutes.CMS) { AdminCmsScreen(navController) }
    composable(AdminRoutes.ADS) { AdminAdsScreen(navController) }
    composable(AdminRoutes.SETTINGS) { AdminSettingsScreen(navController, session) }
    composable(AdminRoutes.TESTS) { AdminTestsScreen(navController) }
    composable(AdminRoutes.EXERCISES) { AdminExercisesScreen(navController) }
    composable(AdminRoutes.MODERATION) { AdminModerationScreen(navController) }
    composable(AdminRoutes.SUPPORT) { AdminSupportScreen(navController) }
    composable(AdminRoutes.AUDIT) { AdminAuditScreen(navController) }
}

class AdminConsoleViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<JsonObject>>(Async.Loading)
    val state: StateFlow<Async<JsonObject>> = _state.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.value = Async.Loading
            runCatching { AdminRepository.analytics() }
                .onSuccess { _state.value = Async.Success(it) }
                .onFailure { _state.value = Async.Failure(it.toAppError()) }
        }
    }
}

@Composable
fun AdminConsoleScreen(navController: NavHostController, session: SessionViewModel) {
    val vm: AdminConsoleViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val sessionState by session.state.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { vm.load() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        DetailHeader(
            if (sessionState.isOwner) tr(StrAdminHub.ownerConsole) else tr(StrAdminHub.adminConsole),
            onBack = { navController.popBackStack() },
        )

        LazyColumn(
            contentPadding = PaddingValues(horizontal = Dimens.screenPadding, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (val s = state) {
                is Async.Loading -> item { LoadingBlock() }
                is Async.Failure -> item { ErrorBlock(s.error) { vm.load() } }
                is Async.Success -> {
                    val a = s.value
                    item {
                        InkCard(borderColor = Ink.Amber.copy(alpha = 0.25f)) {
                            Text(tr(StrAdminHub.netRevenue30), color = Ink.TextSecondary, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                formatMoney(a.num("net_revenue"), "EGP"),
                                color = Ink.Amber,
                                style = MaterialTheme.typography.displaySmall,
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                trf(
                                    StrAdminHub.grossAndTeachers,
                                    formatMoney(a.num("gross_revenue"), "EGP"),
                                    formatMoney(a.num("teacher_earnings"), "EGP"),
                                ),
                                color = Ink.TextMuted,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }

                    item { SectionHeader(tr(StrAdminHub.platform)) }
                    item {
                        val tiles = listOf(
                            tr(StrAdminHub.users) to a.int("users_total").toString(),
                            tr(StrAdminHub.students) to a.int("students").toString(),
                            tr(StrAdminHub.teachers) to a.int("teachers").toString(),
                            tr(StrAdminHub.paidOrders) to a.int("orders_paid").toString(),
                            tr(StrAdminHub.coursesLive) to a.int("courses_published").toString(),
                            tr(StrAdminHub.testsTaken) to a.int("tests_taken").toString(),
                            tr(StrAdminHub.refunds) to formatMoney(a.num("refunds"), "EGP"),
                            tr(StrAdminHub.payoutsDue) to formatMoney(a.num("payouts_pending"), "EGP"),
                        )
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.height(240.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            userScrollEnabled = false,
                        ) {
                            items(tiles) { (label, value) ->
                                InkCard(contentPadding = PaddingValues(14.dp)) {
                                    Text(value, color = Ink.TextPrimary, style = MaterialTheme.typography.titleLarge, maxLines = 1)
                                    Text(label, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }

                    val pendingCourses = a.int("courses_pending")
                    val openTickets = a.int("open_tickets")

                    item { SectionHeader(tr(StrAdminHub.controlCentre)) }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (sessionState.can("teachers.manage")) {
                                StudioRow(Icons.Default.ManageAccounts, tr(StrAdminHub.teachersAvailability), tr(StrAdminHub.teachersAvailabilitySub)) {
                                    navController.navigate(AdminRoutes.TEACHERS)
                                }
                            }
                            if (sessionState.can("courses.manage")) {
                                StudioRow(
                                    Icons.Default.LibraryBooks,
                                    tr(StrAdminHub.courseLibrary),
                                    tr(StrAdminHub.courseLibrarySub),
                                ) { navController.navigate(StudioRoutes.courses(CourseScope.ALL)) }
                            }
                            if (sessionState.can("courses.manage")) {
                                StudioRow(
                                    Icons.Default.FactCheck,
                                    tr(StrAdminHub.contentReview),
                                    if (pendingCourses > 0) trf(StrAdminHub.awaitingApproval, pendingCourses) else tr(StrAdminHub.nothingPending),
                                ) { navController.navigate(AdminRoutes.REVIEW) }
                            }
                            if (sessionState.can("pricing.manage")) {
                                StudioRow(Icons.Default.CurrencyExchange, tr(StrAdminHub.countryPricing), tr(StrAdminHub.countryPricingSub)) {
                                    navController.navigate(AdminRoutes.PRICING)
                                }
                            }
                            if (sessionState.can("coupons.manage")) {
                                StudioRow(Icons.Default.Discount, tr(StrAdminHub.coupons), tr(StrAdminHub.couponsSub)) {
                                    navController.navigate(AdminRoutes.COUPONS)
                                }
                            }
                            if (sessionState.can("finance.read")) {
                                StudioRow(Icons.Default.ReceiptLong, tr(StrAdminHub.ordersRefunds), tr(StrAdminHub.ordersRefundsSub)) {
                                    navController.navigate(AdminRoutes.FINANCE)
                                }
                            }
                            if (sessionState.can("payouts.manage")) {
                                StudioRow(Icons.Default.Payments, tr(StrAdminHub.withdrawals), tr(StrAdminHub.withdrawalsSub)) {
                                    navController.navigate(AdminRoutes.PAYOUTS)
                                }
                            }
                            if (sessionState.can("users.manage") || sessionState.isOwner) {
                                StudioRow(Icons.Default.ManageAccounts, tr(StrAdminHub.usersAdmins), tr(StrAdminHub.usersAdminsSub)) {
                                    navController.navigate(AdminRoutes.USERS)
                                }
                            }
                            if (sessionState.can("tests.manage")) {
                                StudioRow(Icons.Default.Quiz, tr(StrAdminHub.placementTests), tr(StrAdminHub.placementTestsSub)) {
                                    navController.navigate(AdminRoutes.TESTS)
                                }
                                StudioRow(Icons.Default.Quiz, tr(StrAdminHub.teacherExercises), tr(StrAdminHub.teacherExercisesSub)) {
                                    navController.navigate(AdminRoutes.EXERCISES)
                                }
                            }
                            if (sessionState.can("notifications.manage")) {
                                StudioRow(Icons.Default.Campaign, tr(StrAdminHub.announcements), tr(StrAdminHub.announcementsSub)) {
                                    navController.navigate(AdminRoutes.ANNOUNCE)
                                }
                            }
                            if (sessionState.can("cms.manage")) {
                                StudioRow(Icons.Default.Campaign, tr(StrAdminHub.homeContent), tr(StrAdminHub.homeContentSub)) {
                                    navController.navigate(AdminRoutes.CMS)
                                }
                            }
                            if (sessionState.can("ads.manage")) {
                                StudioRow(Icons.Default.Tv, tr(StrAdminHub.admob), tr(StrAdminHub.admobSub)) {
                                    navController.navigate(AdminRoutes.ADS)
                                }
                            }
                            if (sessionState.can("reviews.manage")) {
                                StudioRow(Icons.Default.Gavel, tr(StrAdminHub.reviewsModeration), tr(StrAdminHub.reviewsModerationSub)) {
                                    navController.navigate(AdminRoutes.MODERATION)
                                }
                            }
                            if (sessionState.can("support.manage")) {
                                StudioRow(
                                    Icons.Default.SupportAgent,
                                    tr(StrAdminHub.supportTickets),
                                    if (openTickets > 0) trf(StrAdminHub.ticketsOpen, openTickets) else tr(StrAdminHub.noOpenTickets),
                                ) { navController.navigate(AdminRoutes.SUPPORT) }
                            }
                            if (sessionState.can("settings.manage")) {
                                StudioRow(Icons.Default.Settings, tr(StrAdminHub.platformSettings), tr(StrAdminHub.platformSettingsSub)) {
                                    navController.navigate(AdminRoutes.SETTINGS)
                                }
                            }
                            if (sessionState.can("audit.read")) {
                                StudioRow(Icons.Default.History, tr(StrAdminHub.auditLog), tr(StrAdminHub.auditLogSub)) {
                                    navController.navigate(AdminRoutes.AUDIT)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
