package com.rork.pro.ui.i18n

/** Adaptive placement test: start, question run, result. */
object StrTest {
    val placementTest = Tr("Placement test", "اختبار تحديد المستوى")
    val findYourLevel = Tr("Find your exact level", "اكتشف مستواك بدقة")
    val adaptiveIntro = Tr("Questions adapt to your answers, so you reach an accurate CEFR level in fewer steps.", "تتكيف الأسئلة مع إجاباتك، لتصل إلى مستواك بدقة وفق الإطار الأوروبي في خطوات أقل.")
    val noTestPublished = Tr("No test published", "لا يوجد اختبار منشور")
    val noTestPublishedBody = Tr("The academy has not published a placement test yet. Check back soon.", "لم تنشر الأكاديمية اختبار تحديد مستوى بعد. عد قريبًا.")
    val adaptive = Tr("Adaptive", "تكيفي")
    val fixed = Tr("Fixed", "ثابت")
    val startFreeTest = Tr("Start free test", "ابدأ الاختبار المجاني")
    val yourPreviousResults = Tr("Your previous results", "نتائجك السابقة")
    val result = Tr("Result", "النتيجة")
    val levelTest = Tr("Level test", "اختبار المستوى")
    val scoringAnswers = Tr("Scoring your answers", "جارٍ تصحيح إجاباتك")
    val yourAnswer = Tr("Your answer", "إجابتك")
    val correct = Tr("Correct", "إجابة صحيحة")
    val notQuite = Tr("Not quite", "ليست صحيحة")
    val submitAnswer = Tr("Submit answer", "إرسال الإجابة")
    val nextQuestion = Tr("Next question", "السؤال التالي")
    val yourLevelResult = Tr("Your level result", "نتيجة مستواك")
    val strengths = Tr("Strengths", "نقاط القوة")
    val focus = Tr("Focus", "بحاجة إلى تركيز")
    val seeAll = Tr("See all", "عرض الكل")
    val noRecommendations = Tr("No recommendations yet", "لا توجد توصيات بعد")
    val noRecommendationsBody = Tr("As the academy publishes content for your level it will show up here.", "سيظهر هنا المحتوى الذي تنشره الأكاديمية لمستواك.")
    val browseCourses = Tr("Browse courses →", "تصفّح الدورات ←")
    val questionsCount = Tr("%d questions", "%d سؤال")
    val minutes = Tr("%d min", "%d دقيقة")
    val questionXofY = Tr("Question %1${'$'}s of %2${'$'}s", "السؤال %1${'$'}s من %2${'$'}s")
    val topPercentOfLearners = Tr("Top %d%% of learners", "ضمن أفضل %d%% من المتعلمين")
    val recommendedFor = Tr("Recommended for %s", "موصى به لمستوى %s")
    val answerRecorded = Tr("Answer recorded", "تم تسجيل إجابتك")
    val timeUpBody = Tr(
        "Your time for this test ran out. We scored everything you answered.",
        "انتهى وقت الاختبار. صحّحنا كل ما أجبت عنه.",
    )
    val chooseAllThatApply = Tr("Choose every correct answer", "اختر كل الإجابات الصحيحة")
    val notCompleted = Tr("Attempt not completed", "محاولة غير مكتملة")
    val notCompletedBody = Tr(
        "This attempt ended before any question was answered, so it has no level.",
        "انتهت هذه المحاولة قبل الإجابة عن أي سؤال، لذلك ليس لها مستوى.",
    )
    val retakeTest = Tr("Take the test", "ابدأ الاختبار")
    val questionUnavailable = Tr(
        "This question cannot be displayed",
        "تعذّر عرض هذا السؤال",
    )
    val questionUnavailableBody = Tr(
        "It has no answer options. Skip it to carry on with the test.",
        "لا توجد به خيارات للإجابة. تخطّه لمتابعة الاختبار.",
    )
    val skipQuestion = Tr("Skip question", "تخطي السؤال")
    val trueLabel = Tr("True", "صحيح")
    val falseLabel = Tr("False", "خطأ")
    val placementTests = Tr("Placement tests", "اختبارات تحديد المستوى")
    val teacherExercises = Tr("Teacher exercises", "تمارين المعلمين")
    val chooseTeacher = Tr("Choose a teacher", "اختر معلماً")
    val teacherExercisesIntro = Tr("Practice with exercises published by your teacher.", "تدرّب على تمارين ينشرها معلمك.")
    val noTeachers = Tr("No teachers available", "لا يوجد معلمون متاحون")
    val noExercises = Tr("No exercises published yet", "لا توجد تمارين منشورة بعد")
    val noExercisesBody = Tr("Choose another teacher or check back later.", "اختر معلماً آخر أو عد لاحقاً.")
    val exercise = Tr("Exercise", "تمرين")
    val startExercise = Tr("Start exercise", "ابدأ التمرين")
}
