package com.rork.pro.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import coil3.compose.AsyncImage
import com.rork.pro.data.Async
import com.rork.pro.data.Banner
import com.rork.pro.data.CatalogRepository
import com.rork.pro.data.Category
import com.rork.pro.data.Course
import com.rork.pro.data.TestRepository
import com.rork.pro.data.TestAttemptRow
import com.rork.pro.data.toAppError
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.Avatar
import com.rork.pro.ui.components.AdBanner
import com.rork.pro.ui.components.CoverImage
import com.rork.pro.ui.components.EmptyBlock
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LevelBadge
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.Pill
import com.rork.pro.ui.components.RatingRow
import com.rork.pro.ui.components.Refreshable
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.formatMoney
import com.rork.pro.ui.navigation.Routes
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalTime
import com.rork.pro.ui.i18n.StrHome
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.i18n.trf
import com.rork.pro.ui.i18n.Str

data class HomeData(
    val banners: List<Banner>,
    val categories: List<Category>,
    val featured: List<Course>,
    val latestResult: TestAttemptRow?,
)

class HomeViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<HomeData>>(Async.Loading)
    val state: StateFlow<Async<HomeData>> = _state.asStateFlow()

    private val _category = MutableStateFlow<String?>(null)
    val category: StateFlow<String?> = _category.asStateFlow()

    init {
        load()
    }

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    /** Re-reads everything without blanking what is already on screen. */
    fun refresh() {
        _refreshing.value = true
        load(quiet = true)
    }

    fun load(quiet: Boolean = false) {
        viewModelScope.launch {
            if (!quiet) _state.value = Async.Loading
            runCatching {
                HomeData(
                    banners = CatalogRepository.banners(),
                    categories = CatalogRepository.categories(),
                    featured = CatalogRepository.publishedCourses(categoryId = _category.value, limit = 8),
                    latestResult = TestRepository.latestResult(),
                )
            }.onSuccess { _state.value = Async.Success(it) }
                .onFailure { if (!quiet) _state.value = Async.Failure(it.toAppError()) }
            _refreshing.value = false
        }
    }

    fun selectCategory(id: String?) {
        _category.value = id
        load()
    }
}

@Composable
fun HomeScreen(navController: NavHostController, session: SessionViewModel) {
    val vm: HomeViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val selectedCategory by vm.category.collectAsStateWithLifecycle()
    val sessionState by session.state.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { session.refreshNotifications() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TopRow(
            unread = sessionState.unreadCount,
            onNotifications = { navController.navigate(Routes.NOTIFICATIONS) },
            onSearch = { navController.navigate(Routes.COURSES) },
        )

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load() }
            is Async.Success -> Refreshable(
                refreshing,
                {
                    vm.refresh()
                    session.refreshNotifications()
                },
            ) {
                HomeContent(
                    data = s.value,
                    greetingName = sessionState.profile?.displayName ?: tr(StrHome.thereFallback),
                    level = sessionState.profile?.currentLevel,
                    streak = sessionState.profile?.streakDays ?: 0,
                    selectedCategory = selectedCategory,
                    onCategory = vm::selectCategory,
                    navController = navController,
                )
            }
        }
    }
}

@Composable
private fun TopRow(unread: Int, onNotifications: () -> Unit, onSearch: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = Dimens.screenPadding, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = Ink.Amber, fontWeight = FontWeight.Black)) { append("7") }
                withStyle(SpanStyle(color = Ink.TextPrimary, fontWeight = FontWeight.Black)) { append("PRO") }
            },
            fontSize = 25.sp,
        )
        Row {
            IconButton(onClick = onNotifications) {
                BadgedBox(badge = {
                    if (unread > 0) Badge(containerColor = Ink.Amber, contentColor = Ink.OnAmber) {
                        Text(if (unread > 9) "9+" else unread.toString(), fontSize = 9.sp)
                    }
                }) {
                    Icon(Icons.Default.Notifications, tr(StrHome.notifications), tint = Ink.TextPrimary)
                }
            }
            IconButton(onClick = onSearch) {
                Icon(Icons.Default.Search, tr(StrHome.searchCourses), tint = Ink.TextPrimary)
            }
        }
    }
}

@Composable
private fun HomeContent(
    data: HomeData,
    greetingName: String,
    level: String?,
    streak: Int,
    selectedCategory: String?,
    onCategory: (String?) -> Unit,
    navController: NavHostController,
) {
    LazyColumn(
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = Dimens.screenPadding)) {
                Text(
                    trf(StrHome.greetingLine, greeting(), greetingName),
                    style = MaterialTheme.typography.headlineMedium,
                    color = Ink.TextPrimary,
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (level != null) {
                        LevelBadge(level)
                    } else {
                        Pill(tr(StrHome.takeFreeLevelTest), background = Ink.AmberSoft, foreground = Ink.Amber)
                    }
                    if (streak > 0) {
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(Ink.SurfaceHigh)
                                .padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(Icons.Default.LocalFireDepartment, null, tint = Ink.Amber, modifier = Modifier.size(15.dp))
                            Text(
                                trf(StrHome.dayStreak, streak),
                                color = Ink.TextPrimary,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }
        }

        if (data.latestResult == null) {
            item { PlacementPrompt(Modifier.padding(horizontal = Dimens.screenPadding)) { navController.navigate(Routes.TEST_START) } }
        } else {
            item {
                ResultRecap(
                    result = data.latestResult,
                    modifier = Modifier.padding(horizontal = Dimens.screenPadding),
                ) { navController.navigate(Routes.testResult(data.latestResult.id)) }
            }
        }

        // The server decides whether this learner sees an ad here at all.
        item { AdBanner("HOME", Modifier.padding(horizontal = Dimens.screenPadding)) }

        if (data.banners.isNotEmpty()) {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = Dimens.screenPadding),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(data.banners, key = { it.id }) { banner ->
                        HeroBanner(banner) { target ->
                            when {
                                target.isNullOrBlank() -> Unit
                                target.startsWith("course:") -> navController.navigate(Routes.courseDetail(target.removePrefix("course:")))
                                target == "test" -> navController.navigate(Routes.TEST_START)
                                else -> navController.navigate(Routes.COURSES)
                            }
                        }
                    }
                }
            }
        }

        if (data.categories.isNotEmpty()) {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = Dimens.screenPadding),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item {
                        CategoryChip(tr(StrHome.all), selectedCategory == null) { onCategory(null) }
                    }
                    items(data.categories, key = { it.id }) { category ->
                        CategoryChip(category.name, selectedCategory == category.id) { onCategory(category.id) }
                    }
                }
            }
        }

        item {
            SectionHeader(
                tr(StrHome.featuredCourses),
                Modifier.padding(horizontal = Dimens.screenPadding),
                actionLabel = tr(StrHome.seeAll),
                onAction = { navController.navigate(Routes.COURSES) },
            )
        }

        if (data.featured.isEmpty()) {
            item {
                EmptyBlock(
                    tr(StrHome.noCoursesYet),
                    tr(StrHome.noCoursesYetBody),
                )
            }
        } else {
            items(data.featured, key = { it.id }) { course ->
                CourseRowCard(
                    course = course,
                    modifier = Modifier.padding(horizontal = Dimens.screenPadding),
                ) { navController.navigate(Routes.courseDetail(course.id)) }
            }
        }

    }
}

private fun greeting(): String = when (LocalTime.now().hour) {
    in 5..11 -> tr(StrHome.goodMorning)
    in 12..16 -> tr(StrHome.goodAfternoon)
    else -> tr(StrHome.goodEvening)
}

@Composable
private fun PlacementPrompt(modifier: Modifier = Modifier, onStart: () -> Unit) {
    InkCard(
        modifier = modifier,
        onClick = onStart,
        color = Ink.Surface,
        borderColor = Ink.Amber.copy(alpha = 0.35f),
    ) {
        Text(tr(StrHome.freePlacementTest), style = MaterialTheme.typography.titleLarge, color = Ink.TextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            tr(StrHome.freePlacementBody),
            color = Ink.TextSecondary,
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))
        Pill(tr(StrHome.startTheTest))
    }
}

@Composable
private fun ResultRecap(result: TestAttemptRow, modifier: Modifier = Modifier, onOpen: () -> Unit) {
    InkCard(modifier = modifier, onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Ink.AmberSoft),
                contentAlignment = Alignment.Center,
            ) {
                Text(result.level ?: "—", color = Ink.Amber, fontWeight = FontWeight.Black, fontSize = 19.sp)
            }
            Column(Modifier.weight(1f)) {
                Text(tr(StrHome.yourLevelResult), color = Ink.TextPrimary, style = MaterialTheme.typography.titleMedium)
                Text(
                    trf(StrHome.scoredBreakdown, result.percent.toInt()),
                    color = Ink.TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun HeroBanner(banner: Banner, onClick: (String?) -> Unit) {
    Box(
        Modifier
            .width(320.dp)
            .aspectRatio(1.72f)
            .clip(RoundedCornerShape(Dimens.cardRadius))
            .background(Ink.SurfaceHigh)
            .clickable { onClick(banner.ctaTarget) },
    ) {
        if (!banner.imageUrl.isNullOrBlank()) {
            AsyncImage(
                model = banner.imageUrl,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xF00B1220), Color(0xB00B1220), Color(0x300B1220)),
                    ),
                ),
        )
        Column(
            Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                banner.title,
                color = Ink.TextPrimary,
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
            if (!banner.subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(banner.subtitle, color = Ink.Amber, style = MaterialTheme.typography.titleSmall)
            }
            if (!banner.ctaLabel.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Pill(banner.ctaLabel)
            }
        }
    }
}

@Composable
private fun CategoryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.titleSmall) },
        shape = RoundedCornerShape(999.dp),
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Ink.Surface,
            labelColor = Ink.TextSecondary,
            selectedContainerColor = Ink.AmberSoft,
            selectedLabelColor = Ink.Amber,
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = Ink.Hairline,
            selectedBorderColor = Ink.Amber,
            borderWidth = 1.dp,
            selectedBorderWidth = 1.dp,
        ),
    )
}

@Composable
fun CourseRowCard(course: Course, modifier: Modifier = Modifier, onClick: () -> Unit) {
    InkCard(modifier = modifier, onClick = onClick, contentPadding = PaddingValues(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CoverImage(
                course.thumbnailUrl,
                Modifier
                    .size(width = 118.dp, height = 96.dp)
                    .clip(RoundedCornerShape(14.dp)),
                fallbackLabel = course.title,
            )
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    course.title,
                    color = Ink.TextPrimary,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Avatar(course.teacher?.avatarUrl, course.teacher?.fullName, 22.dp)
                    Text(
                        course.teacher?.fullName ?: tr(StrHome.sevenProTeacher),
                        color = Ink.TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RatingRow(course.ratingAvg, course.ratingCount)
                    Pill(
                        if (course.isFreeCourse) tr(Str.free) else formatMoney(course.basePrice, course.baseCurrency),
                        background = if (course.isFreeCourse) Ink.TealSoft else Ink.Amber,
                        foreground = if (course.isFreeCourse) Ink.Teal else Ink.OnAmber,
                    )
                }
            }
        }
    }
}
