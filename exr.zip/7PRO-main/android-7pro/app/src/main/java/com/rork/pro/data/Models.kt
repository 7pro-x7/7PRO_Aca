package com.rork.pro.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

@Serializable
data class Profile(
    val id: String,
    val email: String? = null,
    @SerialName("full_name") val fullName: String? = null,
    val phone: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    val role: String = "STUDENT",
    val status: String = "ACTIVE",
    @SerialName("country_code") val countryCode: String? = null,
    @SerialName("current_level") val currentLevel: String? = null,
    @SerialName("streak_days") val streakDays: Int = 0,
    @SerialName("created_at") val createdAt: String? = null,
) {
    val isOwner: Boolean get() = role == "OWNER"
    val isStaff: Boolean get() = role == "OWNER" || role == "ADMIN"
    val isTeacher: Boolean get() = role == "TEACHER"
    val displayName: String get() = fullName?.takeIf { it.isNotBlank() } ?: email?.substringBefore('@') ?: "Learner"
}

@Serializable
data class AdminPermission(
    val id: String? = null,
    @SerialName("user_id") val userId: String,
    val permission: String,
)

@Serializable
data class Category(
    val id: String,
    val slug: String,
    val name: String,
    val icon: String? = null,
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("is_active") val isActive: Boolean = true,
)

@Serializable
data class Banner(
    val id: String,
    val placement: String = "HOME_HERO",
    val title: String,
    val subtitle: String? = null,
    @SerialName("image_url") val imageUrl: String? = null,
    @SerialName("cta_label") val ctaLabel: String? = null,
    @SerialName("cta_target") val ctaTarget: String? = null,
    @SerialName("ends_at") val endsAt: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("sort_order") val sortOrder: Int = 0,
)

@Serializable
data class TeacherRef(
    val id: String? = null,
    @SerialName("full_name") val fullName: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
)

@Serializable
data class Course(
    val id: String,
    @SerialName("teacher_id") val teacherId: String,
    @SerialName("category_id") val categoryId: String? = null,
    val title: String,
    val subtitle: String? = null,
    val description: String? = null,
    @SerialName("thumbnail_url") val thumbnailUrl: String? = null,
    val level: String? = null,
    @SerialName("base_price") val basePrice: Double = 0.0,
    @SerialName("base_currency") val baseCurrency: String = "USD",
    @SerialName("is_free") val isFree: Boolean = false,
    val status: String = "DRAFT",
    @SerialName("rejection_note") val rejectionNote: String? = null,
    @SerialName("certificate_enabled") val certificateEnabled: Boolean = true,
    @SerialName("certificate_min_percent") val certificateMinPercent: Int = 80,
    @SerialName("views_count") val viewsCount: Int = 0,
    @SerialName("enrollments_count") val enrollmentsCount: Int = 0,
    @SerialName("rating_avg") val ratingAvg: Double = 0.0,
    @SerialName("rating_count") val ratingCount: Int = 0,
    @SerialName("is_featured") val isFeatured: Boolean = false,
    @SerialName("created_at") val createdAt: String? = null,
    val teacher: TeacherRef? = null,
) {
    /**
     * Whether the course actually costs anything.
     *
     * A course carries both a free flag and a price, and the two can disagree: one created in
     * the studio sits at zero long before the flag is ever switched on. Nothing without a price
     * is a paid course, so every screen asks this instead of reading the raw flag.
     */
    val isFreeCourse: Boolean get() = isFree || basePrice <= 0.0
}

@Serializable
data class CourseSection(
    val id: String,
    @SerialName("course_id") val courseId: String,
    val title: String,
    val subtitle: String? = null,
    @SerialName("sort_order") val sortOrder: Int = 0,
)

@Serializable
data class Lesson(
    val id: String,
    @SerialName("course_id") val courseId: String,
    @SerialName("section_id") val sectionId: String? = null,
    val title: String,
    val description: String? = null,
    val kind: String = "VIDEO",
    @SerialName("video_url") val videoUrl: String? = null,
    @SerialName("document_url") val documentUrl: String? = null,
    val content: String? = null,
    @SerialName("duration_seconds") val durationSeconds: Int = 0,
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("is_preview") val isPreview: Boolean = false,
)

@Serializable
data class LessonQuiz(
    val id: String,
    @SerialName("lesson_id") val lessonId: String,
    val question: String,
    val options: List<String> = emptyList(),
    val points: Int = 1,
    @SerialName("sort_order") val sortOrder: Int = 0,
)

@Serializable
data class LessonProgress(
    val id: String? = null,
    @SerialName("lesson_id") val lessonId: String,
    @SerialName("course_id") val courseId: String,
    @SerialName("seconds_watched") val secondsWatched: Int = 0,
    @SerialName("is_completed") val isCompleted: Boolean = false,
)

@Serializable
data class Enrollment(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("course_id") val courseId: String,
    val status: String = "ACTIVE",
    @SerialName("progress_percent") val progressPercent: Double = 0.0,
    @SerialName("last_lesson_id") val lastLessonId: String? = null,
    @SerialName("completed_at") val completedAt: String? = null,
    val course: Course? = null,
)

@Serializable
data class TeacherProfile(
    val id: String,
    val headline: String? = null,
    val bio: String? = null,
    @SerialName("photo_url") val photoUrl: String? = null,
    @SerialName("cover_url") val coverUrl: String? = null,
    val subjects: List<String> = emptyList(),
    val languages: List<String> = emptyList(),
    @SerialName("experience_years") val experienceYears: Int = 0,
    val status: String = "APPROVED",
    @SerialName("accepting_new_students") val acceptingNewStudents: Boolean = false,
    @SerialName("can_manage_tests") val canManageTests: Boolean = false,
    @SerialName("commission_rate") val commissionRate: Double? = null,
    @SerialName("rating_avg") val ratingAvg: Double = 0.0,
    @SerialName("rating_count") val ratingCount: Int = 0,
    @SerialName("students_count") val studentsCount: Int = 0,
    val badge: String? = null,
    val profile: TeacherRef? = null,
)

@Serializable
data class Order(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("teacher_id") val teacherId: String? = null,
    @SerialName("item_type") val itemType: String,
    @SerialName("course_id") val courseId: String? = null,
    @SerialName("country_code") val countryCode: String,
    val currency: String,
    @SerialName("list_price") val listPrice: Double = 0.0,
    @SerialName("discount_amount") val discountAmount: Double = 0.0,
    @SerialName("total_amount") val totalAmount: Double = 0.0,
    @SerialName("commission_rate") val commissionRate: Double = 0.0,
    @SerialName("teacher_amount") val teacherAmount: Double = 0.0,
    @SerialName("platform_amount") val platformAmount: Double = 0.0,
    @SerialName("refunded_amount") val refundedAmount: Double = 0.0,
    val status: String = "PENDING",
    val provider: String? = null,
    @SerialName("checkout_url") val checkoutUrl: String? = null,
    @SerialName("failure_reason") val failureReason: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("paid_at") val paidAt: String? = null,
)

@Serializable
data class LedgerEntry(
    val id: String,
    @SerialName("teacher_id") val teacherId: String,
    val kind: String,
    val amount: Double,
    val currency: String,
    val status: String,
    @SerialName("available_at") val availableAt: String? = null,
    val note: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class Payout(
    val id: String,
    @SerialName("teacher_id") val teacherId: String,
    val amount: Double,
    val currency: String,
    val method: String? = null,
    val destination: String? = null,
    val reference: String? = null,
    val note: String? = null,
    val status: String = "PENDING",
    @SerialName("requested_at") val requestedAt: String? = null,
    @SerialName("paid_at") val paidAt: String? = null,
    val teacher: TeacherRef? = null,
)

@Serializable
data class Certificate(
    val id: String,
    val serial: String,
    @SerialName("course_title") val courseTitle: String,
    @SerialName("student_name") val studentName: String,
    @SerialName("teacher_name") val teacherName: String? = null,
    @SerialName("score_percent") val scorePercent: Double? = null,
    @SerialName("issued_at") val issuedAt: String? = null,
    @SerialName("verify_code") val verifyCode: String,
    val revoked: Boolean = false,
)

@Serializable
data class Review(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("target_type") val targetType: String,
    @SerialName("teacher_id") val teacherId: String? = null,
    @SerialName("course_id") val courseId: String? = null,
    val rating: Int,
    val body: String? = null,
    @SerialName("is_hidden") val isHidden: Boolean = false,
    @SerialName("created_at") val createdAt: String? = null,
    val author: TeacherRef? = null,
)

@Serializable
data class AppNotification(
    val id: Long,
    val kind: String,
    val title: String,
    val body: String? = null,
    /** Free-form payload the server attaches, used to open the right screen when tapped. */
    val data: JsonObject? = null,
    @SerialName("read_at") val readAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
) {
    private fun value(key: String): String? =
        data?.get(key)?.toString()?.trim('"')?.takeIf { it.isNotBlank() && it != "null" }

    /**
     * Where tapping this notification should land.
     *
     * Falls back to the notification list, so an unknown payload can never open a dead end.
     */
    val deepLink: String
        get() = value("course_id")?.let { "course/$it" }
            ?: value("attempt_id")?.let { "test-result/$it" }
            ?: "notifications"
}

@Serializable
data class SupportTicket(
    val id: String,
    @SerialName("user_id") val userId: String,
    val subject: String,
    val category: String? = null,
    val status: String = "OPEN",
    val priority: String = "NORMAL",
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class TicketMessage(
    val id: Long,
    @SerialName("ticket_id") val ticketId: String,
    @SerialName("sender_id") val senderId: String,
    val body: String,
    @SerialName("is_staff") val isStaff: Boolean = false,
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class PlacementTest(
    val id: String,
    val title: String,
    val description: String? = null,
    val scope: String = "PUBLIC",
    @SerialName("target_level") val targetLevel: String? = null,
    @SerialName("is_adaptive") val isAdaptive: Boolean = true,
    @SerialName("question_count") val questionCount: Int = 20,
    @SerialName("time_limit_seconds") val timeLimitSeconds: Int = 1200,
    @SerialName("passing_score") val passingScore: Double = 50.0,
    val status: String = "DRAFT",
    @SerialName("owner_id") val ownerId: String? = null,
    val owner: TeacherRef? = null,
)

@Serializable
data class TestQuestionView(
    val id: String,
    val kind: String,
    val skill: String,
    val difficulty: Int,
    val prompt: String,
    val options: List<String> = emptyList(),
    @SerialName("image_url") val imageUrl: String? = null,
    @SerialName("audio_url") val audioUrl: String? = null,
    @SerialName("video_url") val videoUrl: String? = null,
    val points: Double = 1.0,
)

@Serializable
data class NextQuestion(
    val done: Boolean = false,
    val reason: String? = null,
    val question: TestQuestionView? = null,
    val index: Int = 0,
    val total: Int = 0,
    /** Server-authoritative countdown, so the on-screen timer can never drift from the real limit. */
    @SerialName("seconds_left") val secondsLeft: Int? = null,
)

@Serializable
data class StartAttempt(
    @SerialName("attempt_id") val attemptId: String,
    val resumed: Boolean = false,
    @SerialName("question_count") val questionCount: Int = 0,
    @SerialName("time_limit_seconds") val timeLimitSeconds: Int = 0,
    @SerialName("seconds_left") val secondsLeft: Int? = null,
    val answered: Int = 0,
    val title: String? = null,
)

@Serializable
data class AnswerResult(
    val correct: Boolean = false,
    val earned: Double = 0.0,
    val explanation: String? = null,
    /** False when the question carries no model answer, so it is recorded but not scored. */
    val graded: Boolean = true,
)

@Serializable
data class TestResult(
    @SerialName("attempt_id") val attemptId: String,
    val percent: Double = 0.0,
    val level: String? = null,
    val skills: Map<String, Double> = emptyMap(),
    val strengths: List<String> = emptyList(),
    val weaknesses: List<String> = emptyList(),
    @SerialName("better_than_percent") val betterThanPercent: Double? = null,
    val passed: Boolean = false,
    val status: String = "SUBMITTED",
    val answered: Int = 0,
)

@Serializable
data class TestAttemptRow(
    val id: String,
    @SerialName("test_id") val testId: String,
    val status: String,
    val percent: Double = 0.0,
    val level: String? = null,
    @SerialName("skill_breakdown") val skillBreakdown: Map<String, Double> = emptyMap(),
    val strengths: List<String> = emptyList(),
    val weaknesses: List<String> = emptyList(),
    @SerialName("submitted_at") val submittedAt: String? = null,
)

@Serializable
data class PriceQuote(
    @SerialName("item_type") val itemType: String,
    @SerialName("course_id") val courseId: String? = null,
    @SerialName("teacher_id") val teacherId: String? = null,
    @SerialName("country_code") val countryCode: String = "",
    val currency: String = "",
    @SerialName("list_price") val listPrice: Double = 0.0,
    @SerialName("discount_amount") val discountAmount: Double = 0.0,
    @SerialName("total_amount") val totalAmount: Double = 0.0,
    val coupon: CouponResult? = null,
)

@Serializable
data class CouponResult(
    val valid: Boolean = false,
    val discount: Double = 0.0,
    val code: String? = null,
    val reason: String? = null,
)

/**
 * One payment option, exactly as it exists on the platform's own Paymob account.
 *
 * [kind] is the family the app draws an icon and a translated name for; [label] is whatever the
 * integration is called in the Paymob dashboard and is shown as-is for anything unrecognised.
 */
@Serializable
data class PaymentMethod(
    val id: String,
    val kind: String = "OTHER",
    val label: String = "",
)

@Serializable
data class PaymentMethods(
    val ok: Boolean = false,
    val methods: List<PaymentMethod> = emptyList(),
)

@Serializable
data class CheckoutSession(
    val ok: Boolean = false,
    @SerialName("order_id") val orderId: String? = null,
    @SerialName("checkout_url") val checkoutUrl: String? = null,
    @SerialName("total_amount") val totalAmount: Double = 0.0,
    val currency: String? = null,
    val free: Boolean = false,
    val error: String? = null,
)

@Serializable
data class TeacherBalance(
    val pending: Double = 0.0,
    val available: Double = 0.0,
    val paid: Double = 0.0,
    val gross: Double = 0.0,
    val currency: String = "EGP",
    @SerialName("minimum_payout") val minimumPayout: Double = 1000.0,
)

@Serializable
data class CountryPricing(
    val id: String? = null,
    @SerialName("country_code") val countryCode: String,
    val currency: String,
    @SerialName("fx_multiplier") val fxMultiplier: Double = 1.0,
    @SerialName("round_to") val roundTo: Double = 1.0,
    @SerialName("discount_percent") val discountPercent: Double = 0.0,
    @SerialName("region_group") val regionGroup: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
)

@Serializable
data class Coupon(
    val id: String? = null,
    val code: String,
    val kind: String = "PERCENT",
    val amount: Double = 0.0,
    @SerialName("max_uses") val maxUses: Int? = null,
    @SerialName("used_count") val usedCount: Int = 0,
    @SerialName("expires_at") val expiresAt: String? = null,
    @SerialName("is_active") val isActive: Boolean = true,
)

@Serializable
data class AdmobPlacement(
    val id: String? = null,
    val screen: String,
    val section: String? = null,
    val format: String = "BANNER",
    @SerialName("ad_unit_id") val adUnitId: String,
    val frequency: Int = 1,
    val spacing: Int = 4,
    @SerialName("max_impressions_per_session") val maxImpressions: Int = 10,
    @SerialName("is_enabled") val isEnabled: Boolean = false,
    @SerialName("free_content_only") val freeContentOnly: Boolean = true,
)

@Serializable
data class AppSetting(
    val key: String,
    val value: JsonElement,
    val description: String? = null,
)

@Serializable
data class AuditLog(
    val id: Long,
    val action: String,
    @SerialName("target_type") val targetType: String? = null,
    @SerialName("target_id") val targetId: String? = null,
    @SerialName("actor_role") val actorRole: String? = null,
    val metadata: JsonObject? = null,
    @SerialName("created_at") val createdAt: String? = null,
    val actor: TeacherRef? = null,
)

@Serializable
data class RefundRow(
    val id: String,
    @SerialName("order_id") val orderId: String,
    val kind: String,
    val amount: Double,
    val currency: String,
    val reason: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class Recommendations(
    val courses: List<Course> = emptyList(),
)

