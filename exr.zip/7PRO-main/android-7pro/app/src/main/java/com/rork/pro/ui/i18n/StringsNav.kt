package com.rork.pro.ui.i18n

/** Bottom tabs and detail headers. */
object StrNav {
    val homeTab = Tr("Home", "الرئيسية")
    val coursesTab = Tr("Courses", "الدورات")
    val testTab = Tr("Level test", "اختبار المستوى")
    val profileTab = Tr("Profile", "حسابي")
    val back = Tr("Back", "رجوع")
}
