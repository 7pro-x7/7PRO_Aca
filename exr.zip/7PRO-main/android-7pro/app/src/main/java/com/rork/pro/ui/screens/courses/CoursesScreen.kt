package com.rork.pro.ui.screens.courses

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.rork.pro.data.Async
import com.rork.pro.data.CatalogRepository
import com.rork.pro.data.Category
import com.rork.pro.data.CommerceRepository
import com.rork.pro.data.Course
import com.rork.pro.data.Enrollment
import com.rork.pro.data.toAppError
import com.rork.pro.ui.components.EmptyBlock
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.Refreshable
import com.rork.pro.ui.components.SkillBar
import com.rork.pro.ui.navigation.Routes
import com.rork.pro.ui.screens.home.CourseRowCard
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.rork.pro.ui.i18n.StrCourses
import com.rork.pro.ui.i18n.tr

data class CatalogData(
    val categories: List<Category>,
    val courses: List<Course>,
    val myCourses: List<Enrollment>,
)

class CoursesViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<CatalogData>>(Async.Loading)
    val state: StateFlow<Async<CatalogData>> = _state.asStateFlow()

    var query: String = ""
        private set
    private val _categoryId = MutableStateFlow<String?>(null)
    val categoryId: StateFlow<String?> = _categoryId.asStateFlow()

    init {
        load()
    }

    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing.asStateFlow()

    /** Re-reads the catalogue without blanking the list that is already on screen. */
    fun refresh() {
        _refreshing.value = true
        load(quiet = true)
    }

    fun load(quiet: Boolean = false) {
        viewModelScope.launch {
            if (!quiet) _state.value = Async.Loading
            runCatching {
                CatalogData(
                    categories = CatalogRepository.categories(),
                    courses = CatalogRepository.publishedCourses(
                        categoryId = _categoryId.value,
                        search = query.takeIf { it.isNotBlank() },
                    ),
                    myCourses = CommerceRepository.myEnrollments(),
                )
            }.onSuccess { _state.value = Async.Success(it) }
                .onFailure { if (!quiet) _state.value = Async.Failure(it.toAppError()) }
            _refreshing.value = false
        }
    }

    fun search(text: String) {
        query = text
        load()
    }

    fun selectCategory(id: String?) {
        _categoryId.value = id
        load()
    }
}

@Composable
fun CoursesScreen(navController: NavHostController) {
    val vm: CoursesViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val selected by vm.categoryId.collectAsStateWithLifecycle()
    val refreshing by vm.refreshing.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { vm.load() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            tr(StrCourses.coursesTitle),
            style = MaterialTheme.typography.headlineMedium,
            color = Ink.TextPrimary,
            modifier = Modifier.padding(horizontal = Dimens.screenPadding, vertical = 10.dp),
        )

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = Dimens.screenPadding),
            placeholder = { Text(tr(StrCourses.searchCourses)) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Ink.TextMuted) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                imeAction = androidx.compose.ui.text.input.ImeAction.Search,
            ),
            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { vm.search(text) }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Ink.Surface,
                unfocusedContainerColor = Ink.Surface,
                focusedBorderColor = Ink.Amber,
                unfocusedBorderColor = Ink.Hairline,
                cursorColor = Ink.Amber,
                focusedTextColor = Ink.TextPrimary,
                unfocusedTextColor = Ink.TextPrimary,
            ),
        )

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load() }
            is Async.Success -> {
                val data = s.value
                Refreshable(refreshing, { vm.refresh() }) {
                LazyColumn(
                    contentPadding = PaddingValues(top = 14.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (data.categories.isNotEmpty()) {
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = Dimens.screenPadding),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                item {
                                    FilterChip(
                                        selected = selected == null,
                                        onClick = { vm.selectCategory(null) },
                                        label = { Text(tr(StrCourses.all)) },
                                        shape = RoundedCornerShape(999.dp),
                                        colors = chipColors(),
                                    )
                                }
                                items(data.categories, key = { it.id }) { c ->
                                    FilterChip(
                                        selected = selected == c.id,
                                        onClick = { vm.selectCategory(c.id) },
                                        label = { Text(c.name) },
                                        shape = RoundedCornerShape(999.dp),
                                        colors = chipColors(),
                                    )
                                }
                            }
                        }
                    }

                    if (data.myCourses.isNotEmpty()) {
                        item {
                            SectionHeader(tr(StrCourses.continueLearning), Modifier.padding(horizontal = Dimens.screenPadding))
                        }
                        items(data.myCourses, key = { it.id }) { enrollment ->
                            EnrolledCard(enrollment, Modifier.padding(horizontal = Dimens.screenPadding)) {
                                navController.navigate(Routes.coursePlayer(enrollment.courseId))
                            }
                        }
                        item { Spacer(Modifier.height(6.dp)) }
                    }

                    item {
                        SectionHeader(tr(StrCourses.allCourses), Modifier.padding(horizontal = Dimens.screenPadding))
                    }

                    if (data.courses.isEmpty()) {
                        item {
                            EmptyBlock(
                                tr(StrCourses.nothingHereYet),
                                if (vm.query.isBlank()) {
                                    tr(StrCourses.publishedAppearHere)
                                } else {
                                    tr(StrCourses.noCourseMatched)
                                },
                            )
                        }
                    } else {
                        items(data.courses, key = { it.id }) { course ->
                            CourseRowCard(course, Modifier.padding(horizontal = Dimens.screenPadding)) {
                                navController.navigate(Routes.courseDetail(course.id))
                            }
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    containerColor = Ink.Surface,
    labelColor = Ink.TextSecondary,
    selectedContainerColor = Ink.AmberSoft,
    selectedLabelColor = Ink.Amber,
)

@Composable
private fun EnrolledCard(enrollment: Enrollment, modifier: Modifier = Modifier, onClick: () -> Unit) {
    InkCard(modifier = modifier, onClick = onClick) {
        Text(
            enrollment.course?.title ?: tr(StrCourses.yourCourse),
            color = Ink.TextPrimary,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 2,
        )
        Spacer(Modifier.height(10.dp))
        SkillBar(tr(StrCourses.progress), enrollment.progressPercent)
    }
}
