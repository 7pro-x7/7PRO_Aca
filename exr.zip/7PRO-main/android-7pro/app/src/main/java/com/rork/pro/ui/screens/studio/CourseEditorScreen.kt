package com.rork.pro.ui.screens.studio

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.rork.pro.data.AppError
import com.rork.pro.data.Async
import com.rork.pro.data.CatalogRepository
import com.rork.pro.data.Category
import com.rork.pro.data.CourseDraft
import com.rork.pro.data.CourseSection
import com.rork.pro.data.CourseStudioRepository
import com.rork.pro.data.Lesson
import com.rork.pro.data.MediaRepository
import com.rork.pro.data.toAppError
import com.rork.pro.ui.SessionViewModel
import com.rork.pro.ui.components.CoverImage
import com.rork.pro.ui.components.Divider
import com.rork.pro.ui.components.ErrorBlock
import com.rork.pro.ui.components.InkCard
import com.rork.pro.ui.components.LoadingBlock
import com.rork.pro.ui.components.Pill
import com.rork.pro.ui.components.PrimaryAction
import com.rork.pro.ui.components.SecondaryAction
import com.rork.pro.ui.components.SectionHeader
import com.rork.pro.ui.components.StatusPill
import com.rork.pro.ui.i18n.StrStudio
import com.rork.pro.ui.i18n.codeLabel
import com.rork.pro.ui.i18n.levelLabel
import com.rork.pro.ui.i18n.tr
import com.rork.pro.ui.navigation.DetailHeader
import com.rork.pro.ui.screens.auth.InkField
import com.rork.pro.ui.theme.Dimens
import com.rork.pro.ui.theme.Ink
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private val LEVELS = listOf("A1", "A2", "B1", "B2", "C1", "C2")
private val LESSON_KINDS = listOf("VIDEO", "DOCUMENT", "TEXT", "QUIZ")

/** The editable half of a course; the curriculum is saved row by row as it is edited. */
data class CourseForm(
    val title: String,
    val subtitle: String,
    val description: String,
    val thumbnailUrl: String,
    val level: String,
    val categoryId: String?,
    val price: Double,
    val currency: String,
    val isFree: Boolean,
    val certificateEnabled: Boolean,
)

class CourseEditorViewModel : ViewModel() {
    private val _state = MutableStateFlow<Async<CourseDraft>>(Async.Loading)
    val state: StateFlow<Async<CourseDraft>> = _state.asStateFlow()

    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _uploading = MutableStateFlow(false)
    val uploading: StateFlow<Boolean> = _uploading.asStateFlow()

    private val _error = MutableStateFlow<AppError?>(null)
    val error: StateFlow<AppError?> = _error.asStateFlow()

    private val _savedTick = MutableStateFlow(0)
    val savedTick: StateFlow<Int> = _savedTick.asStateFlow()

    /** False when the owner requires review before a teacher's course can go live. */
    private val _directPublish = MutableStateFlow(true)
    val directPublish: StateFlow<Boolean> = _directPublish.asStateFlow()

    private var courseId: String = ""
    private var bound = false

    fun bind(id: String) {
        if (bound && courseId == id) return
        courseId = id
        bound = true
        load()
        viewModelScope.launch {
            runCatching { CatalogRepository.categories() }.onSuccess { _categories.value = it }
            runCatching { CatalogRepository.settings() }.onSuccess { settings ->
                _directPublish.value = settings["courses.teacher_direct_publish"] != "false"
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            runCatching { CourseStudioRepository.draft(courseId) }
                .onSuccess { _state.value = Async.Success(it) }
                .onFailure { _state.value = Async.Failure(it.toAppError()) }
        }
    }

    /** Saves the detail form, optionally moving the course to a new status in the same action. */
    fun save(form: CourseForm, thenStatus: String? = null) {
        act {
            CourseStudioRepository.saveCourse(
                id = courseId,
                title = form.title.trim(),
                subtitle = form.subtitle.trim(),
                description = form.description.trim(),
                thumbnailUrl = form.thumbnailUrl.trim(),
                level = form.level.trim(),
                categoryId = form.categoryId,
                price = form.price,
                currency = form.currency.trim(),
                isFree = form.isFree,
                certificateEnabled = form.certificateEnabled,
            )
            if (thenStatus != null) CourseStudioRepository.setStatus(courseId, thenStatus)
            _savedTick.value += 1
        }
    }

    fun deleteCourse(onDeleted: () -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            runCatching { CourseStudioRepository.deleteCourse(courseId) }
                .onSuccess { onDeleted() }
                .onFailure { _error.value = it.toAppError() }
            _busy.value = false
        }
    }

    fun addSection(title: String, count: Int) = act {
        CourseStudioRepository.addSection(courseId, title, count)
        CourseStudioRepository.resequence(courseId)
    }

    fun renameSection(id: String, title: String) = act { CourseStudioRepository.renameSection(id, title) }

    fun deleteSection(id: String) = act {
        CourseStudioRepository.deleteSection(id)
        CourseStudioRepository.resequence(courseId)
    }

    fun moveSection(sections: List<CourseSection>, from: Int, to: Int) {
        if (to !in sections.indices) return
        val reordered = sections.toMutableList().apply { add(to, removeAt(from)) }
        act {
            CourseStudioRepository.reorderSections(reordered)
            CourseStudioRepository.resequence(courseId)
        }
    }

    /** Moves a lesson inside its own group, then renumbers the course so playback order follows. */
    fun moveLesson(draft: CourseDraft, sectionId: String?, lessons: List<Lesson>, from: Int, to: Int) {
        if (from !in lessons.indices || to !in lessons.indices) return
        val reordered = lessons.toMutableList().apply { add(to, removeAt(from)) }
        val full = buildList {
            draft.sections.forEach { section ->
                addAll(if (section.id == sectionId) reordered else draft.lessonsIn(section.id))
            }
            addAll(if (sectionId == null) reordered else draft.looseLessons)
        }
        act { CourseStudioRepository.reorderLessons(full) }
    }

    fun saveLesson(
        id: String?,
        sectionId: String?,
        title: String,
        kind: String,
        videoUrl: String,
        documentUrl: String,
        content: String,
        minutes: Int,
        sortOrder: Int,
        isPreview: Boolean,
    ) = act {
        CourseStudioRepository.saveLesson(
            id = id,
            courseId = courseId,
            sectionId = sectionId,
            title = title.trim(),
            kind = kind,
            videoUrl = videoUrl.trim(),
            documentUrl = documentUrl.trim(),
            content = content.trim(),
            durationSeconds = minutes * 60,
            sortOrder = sortOrder,
            isPreview = isPreview,
        )
        CourseStudioRepository.resequence(courseId)
    }

    fun deleteLesson(id: String) = act {
        CourseStudioRepository.deleteLesson(id)
        CourseStudioRepository.resequence(courseId)
    }

    /** Reads the picked file and uploads it, handing the public URL back to the form. */
    fun upload(context: android.content.Context, uri: Uri, folder: String, onDone: (String) -> Unit) {
        viewModelScope.launch {
            _uploading.value = true
            _error.value = null
            runCatching {
                val file = MediaRepository.read(context, uri)
                MediaRepository.upload(file, folder)
            }.onSuccess { onDone(it) }
                .onFailure { _error.value = it.toAppError() }
            _uploading.value = false
        }
    }

    fun clearError() {
        _error.value = null
    }

    private fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            _error.value = null
            runCatching { block() }.onFailure { _error.value = it.toAppError() }
            _busy.value = false
            load()
        }
    }
}

/**
 * One editor for both dashboards. What the caller may do is decided by the database:
 * teachers reach their own courses, `courses.manage` holders reach every course.
 */
@Composable
fun CourseEditorScreen(navController: NavHostController, session: SessionViewModel, courseId: String) {
    val vm: CourseEditorViewModel = viewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val categories by vm.categories.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val uploading by vm.uploading.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val directPublish by vm.directPublish.collectAsStateWithLifecycle()
    val savedTick by vm.savedTick.collectAsStateWithLifecycle()
    val sessionState by session.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(courseId) { vm.bind(courseId) }

    var title by remember { mutableStateOf("") }
    var subtitle by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var thumb by remember { mutableStateOf("") }
    var level by remember { mutableStateOf("") }
    var categoryId by remember { mutableStateOf<String?>(null) }
    var price by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("EGP") }
    var isFree by remember { mutableStateOf(false) }
    var certificate by remember { mutableStateOf(true) }
    var seeded by remember { mutableStateOf(false) }

    var lessonSheet by remember { mutableStateOf<LessonTarget?>(null) }
    var sectionDialog by remember { mutableStateOf<SectionDialog?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    val pendingPick = remember { mutableStateOf<((Uri) -> Unit)?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { pendingPick.value?.invoke(it) }
        pendingPick.value = null
    }

    val draft = (state as? Async.Success)?.value
    LaunchedEffect(draft?.course?.id) {
        val course = draft?.course ?: return@LaunchedEffect
        if (seeded) return@LaunchedEffect
        title = course.title
        subtitle = course.subtitle.orEmpty()
        description = course.description.orEmpty()
        thumb = course.thumbnailUrl.orEmpty()
        level = course.level.orEmpty()
        categoryId = course.categoryId
        price = if (course.basePrice > 0) course.basePrice.toString().removeSuffix(".0") else ""
        currency = course.baseCurrency
        isFree = course.isFreeCourse
        certificate = course.certificateEnabled
        seeded = true
    }

    fun form(): CourseForm = CourseForm(
        title = title,
        subtitle = subtitle,
        description = description,
        thumbnailUrl = thumb,
        level = level,
        categoryId = categoryId,
        price = price.toDoubleOrNull() ?: 0.0,
        currency = currency,
        isFree = isFree || (price.toDoubleOrNull() ?: 0.0) <= 0.0,
        certificateEnabled = certificate,
    )

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding(),
    ) {
        DetailHeader(
            draft?.course?.title?.takeIf { it.isNotBlank() } ?: tr(StrStudio.editCourse),
            onBack = { navController.popBackStack() },
            trailing = { draft?.let { StatusPill(it.course.status, Modifier.padding(end = 12.dp)) } },
        )

        when (val s = state) {
            is Async.Loading -> LoadingBlock(Modifier.fillMaxSize())
            is Async.Failure -> ErrorBlock(s.error, Modifier.fillMaxSize()) { vm.load() }
            is Async.Success -> {
                val course = s.value.course
                val canReviewOthers = sessionState.can("courses.manage")
                val needsReview = !canReviewOthers && !directPublish

                Box(Modifier.weight(1f)) {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = Dimens.screenPadding, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        item {
                            StatusNotice(course.status, course.rejectionNote, needsReview)
                        }

                        if (canReviewOthers && !course.teacher?.fullName.isNullOrBlank()) {
                            item {
                                Text(
                                    "${tr(StrStudio.ownedBy)}: ${course.teacher?.fullName}",
                                    color = Ink.TextMuted,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }

                        item { SectionHeader(tr(StrStudio.cover)) }
                        item {
                            CoverPicker(
                                url = thumb,
                                uploading = uploading,
                                onPick = {
                                    pendingPick.value = { uri ->
                                        vm.upload(context, uri, "covers") { thumb = it }
                                    }
                                    picker.launch("image/*")
                                },
                                onClear = { thumb = "" },
                            )
                        }

                        item { SectionHeader(tr(StrStudio.details)) }
                        item {
                            InkCard {
                                InkField(title, { title = it }, tr(StrStudio.titleField))
                                Spacer(Modifier.height(8.dp))
                                InkField(subtitle, { subtitle = it }, tr(StrStudio.subtitleField))
                                Spacer(Modifier.height(8.dp))
                                InkField(
                                    description,
                                    { description = it },
                                    tr(StrStudio.descriptionField),
                                    singleLine = false,
                                    minLines = 4,
                                )
                                Spacer(Modifier.height(14.dp))
                                Text(tr(StrStudio.levelField), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(6.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(LEVELS) { option ->
                                        FilterChip(levelLabel(option).ifBlank { option }, level == option) {
                                            level = if (level == option) "" else option
                                        }
                                    }
                                }
                                if (categories.isNotEmpty()) {
                                    Spacer(Modifier.height(14.dp))
                                    Text(tr(StrStudio.categoryField), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                                    Spacer(Modifier.height(6.dp))
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        item {
                                            FilterChip(tr(StrStudio.noCategory), categoryId == null) { categoryId = null }
                                        }
                                        items(categories) { category ->
                                            FilterChip(category.name, categoryId == category.id) {
                                                categoryId = category.id
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item { SectionHeader(tr(StrStudio.pricing)) }
                        item {
                            InkCard {
                                ToggleRow(tr(StrStudio.freeCourse), tr(StrStudio.freeCourseSub), isFree) { isFree = it }
                                if (!isFree) {
                                    Spacer(Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(Modifier.weight(1f)) {
                                            InkField(
                                                price,
                                                { price = it.filter { c -> c.isDigit() || c == '.' } },
                                                tr(StrStudio.priceField),
                                                keyboardType = KeyboardType.Decimal,
                                            )
                                        }
                                        Box(Modifier.weight(1f)) {
                                            InkField(
                                                currency,
                                                { currency = it.uppercase().take(3) },
                                                tr(StrStudio.currencyField),
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                Divider()
                                Spacer(Modifier.height(10.dp))
                                ToggleRow(
                                    tr(StrStudio.certificate),
                                    tr(StrStudio.certificateSub),
                                    certificate,
                                ) { certificate = it }
                            }
                        }

                        item {
                            SectionHeader(
                                tr(StrStudio.curriculum),
                                actionLabel = tr(StrStudio.addSection),
                                onAction = { sectionDialog = SectionDialog(null, "") },
                            )
                        }

                        if (s.value.sections.isEmpty() && s.value.lessons.isEmpty()) {
                            item {
                                InkCard {
                                    Text(
                                        tr(StrStudio.emptyCurriculum),
                                        color = Ink.TextMuted,
                                        style = MaterialTheme.typography.bodyMedium,
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    SecondaryAction(tr(StrStudio.addLesson), Modifier.fillMaxWidth()) {
                                        lessonSheet = LessonTarget(null, null, s.value.lessons.size)
                                    }
                                }
                            }
                        }

                        itemsIndexed(s.value.sections) { index, section ->
                            val sectionLessons = s.value.lessonsIn(section.id)
                            SectionCard(
                                section = section,
                                lessons = sectionLessons,
                                isFirst = index == 0,
                                isLast = index == s.value.sections.lastIndex,
                                onMove = { delta -> vm.moveSection(s.value.sections, index, index + delta) },
                                onRename = { sectionDialog = SectionDialog(section.id, section.title) },
                                onDelete = { vm.deleteSection(section.id) },
                                onAddLesson = {
                                    lessonSheet = LessonTarget(null, section.id, s.value.lessons.size)
                                },
                                onEditLesson = { lesson ->
                                    lessonSheet = LessonTarget(lesson, section.id, lesson.sortOrder)
                                },
                                onMoveLesson = { lesson, delta ->
                                    val position = sectionLessons.indexOf(lesson)
                                    vm.moveLesson(s.value, section.id, sectionLessons, position, position + delta)
                                },
                                onDeleteLesson = { vm.deleteLesson(it.id) },
                            )
                        }

                        val loose = s.value.looseLessons
                        if (loose.isNotEmpty()) {
                            item {
                                SectionCard(
                                    section = null,
                                    lessons = loose,
                                    isFirst = true,
                                    isLast = true,
                                    onMove = {},
                                    onRename = {},
                                    onDelete = {},
                                    onAddLesson = { lessonSheet = LessonTarget(null, null, s.value.lessons.size) },
                                    onEditLesson = { lesson -> lessonSheet = LessonTarget(lesson, null, lesson.sortOrder) },
                                    onMoveLesson = { lesson, delta ->
                                        val position = loose.indexOf(lesson)
                                        vm.moveLesson(s.value, null, loose, position, position + delta)
                                    },
                                    onDeleteLesson = { vm.deleteLesson(it.id) },
                                )
                            }
                        }

                        item { SectionHeader(tr(StrStudio.dangerZone)) }
                        item {
                            InkCard(borderColor = Ink.Coral.copy(alpha = 0.2f)) {
                                Text(tr(StrStudio.archiveCourse), color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
                                Text(tr(StrStudio.archiveCourseSub), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(10.dp))
                                SecondaryAction(tr(StrStudio.archiveCourse), Modifier.fillMaxWidth()) {
                                    vm.save(form(), thenStatus = "ARCHIVED")
                                }
                                Spacer(Modifier.height(16.dp))
                                Divider()
                                Spacer(Modifier.height(16.dp))
                                Text(tr(StrStudio.deleteCourse), color = Ink.Coral, style = MaterialTheme.typography.titleSmall)
                                Text(tr(StrStudio.deleteCourseSub), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(10.dp))
                                SecondaryAction(tr(StrStudio.deleteCourse), Modifier.fillMaxWidth()) { confirmDelete = true }
                            }
                        }

                        error?.let {
                            item {
                                Text(it.message, color = Ink.Coral, style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        item { Spacer(Modifier.height(4.dp)) }
                    }
                }

                EditorActionBar(
                    status = course.status,
                    needsReview = needsReview,
                    busy = busy,
                    savedTick = savedTick,
                    onSave = { vm.save(form()) },
                    onPublish = { vm.save(form(), thenStatus = "PUBLISHED") },
                    onUnpublish = { vm.save(form(), thenStatus = "DRAFT") },
                )

                if (lessonSheet != null) {
                    LessonSheet(
                        target = lessonSheet!!,
                        uploading = uploading,
                        onPickMedia = { mime, assign ->
                            pendingPick.value = { uri -> vm.upload(context, uri, "lessons", assign) }
                            picker.launch(mime)
                        },
                        onDismiss = { lessonSheet = null },
                        onSave = { title, kind, video, document, content, minutes, preview ->
                            val target = lessonSheet
                            vm.saveLesson(
                                id = target?.lesson?.id,
                                sectionId = target?.sectionId,
                                title = title,
                                kind = kind,
                                videoUrl = video,
                                documentUrl = document,
                                content = content,
                                minutes = minutes,
                                sortOrder = target?.sortOrder ?: 0,
                                isPreview = preview,
                            )
                            lessonSheet = null
                        },
                    )
                }

                sectionDialog?.let { dialog ->
                    SectionTitleDialog(
                        initial = dialog.title,
                        onDismiss = { sectionDialog = null },
                        onConfirm = { value ->
                            if (dialog.id == null) {
                                vm.addSection(value, s.value.sections.size)
                            } else {
                                vm.renameSection(dialog.id, value)
                            }
                            sectionDialog = null
                        },
                    )
                }

                if (confirmDelete) {
                    AlertDialog(
                        onDismissRequest = { confirmDelete = false },
                        containerColor = Ink.Surface,
                        titleContentColor = Ink.TextPrimary,
                        textContentColor = Ink.TextSecondary,
                        title = { Text(tr(StrStudio.deleteCourse)) },
                        text = { Text(tr(StrStudio.deleteCourseConfirm)) },
                        confirmButton = {
                            TextButton(onClick = {
                                confirmDelete = false
                                vm.deleteCourse { navController.popBackStack() }
                            }) { Text(tr(StrStudio.confirmDelete), color = Ink.Coral) }
                        },
                        dismissButton = {
                            TextButton(onClick = { confirmDelete = false }) {
                                Text(tr(StrStudio.cancel), color = Ink.TextMuted)
                            }
                        },
                    )
                }
            }
        }
    }
}

private data class LessonTarget(val lesson: Lesson?, val sectionId: String?, val sortOrder: Int)

private data class SectionDialog(val id: String?, val title: String)

@Composable
private fun StatusNotice(status: String, rejectionNote: String?, needsReview: Boolean) {
    val (text, color) = when (status) {
        "PUBLISHED" -> tr(StrStudio.publishedNotice) to Ink.Teal
        "PENDING_REVIEW" -> tr(StrStudio.reviewNotice) to Ink.Amber
        "REJECTED" -> tr(StrStudio.rejectedNotice) to Ink.Coral
        else -> (if (needsReview) tr(StrStudio.reviewRequiredNotice) else tr(StrStudio.draftNotice)) to Ink.TextMuted
    }
    InkCard(contentPadding = PaddingValues(14.dp)) {
        Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
        if (status == "REJECTED" && !rejectionNote.isNullOrBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(rejectionNote, color = Ink.TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CoverPicker(url: String, uploading: Boolean, onPick: () -> Unit, onClear: () -> Unit) {
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(Dimens.cardRadius))
                .clickable(enabled = !uploading, onClick = onPick),
            contentAlignment = Alignment.Center,
        ) {
            CoverImage(url.takeIf { it.isNotBlank() }, Modifier.fillMaxSize())
            if (uploading) {
                CircularProgressIndicator(color = Ink.Amber, strokeWidth = 2.5.dp, modifier = Modifier.size(28.dp))
            } else if (url.isBlank()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Image, null, tint = Ink.Amber, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(6.dp))
                    Text(tr(StrStudio.addCover), color = Ink.TextSecondary, style = MaterialTheme.typography.bodySmall)
                    Text(tr(StrStudio.uploadLimit), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (url.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryAction(tr(StrStudio.replaceCover), Modifier.weight(1f), enabled = !uploading, onClick = onPick)
                SecondaryAction(tr(StrStudio.removeCover), Modifier.weight(1f), onClick = onClear)
            }
        }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink.TextPrimary, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Ink.Canvas,
                checkedTrackColor = Ink.Amber,
                uncheckedThumbColor = Ink.TextMuted,
                uncheckedTrackColor = Ink.SurfaceHigh,
                uncheckedBorderColor = Ink.Hairline,
            ),
        )
    }
}

@Composable
private fun SectionCard(
    section: CourseSection?,
    lessons: List<Lesson>,
    isFirst: Boolean,
    isLast: Boolean,
    onMove: (Int) -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onAddLesson: () -> Unit,
    onEditLesson: (Lesson) -> Unit,
    onMoveLesson: (Lesson, Int) -> Unit,
    onDeleteLesson: (Lesson) -> Unit,
) {
    InkCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                section?.title ?: tr(StrStudio.ungrouped),
                color = Ink.TextPrimary,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f),
            )
            if (section != null) {
                IconAction(Icons.Default.ArrowUpward, tr(StrStudio.moveUp), enabled = !isFirst) { onMove(-1) }
                IconAction(Icons.Default.ArrowDownward, tr(StrStudio.moveDown), enabled = !isLast) { onMove(1) }
                IconAction(Icons.Default.Edit, tr(StrStudio.renameSection)) { onRename() }
                IconAction(Icons.Default.DeleteOutline, tr(StrStudio.deleteSection), tint = Ink.Coral) { onDelete() }
            }
        }

        Spacer(Modifier.height(10.dp))

        if (lessons.isEmpty()) {
            Text(tr(StrStudio.noLessonsInSection), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
        } else {
            lessons.forEachIndexed { index, lesson ->
                LessonRow(
                    lesson = lesson,
                    position = index + 1,
                    isFirst = index == 0,
                    isLast = index == lessons.lastIndex,
                    onEdit = { onEditLesson(lesson) },
                    onMove = { delta -> onMoveLesson(lesson, delta) },
                    onDelete = { onDeleteLesson(lesson) },
                )
                if (index != lessons.lastIndex) {
                    Spacer(Modifier.height(6.dp))
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SecondaryAction(tr(StrStudio.addLesson), Modifier.fillMaxWidth(), onClick = onAddLesson)
    }
}

@Composable
private fun LessonRow(
    lesson: Lesson,
    position: Int,
    isFirst: Boolean,
    isLast: Boolean,
    onEdit: () -> Unit,
    onMove: (Int) -> Unit,
    onDelete: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Ink.SurfaceHigh)
            .clickable(onClick = onEdit)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "$position. ${lesson.title}",
                color = Ink.TextPrimary,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(codeLabel(lesson.kind), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                if (lesson.durationSeconds > 0) {
                    Text(
                        "· ${lesson.durationSeconds / 60}",
                        color = Ink.TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                if (lesson.isPreview) {
                    Pill(tr(StrStudio.previewBadge), background = Ink.TealSoft, foreground = Ink.Teal)
                }
            }
        }
        IconAction(Icons.Default.ArrowUpward, tr(StrStudio.moveUp), enabled = !isFirst) { onMove(-1) }
        IconAction(Icons.Default.ArrowDownward, tr(StrStudio.moveDown), enabled = !isLast) { onMove(1) }
        IconAction(Icons.Default.DeleteOutline, tr(StrStudio.delete), tint = Ink.Coral) { onDelete() }
    }
}

@Composable
private fun EditorActionBar(
    status: String,
    needsReview: Boolean,
    busy: Boolean,
    savedTick: Int,
    onSave: () -> Unit,
    onPublish: () -> Unit,
    onUnpublish: () -> Unit,
) {
    val live = status == "PUBLISHED" || status == "PENDING_REVIEW"
    Column(
        Modifier
            .fillMaxWidth()
            .background(Ink.Surface)
            .navigationBarsPadding()
            .padding(horizontal = Dimens.screenPadding, vertical = 12.dp),
    ) {
        if (savedTick > 0 && !busy) {
            Text(tr(StrStudio.saved), color = Ink.Teal, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            SecondaryAction(
                if (status == "DRAFT") tr(StrStudio.saveDraft) else tr(StrStudio.save),
                Modifier.weight(1f),
                enabled = !busy,
                onClick = onSave,
            )
            Box(Modifier.weight(1f)) {
                if (live) {
                    PrimaryAction(tr(StrStudio.unpublish), loading = busy, onClick = onUnpublish)
                } else {
                    PrimaryAction(
                        if (needsReview) tr(StrStudio.submitForReview) else tr(StrStudio.publish),
                        loading = busy,
                        onClick = onPublish,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LessonSheet(
    target: LessonTarget,
    uploading: Boolean,
    onPickMedia: (String, (String) -> Unit) -> Unit,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String, Int, Boolean) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val lesson = target.lesson

    var title by remember { mutableStateOf(lesson?.title.orEmpty()) }
    var kind by remember { mutableStateOf(lesson?.kind ?: "VIDEO") }
    var videoUrl by remember { mutableStateOf(lesson?.videoUrl.orEmpty()) }
    var documentUrl by remember { mutableStateOf(lesson?.documentUrl.orEmpty()) }
    var content by remember { mutableStateOf(lesson?.content.orEmpty()) }
    var minutes by remember {
        mutableStateOf(if ((lesson?.durationSeconds ?: 0) > 0) ((lesson?.durationSeconds ?: 0) / 60).toString() else "")
    }
    var preview by remember { mutableStateOf(lesson?.isPreview ?: false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Ink.Surface,
        contentColor = Ink.TextPrimary,
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = Dimens.screenPadding)
                .padding(bottom = 28.dp)
                .imePadding(),
        ) {
            Text(
                if (lesson == null) tr(StrStudio.newLesson) else tr(StrStudio.editLesson),
                color = Ink.TextPrimary,
                style = MaterialTheme.typography.titleLarge,
            )
            Spacer(Modifier.height(14.dp))

            InkField(title, { title = it }, tr(StrStudio.lessonTitle))
            Spacer(Modifier.height(12.dp))

            Text(tr(StrStudio.lessonKind), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LESSON_KINDS.forEach { option ->
                    FilterChip(codeLabel(option), kind == option) { kind = option }
                }
            }

            Spacer(Modifier.height(14.dp))

            when (kind) {
                "VIDEO" -> MediaField(
                    label = tr(StrStudio.uploadVideo),
                    icon = Icons.Default.Videocam,
                    value = videoUrl,
                    uploading = uploading,
                    onPick = { onPickMedia("video/*") { videoUrl = it } },
                    onChange = { videoUrl = it },
                )
                "TEXT", "QUIZ" -> {
                    InkField(content, { content = it }, tr(StrStudio.lessonText), singleLine = false, minLines = 5)
                    Spacer(Modifier.height(10.dp))
                    MediaField(
                        label = tr(StrStudio.uploadImage),
                        icon = Icons.Default.Image,
                        value = documentUrl,
                        uploading = uploading,
                        onPick = { onPickMedia("image/*") { documentUrl = it } },
                        onChange = { documentUrl = it },
                    )
                }
                else -> MediaField(
                    label = tr(StrStudio.uploadDocument),
                    icon = Icons.Default.AttachFile,
                    value = documentUrl,
                    uploading = uploading,
                    onPick = { onPickMedia("*/*") { documentUrl = it } },
                    onChange = { documentUrl = it },
                )
            }

            Spacer(Modifier.height(12.dp))
            InkField(
                minutes,
                { minutes = it.filter(Char::isDigit) },
                tr(StrStudio.minutesField),
                keyboardType = KeyboardType.Number,
            )

            Spacer(Modifier.height(14.dp))
            ToggleRow(tr(StrStudio.freePreview), tr(StrStudio.freePreviewSub), preview) { preview = it }

            Spacer(Modifier.height(18.dp))
            PrimaryAction(tr(StrStudio.save), enabled = title.isNotBlank() && !uploading) {
                onSave(title, kind, videoUrl, documentUrl, content, minutes.toIntOrNull() ?: 0, preview)
            }
            Spacer(Modifier.height(8.dp))
            SecondaryAction(tr(StrStudio.cancel), Modifier.fillMaxWidth(), onClick = onDismiss)
        }
    }
}

@Composable
private fun MediaField(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    uploading: Boolean,
    onPick: () -> Unit,
    onChange: (String) -> Unit,
) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Ink.SurfaceHigh)
                .clickable(enabled = !uploading, onClick = onPick)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (uploading) {
                CircularProgressIndicator(color = Ink.Amber, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
            } else {
                Icon(icon, null, tint = Ink.Amber, modifier = Modifier.size(19.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    if (uploading) tr(StrStudio.uploading) else label,
                    color = Ink.TextPrimary,
                    style = MaterialTheme.typography.titleSmall,
                )
                Text(
                    if (value.isNotBlank()) tr(StrStudio.attached) else tr(StrStudio.uploadLimit),
                    color = if (value.isNotBlank()) Ink.Teal else Ink.TextMuted,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Icon(Icons.Default.Add, null, tint = Ink.TextMuted, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(8.dp))
        InkField(value, onChange, tr(StrStudio.mediaUrl))
    }
}

@Composable
private fun SectionTitleDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ink.Surface,
        titleContentColor = Ink.TextPrimary,
        title = { Text(if (initial.isBlank()) tr(StrStudio.addSection) else tr(StrStudio.renameSection)) },
        text = {
            Column {
                InkField(value, { value = it }, tr(StrStudio.sectionTitle))
                if (initial.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(tr(StrStudio.deleteSectionBody), color = Ink.TextMuted, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(value.trim()) }, enabled = value.isNotBlank()) {
                Text(tr(StrStudio.save), color = Ink.Amber)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(tr(StrStudio.cancel), color = Ink.TextMuted) }
        },
    )
}
