package com.rork.pro.ui.components

import android.content.Context
import android.util.Log
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.rork.pro.BuildConfig
import com.rork.pro.data.AdsRepository
import kotlinx.coroutines.delay

private const val TAG = "Ads"

/** A first request can simply arrive before any ad is ready, so one retry is allowed. */
private const val MAX_RETRIES = 1
private const val RETRY_DELAY_MS = 15_000L

/**
 * Starts the ads SDK once per process, and only when a real application id was built in.
 *
 * Without an id the SDK is never touched at all, so a build with no AdMob account behaves
 * exactly as if ads did not exist.
 */
private object Ads {
    /**
     * Google's own banner unit, used only in debug builds. A development device gets no fill
     * for a brand new live unit, and tapping a live ad while testing puts the AdMob account at
     * risk — so debug builds always request Google's test ad, release builds always request the
     * unit the owner configured in the database.
     */
    private const val TEST_BANNER_UNIT = "ca-app-pub-3940256099942544/6300978111"

    @Volatile
    private var started = false

    val configured: Boolean get() = BuildConfig.ADMOB_APP_ID.isNotBlank()

    fun start(context: Context) {
        if (!configured || started) return
        started = true
        runCatching {
            if (BuildConfig.DEBUG) {
                MobileAds.setRequestConfiguration(
                    RequestConfiguration.Builder()
                        .setTestDeviceIds(listOf(AdRequest.DEVICE_ID_EMULATOR))
                        .build(),
                )
            }
            MobileAds.initialize(context.applicationContext) {
                Log.i(TAG, "Mobile Ads SDK ready")
            }
        }.onFailure { Log.w(TAG, "Ads SDK could not start: ${it.message}") }
    }

    fun unitFor(placementUnitId: String): String =
        if (BuildConfig.DEBUG) TEST_BANNER_UNIT else placementUnitId
}

/**
 * Starts the ads SDK as the app opens, so the first banner does not have to wait for
 * initialisation before it can request anything.
 */
fun initAds(context: Context) = Ads.start(context)

/**
 * Banner slot driven entirely by the database.
 *
 * The server decides whether this learner may see an ad here at all — ads are off globally
 * unless the owner switched them on, never appear on paid content and never for someone with
 * paid access — and it hands back the ad unit to request. Anything that fails, is switched
 * off, or has nothing to fill it renders no space at all.
 */
@Composable
fun AdBanner(screen: String, modifier: Modifier = Modifier, courseId: String? = null) {
    if (!Ads.configured) return

    val context = LocalContext.current
    val widthDp = LocalConfiguration.current.screenWidthDp
    var unitId by remember(screen, courseId) { mutableStateOf<String?>(null) }
    var attempt by remember(screen, courseId) { mutableIntStateOf(0) }
    var failed by remember(screen, courseId) { mutableStateOf(false) }

    LaunchedEffect(screen, courseId) {
        val config = runCatching { AdsRepository.config(screen, courseId) }
            .onFailure { Log.w(TAG, "Ad config for $screen failed: ${it.message}") }
            .getOrNull()
        val placement = config?.banner()
        if (placement == null) {
            Log.i(TAG, "No banner for $screen (enabled=${config?.enabled}, reason=${config?.reason})")
            return@LaunchedEffect
        }
        Ads.start(context)
        unitId = Ads.unitFor(placement.adUnitId)
    }

    // No fill on the first request is normal; the slot is only given up after a quiet retry.
    LaunchedEffect(failed, attempt) {
        if (!failed || attempt >= MAX_RETRIES) return@LaunchedEffect
        delay(RETRY_DELAY_MS)
        attempt += 1
        failed = false
    }

    val id = unitId
    if (id == null || (failed && attempt >= MAX_RETRIES)) return

    val adView = remember(id, attempt) {
        AdView(context).apply {
            adUnitId = id
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp))
            adListener = object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    // A misconfigured unit or an empty inventory must never leave a gap on screen.
                    Log.w(TAG, "Banner $screen failed: ${error.code} ${error.message}")
                    failed = true
                }

                override fun onAdLoaded() {
                    Log.i(TAG, "Banner $screen loaded")
                }
            }
            runCatching { loadAd(AdRequest.Builder().build()) }
                .onFailure { Log.w(TAG, "Banner $screen request failed: ${it.message}") }
        }
    }

    DisposableEffect(adView) {
        onDispose { adView.destroy() }
    }

    Box(modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        AndroidView(factory = { adView })
    }
}
