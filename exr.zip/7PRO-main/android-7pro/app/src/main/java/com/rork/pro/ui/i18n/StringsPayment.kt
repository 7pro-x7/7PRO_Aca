package com.rork.pro.ui.i18n

/** The 7PRO payment sheet and the hosted gateway checkout it opens. */
object StrPay {
    val title = Tr("Complete your payment", "أكمل عملية الدفع")
    val orderSummary = Tr("Order summary", "ملخص الطلب")
    val listPrice = Tr("Price", "السعر")
    val discount = Tr("Discount", "الخصم")
    val totalDue = Tr("Total due", "الإجمالي المستحق")
    val chooseMethod = Tr("Choose how to pay", "اختر طريقة الدفع")
    val loadingMethods = Tr("Loading payment methods…", "جارٍ تحميل طرق الدفع…")
    val payNow = Tr("Pay %s securely", "ادفع %s بأمان")
    val securedBy = Tr(
        "Encrypted and processed by Paymob. 7PRO never sees your card details.",
        "مشفّر ومعالَج عبر Paymob. لا يطّلع 7PRO على بيانات بطاقتك إطلاقًا.",
    )
    val checkoutTitle = Tr("Secure checkout", "دفع آمن")
    val waitingConfirmation = Tr("Confirming your payment…", "جارٍ تأكيد عملية الدفع…")
    val doNotClose = Tr("Keep this screen open until the payment is confirmed.", "أبقِ هذه الشاشة مفتوحة حتى يتم تأكيد الدفع.")
    val paymentConfirmed = Tr("Payment confirmed", "تم تأكيد الدفع")
    val accessUnlocked = Tr("Your access is unlocked. Enjoy your lessons!", "تم تفعيل وصولك. استمتع بدروسك!")
    val startLearning = Tr("Start learning", "ابدأ التعلم")
    val paymentFailed = Tr("The payment did not go through", "لم تكتمل عملية الدفع")
    val paymentFailedBody = Tr(
        "No money was taken. You can try again with another method.",
        "لم يتم خصم أي مبلغ. يمكنك المحاولة مرة أخرى بطريقة أخرى.",
    )
    val tryAgain = Tr("Try again", "حاول مرة أخرى")
    val openInBrowser = Tr("Open in browser instead", "الفتح في المتصفح بدلاً من ذلك")
    val cancelPayment = Tr("Cancel payment", "إلغاء الدفع")

    // Method families
    val methodCard = Tr("Card", "بطاقة بنكية")
    val methodCardSub = Tr("Visa, Mastercard", "فيزا، ماستركارد")
    val methodWallet = Tr("Mobile wallet", "محفظة إلكترونية")
    val methodWalletSub = Tr("Vodafone Cash, Orange, Etisalat, WE", "فودافون كاش، أورنج، اتصالات، وي")
    val methodInstapay = Tr("InstaPay", "إنستاباي")
    val methodInstapaySub = Tr("Instant bank transfer", "تحويل بنكي فوري")
    val methodMeeza = Tr("Meeza", "ميزة")
    val methodMeezaSub = Tr("Egyptian national card", "البطاقة الوطنية المصرية")
    val methodKiosk = Tr("Cash at a kiosk", "دفع نقدي من منفذ")
    val methodKioskSub = Tr("Aman, Masary and partners", "أمان ومصاري ومنافذ أخرى")
    val methodInstallment = Tr("Pay in instalments", "الدفع بالتقسيط")
    val methodInstallmentSub = Tr("Subject to provider approval", "حسب موافقة جهة التقسيط")
}
