package com.rork.pro.data

import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Teacher Studio data. Every query is scoped to the signed-in teacher and the
 * database policies enforce the same boundary, so one teacher can never read another's data.
 */
object TeacherRepository {

    private fun me(): String = Backend.currentUserId ?: error("UNAUTHORIZED")

    suspend fun analytics(): JsonObject =
        Backend.rpcRaw(
            "teacher_analytics",
            buildJsonObject {
                put("p_teacher", me())
                put("p_from", null as String?)
                put("p_to", null as String?)
            },
        ) as JsonObject

    suspend fun balance(): TeacherBalance =
        Backend.rpc("teacher_balance", buildJsonObject { put("p_teacher", me()) })

    suspend fun myCourses(): List<Course> =
        Backend.client.from("courses")
            .select {
                filter { eq("teacher_id", me()) }
                order("created_at", Order.DESCENDING)
            }
            .decodeList()

    suspend fun myExercises(): List<PlacementTest> =
        Backend.client.from("placement_tests")
            .select {
                filter {
                    eq("owner_id", me())
                    eq("scope", "TEACHER")
                }
                order("created_at", Order.DESCENDING)
            }
            .decodeList()

    suspend fun saveExercise(
        id: String?,
        title: String,
        description: String,
        questionCount: Int,
        timeLimit: Int,
    ): PlacementTest {
        val payload = buildJsonObject {
            put("owner_id", me())
            put("scope", "TEACHER")
            put("title", title.trim())
            put("description", description.trim().ifBlank { null })
            put("is_adaptive", false)
            put("question_count", questionCount)
            put("time_limit_seconds", timeLimit)
            put("passing_score", 50.0)
        }
        return if (id == null) {
            Backend.client.from("placement_tests").insert(payload) { select() }.decodeSingle()
        } else {
            Backend.client.from("placement_tests").update(payload) {
                select()
                filter {
                    eq("id", id)
                    eq("owner_id", me())
                    eq("scope", "TEACHER")
                }
            }.decodeSingle()
        }
    }

    suspend fun setExerciseStatus(id: String, status: String) {
        Backend.client.from("placement_tests").update(buildJsonObject { put("status", status) }) {
            filter {
                eq("id", id)
                eq("owner_id", me())
                eq("scope", "TEACHER")
            }
        }
    }

    suspend fun deleteExercise(id: String) {
        Backend.client.from("placement_tests").delete {
            filter {
                eq("id", id)
                eq("owner_id", me())
                eq("scope", "TEACHER")
            }
        }
    }

    suspend fun addExerciseQuestion(
        exerciseId: String,
        kind: String,
        prompt: String,
        options: List<String>,
        correctIndexes: List<Int>,
        correctText: List<String>,
        imageUrl: String,
        audioUrl: String,
        videoUrl: String,
    ) {
        Backend.client.from("test_questions").insert(
            buildJsonObject {
                put("test_id", exerciseId)
                put("kind", kind)
                put("skill", "GENERAL")
                put("difficulty", 3)
                put("prompt", prompt.trim())
                put("options", kotlinx.serialization.json.JsonArray(options.map { kotlinx.serialization.json.JsonPrimitive(it) }))
                put("correct_indexes", kotlinx.serialization.json.JsonArray(correctIndexes.map { kotlinx.serialization.json.JsonPrimitive(it) }))
                put("correct_text", kotlinx.serialization.json.JsonArray(correctText.map { kotlinx.serialization.json.JsonPrimitive(it) }))
                put("points", 1.0)
                put("media_image_url", imageUrl.trim().ifBlank { null })
                put("media_audio_url", audioUrl.trim().ifBlank { null })
                put("media_video_url", videoUrl.trim().ifBlank { null })
            },
        )
    }

    suspend fun saveCourse(
        id: String?,
        title: String,
        subtitle: String,
        description: String,
        thumbnailUrl: String,
        level: String,
        categoryId: String?,
        price: Double,
        currency: String,
        isFree: Boolean,
    ): Course {
        val payload = buildJsonObject {
            put("teacher_id", me())
            put("title", title)
            put("subtitle", subtitle)
            put("description", description)
            put("thumbnail_url", thumbnailUrl.ifBlank { null })
            put("level", level.ifBlank { null })
            put("category_id", categoryId)
            put("base_price", price)
            put("base_currency", currency)
            put("is_free", isFree)
        }
        return if (id == null) {
            Backend.client.from("courses").insert(payload) { select() }.decodeSingle()
        } else {
            Backend.client.from("courses").update(payload) {
                select()
                filter { eq("id", id) }
            }.decodeSingle()
        }
    }

    suspend fun submitCourseForReview(courseId: String) {
        Backend.client.from("courses")
            .update(buildJsonObject { put("status", "PENDING_REVIEW") }) { filter { eq("id", courseId) } }
    }

    suspend fun lessons(courseId: String): List<Lesson> =
        Backend.client.from("lessons")
            .select {
                filter { eq("course_id", courseId) }
                order("sort_order", Order.ASCENDING)
            }
            .decodeList()

    suspend fun saveLesson(
        id: String?,
        courseId: String,
        title: String,
        kind: String,
        videoUrl: String,
        documentUrl: String,
        content: String,
        durationSeconds: Int,
        sortOrder: Int,
        isPreview: Boolean,
    ) {
        val payload = buildJsonObject {
            put("course_id", courseId)
            put("title", title)
            put("kind", kind)
            put("video_url", videoUrl.ifBlank { null })
            put("document_url", documentUrl.ifBlank { null })
            put("content", content.ifBlank { null })
            put("duration_seconds", durationSeconds)
            put("sort_order", sortOrder)
            put("is_preview", isPreview)
        }
        if (id == null) {
            Backend.client.from("lessons").insert(payload)
        } else {
            Backend.client.from("lessons").update(payload) { filter { eq("id", id) } }
        }
    }

    suspend fun deleteLesson(id: String) {
        Backend.client.from("lessons").delete { filter { eq("id", id) } }
    }

    suspend fun ledger(): List<LedgerEntry> =
        Backend.client.from("teacher_ledger")
            .select {
                filter { eq("teacher_id", me()) }
                order("created_at", Order.DESCENDING)
                limit(100)
            }
            .decodeList()

    suspend fun payouts(): List<Payout> =
        Backend.client.from("payouts")
            .select {
                filter { eq("teacher_id", me()) }
                order("requested_at", Order.DESCENDING)
            }
            .decodeList()

    suspend fun requestPayout(amount: Double, method: String, destination: String, note: String) {
        Backend.rpcVoid(
            "request_payout",
            buildJsonObject {
                put("p_amount", amount)
                put("p_method", method)
                put("p_destination", destination)
                put("p_note", note)
            },
        )
    }

    suspend fun updateTeacherProfile(headline: String, bio: String, photoUrl: String, subjects: List<String>, languages: List<String>, years: Int) {
        Backend.client.from("teacher_profiles").update(
            buildJsonObject {
                put("headline", headline)
                put("bio", bio)
                put("photo_url", photoUrl.ifBlank { null })
                put("subjects", kotlinx.serialization.json.JsonArray(subjects.map { kotlinx.serialization.json.JsonPrimitive(it) }))
                put("languages", kotlinx.serialization.json.JsonArray(languages.map { kotlinx.serialization.json.JsonPrimitive(it) }))
                put("experience_years", years)
            },
        ) { filter { eq("id", me()) } }
    }
}
