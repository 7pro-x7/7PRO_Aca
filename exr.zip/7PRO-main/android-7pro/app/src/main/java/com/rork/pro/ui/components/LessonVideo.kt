package com.rork.pro.ui.components

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.net.toUri
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * How a lesson media URL should be presented.
 *
 * [Embedded] is played through an in-app web view (YouTube, Vimeo, Google Drive…),
 * [Streamed] through the native player, and [Link] can only be handed to another app.
 */
sealed interface LessonMedia {
    /**
     * Provider page that exposes an iframe embed.
     *
     * [portrait] records that the source is a tall 9:16 video (a YouTube Short, for example),
     * which decides how the screen is turned when the player goes fullscreen.
     */
    data class Embedded(val embedUrl: String, val portrait: Boolean = false) : LessonMedia

    /** Direct media file or stream playable by ExoPlayer. */
    data class Streamed(val url: String) : LessonMedia

    /** Anything else (documents, unknown pages) — opened outside the app. */
    data object Link : LessonMedia
}

private val streamableExtensions = setOf(
    "mp4", "m4v", "mov", "webm", "mkv", "3gp", "m3u8", "mpd",
    "mp3", "m4a", "aac", "wav", "ogg", "opus",
)

/** YouTube Shorts are always shot and published 9:16. */
private fun isYouTubeShort(host: String, uri: Uri): Boolean =
    (host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com")) &&
        uri.pathSegments.orEmpty().firstOrNull() == "shorts"

private fun youTubeVideoId(host: String, uri: Uri): String? {
    val segments = uri.pathSegments.orEmpty()
    val id = when {
        host == "youtu.be" -> segments.firstOrNull()
        host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com") -> when (segments.firstOrNull()) {
            "watch" -> uri.getQueryParameter("v")
            "embed", "shorts", "live", "v" -> segments.getOrNull(1)
            else -> uri.getQueryParameter("v")
        }
        else -> null
    }
    return id?.takeIf { it.isNotBlank() }
}

/** Maps a teacher-supplied lesson URL to the best in-app playback strategy. */
fun resolveLessonMedia(raw: String): LessonMedia {
    val url = raw.trim()
    if (url.isEmpty()) return LessonMedia.Link

    val uri = runCatching { url.toUri() }.getOrNull() ?: return LessonMedia.Link
    val scheme = uri.scheme?.lowercase()
    if (scheme != "http" && scheme != "https") return LessonMedia.Link

    val host = uri.host?.lowercase()?.removePrefix("www.") ?: return LessonMedia.Link
    val segments = uri.pathSegments.orEmpty()

    youTubeVideoId(host, uri)?.let { id ->
        return LessonMedia.Embedded(
            "https://www.youtube-nocookie.com/embed/$id?rel=0&playsinline=1&modestbranding=1&fs=1",
            portrait = isYouTubeShort(host, uri),
        )
    }

    if (host == "player.vimeo.com") return LessonMedia.Embedded(url)
    if (host == "vimeo.com") {
        val id = segments.lastOrNull { it.all { c -> c.isDigit() } }
        if (!id.isNullOrBlank()) return LessonMedia.Embedded("https://player.vimeo.com/video/$id")
    }

    if (host == "drive.google.com") {
        val id = if (segments.getOrNull(0) == "file" && segments.getOrNull(1) == "d") {
            segments.getOrNull(2)
        } else {
            uri.getQueryParameter("id")
        }
        if (!id.isNullOrBlank()) return LessonMedia.Embedded("https://drive.google.com/file/d/$id/preview")
    }

    if (host == "dailymotion.com" && segments.getOrNull(0) == "video") {
        segments.getOrNull(1)?.takeIf { it.isNotBlank() }?.let {
            return LessonMedia.Embedded("https://www.dailymotion.com/embed/video/$it")
        }
    }

    val extension = uri.path.orEmpty().substringAfterLast('.', "").lowercase()
    if (extension in streamableExtensions) return LessonMedia.Streamed(url)

    return LessonMedia.Link
}

/** Inline player used inside the lesson card. Renders nothing for [LessonMedia.Link]. */
@Composable
fun LessonVideo(media: LessonMedia, modifier: Modifier = Modifier) {
    when (media) {
        is LessonMedia.Embedded -> EmbeddedVideo(media.embedUrl, media.portrait, modifier)
        is LessonMedia.Streamed -> StreamedVideo(media.url, modifier)
        LessonMedia.Link -> Unit
    }
}

// ---------------------------------------------------------------- fullscreen plumbing

/** Walks the context chain to the hosting activity, which owns orientation and system bars. */
private fun Context.findActivity(): Activity? {
    var context: Context? = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    return null
}

/** Hides or restores the status and navigation bars of a window. */
private fun Window.setImmersive(enabled: Boolean, anchor: View) {
    val controller = WindowInsetsControllerCompat(this, anchor)
    if (enabled) {
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    } else {
        controller.show(WindowInsetsCompat.Type.systemBars())
    }
}

/**
 * Landscape videos rotate the screen when expanded; portrait (9:16) lessons stay upright
 * so they fill the phone instead of being squeezed into a sideways letterbox.
 */
private fun orientationFor(aspect: Float?): Int =
    if ((aspect ?: (16f / 9f)) >= 1f) {
        ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    } else {
        ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }

// ---------------------------------------------------------------- embedded (WebView)

private fun embedHtml(embedUrl: String): String =
    "<!DOCTYPE html><html><head>" +
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no\">" +
        "<style>html,body{margin:0;padding:0;background:#000;height:100%;overflow:hidden}" +
        "iframe{border:0;display:block;width:100%;height:100%}</style></head><body>" +
        "<iframe src=\"" + embedUrl + "\" " +
        "allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen\" " +
        "allowfullscreen></iframe></body></html>"

/**
 * Hosts the video view that a web player hands over when its fullscreen button is pressed.
 *
 * The provider (YouTube, Vimeo…) does not resize itself: it calls `onShowCustomView` and
 * expects the app to display that view fullscreen. Without this the button does nothing.
 */
private class WebFullscreenHost(private val activity: Activity?, private val aspect: Float?) {
    private var customView: View? = null
    private var callback: WebChromeClient.CustomViewCallback? = null

    var isActive: Boolean by mutableStateOf(false)
        private set

    fun show(view: View, viewCallback: WebChromeClient.CustomViewCallback) {
        val root = activity?.findViewById<ViewGroup>(android.R.id.content)
        if (root == null) {
            viewCallback.onCustomViewHidden()
            return
        }
        if (customView != null) hide()
        customView = view
        callback = viewCallback
        root.addView(
            view,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        // Turn the screen the way the video is shot: wide clips go landscape, 9:16 clips
        // stay upright and fill the phone instead of sitting in a sideways letterbox.
        activity.requestedOrientation = orientationFor(aspect)
        activity.window.setImmersive(true, view)
        isActive = true
    }

    fun hide() {
        val view = customView ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        customView = null
        runCatching { callback?.onCustomViewHidden() }
        callback = null
        activity?.let {
            it.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            it.window.setImmersive(false, it.window.decorView)
        }
        isActive = false
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun EmbeddedVideo(embedUrl: String, portrait: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val lifecycleOwner = LocalLifecycleOwner.current

    val html = remember(embedUrl) { embedHtml(embedUrl) }
    val baseUrl = remember(embedUrl) {
        val uri = runCatching { embedUrl.toUri() }.getOrNull()
        val host = uri?.host
        if (host.isNullOrBlank()) null else "https://$host"
    }

    val fullscreen = remember(activity, portrait) {
        WebFullscreenHost(activity, if (portrait) 9f / 16f else 16f / 9f)
    }
    var webView by remember(embedUrl) { mutableStateOf<WebView?>(null) }

    // Leaving fullscreen with the system back gesture, exactly like the browser does.
    BackHandler(enabled = fullscreen.isActive) { fullscreen.hide() }

    DisposableEffect(fullscreen) {
        onDispose { fullscreen.hide() }
    }

    // Stop playback (and its audio) when the lesson leaves the screen.
    DisposableEffect(lifecycleOwner, webView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> webView?.onPause()
                Lifecycle.Event.ON_RESUME -> webView?.onResume()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Provider pages letterbox non-16:9 content themselves, so the inline frame stays 16:9.
    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black),
    ) {
        key(embedUrl) {
            AndroidView(
                modifier = Modifier.matchParentSize(),
                factory = { viewContext ->
                    WebView(viewContext).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                        setBackgroundColor(android.graphics.Color.BLACK)
                        webViewClient = WebViewClient()
                        webChromeClient = object : WebChromeClient() {
                            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                                fullscreen.show(view, callback)
                            }

                            override fun onHideCustomView() {
                                fullscreen.hide()
                            }
                        }
                        with(settings) {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            loadWithOverviewMode = true
                            useWideViewPort = true
                        }
                        loadDataWithBaseURL(baseUrl, html, "text/html", "utf-8", null)
                        webView = this
                    }
                },
                onRelease = { view ->
                    fullscreen.hide()
                    webView = null
                    view.loadUrl("about:blank")
                    view.destroy()
                },
            )
        }
    }
}

// ---------------------------------------------------------------- streamed (ExoPlayer)

@OptIn(UnstableApi::class)
@Composable
private fun StreamedVideo(url: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val lifecycleOwner = LocalLifecycleOwner.current

    // The frame starts 16:9 and reshapes to the video's real proportions once known,
    // so portrait (9:16) and square lessons are shown at full size instead of letterboxed.
    var videoAspect by remember(url) { mutableStateOf<Float?>(null) }
    var isFullscreen by remember(url) { mutableStateOf(false) }

    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onVideoSizeChanged(videoSize: VideoSize) {
                    if (videoSize.height > 0) {
                        videoAspect = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
                    }
                }
            })
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = false
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    DisposableEffect(lifecycleOwner, player) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                player.pause()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(videoAspect ?: (16f / 9f))
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black),
    ) {
        AndroidView(
            modifier = Modifier.matchParentSize(),
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    useController = true
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                    // Setting a listener is what makes the fullscreen button appear.
                    setFullscreenButtonClickListener { isFullscreen = true }
                }
            },
            update = { view ->
                // Only one surface may hold the player, so the inline view lets go while expanded.
                view.player = if (isFullscreen) null else player
                view.setFullscreenButtonState(false)
            },
            onRelease = { view -> view.player = null },
        )
    }

    if (isFullscreen) {
        FullscreenPlayer(
            player = player,
            aspect = videoAspect,
            activity = activity,
            onExit = { isFullscreen = false },
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun FullscreenPlayer(
    player: ExoPlayer,
    aspect: Float?,
    activity: Activity?,
    onExit: () -> Unit,
) {
    DisposableEffect(activity, aspect) {
        val previous = activity?.requestedOrientation
        activity?.requestedOrientation = orientationFor(aspect)
        onDispose {
            activity?.requestedOrientation = previous ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    Dialog(
        onDismissRequest = onExit,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
        ),
    ) {
        val dialogView = LocalView.current
        DisposableEffect(dialogView) {
            val window = (dialogView.parent as? DialogWindowProvider)?.window
            window?.let {
                WindowCompat.setDecorFitsSystemWindows(it, false)
                it.setImmersive(true, dialogView)
            }
            onDispose { window?.setImmersive(false, dialogView) }
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black),
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { viewContext ->
                    PlayerView(viewContext).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                        setBackgroundColor(android.graphics.Color.BLACK)
                        useController = true
                        setShowNextButton(false)
                        setShowPreviousButton(false)
                        setFullscreenButtonClickListener { onExit() }
                    }
                },
                update = { view ->
                    view.player = player
                    view.setFullscreenButtonState(true)
                },
                onRelease = { view -> view.player = null },
            )
        }
    }
}
