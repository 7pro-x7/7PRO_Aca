package com.rork.pro.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/** A file the user picked, already read into memory and ready to upload. */
data class PickedFile(val bytes: ByteArray, val name: String) {
    override fun equals(other: Any?): Boolean = this === other
    override fun hashCode(): Int = System.identityHashCode(this)
}

/**
 * Uploads course covers, lesson videos, images and documents to the public `course-media`
 * bucket. Storage policies keep every teacher inside their own folder, while course staff
 * may write anywhere in the bucket.
 */
object MediaRepository {

    private const val BUCKET = "course-media"

    /** Matches the bucket's server-side limit so oversized files fail fast with a clear message. */
    const val MAX_BYTES: Long = 50L * 1024L * 1024L

    /** Reads a picked document into memory, rejecting anything the bucket would refuse. */
    suspend fun read(context: Context, uri: Uri): PickedFile = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val name = displayName(context, uri)
        val bytes = runCatching {
            resolver.openInputStream(uri)?.use { it.readBytes() }
        }.getOrNull() ?: error("FILE_UNREADABLE")
        if (bytes.size > MAX_BYTES) error("FILE_TOO_LARGE")
        PickedFile(bytes, name)
    }

    /** Uploads the file and returns the public URL to store on the course or lesson. */
    suspend fun upload(file: PickedFile, folder: String): String = withContext(Dispatchers.IO) {
        val userId = Backend.currentUserId ?: error("UNAUTHORIZED")
        val path = "$userId/$folder/${System.currentTimeMillis()}-${sanitize(file.name)}"
        val bucket = Backend.client.storage.from(BUCKET)
        bucket.upload(path, file.bytes) { upsert = false }
        bucket.publicUrl(path)
    }

    private fun displayName(context: Context, uri: Uri): String {
        val cursor = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        }.getOrNull()
        cursor?.use {
            if (it.moveToFirst() && !it.isNull(0)) return it.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "upload"
    }

    /** Storage keys allow a narrow character set, so anything else is folded to an underscore. */
    private fun sanitize(name: String): String {
        val cleaned = name.lowercase(Locale.US).replace(Regex("[^a-z0-9._-]"), "_")
        return cleaned.takeLast(64).ifBlank { "upload" }
    }
}
