package com.rork.pro.data

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.rork.pro.MainActivity
import com.rork.pro.R

/**
 * Turns the account's notification history into device notifications.
 *
 * Nothing is invented here: every alert is a row the server already wrote — a confirmed payment,
 * an access change, a decision on a course, an owner announcement. Each row is shown at most
 * once (the highest id already delivered is remembered), so nothing repeats or duplicates, and
 * anything the person has already read in the app is never raised on the device.
 */
object PushCenter {

    const val EXTRA_ROUTE = "7pro.route"

    private const val PREFS = "7pro.push"
    private const val KEY_LAST_ID = "last_delivered_id"
    private const val CHANNEL_ID = "7pro.important"

    /** Kinds worth interrupting someone for. Anything else stays in the in-app history only. */
    private val IMPORTANT = setOf(
        "PAYMENT",
        "ORDER",
        "ORDER_PAID",
        "REFUND",
        "SUBSCRIPTION",
        "ENROLLMENT",
        "COURSE",
        "COURSE_REVIEW",
        "CERTIFICATE",
        "SECURITY",
        "ACCOUNT",
        "ADMIN",
        "TEACHER",
        "PAYOUT",
        "ANNOUNCEMENT",
        "TEST_RESULT",
    )

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun lastDelivered(context: Context): Long = prefs(context).getLong(KEY_LAST_ID, 0L)

    private fun setLastDelivered(context: Context, id: Long) {
        prefs(context).edit().putLong(KEY_LAST_ID, id).apply()
    }

    /** Forgets the delivery watermark, so a new account does not inherit another's history. */
    fun reset(context: Context) {
        prefs(context).edit().remove(KEY_LAST_ID).apply()
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "7PRO", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Payments, access changes and academy announcements"
            },
        )
    }

    private fun canPost(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    /**
     * Reads what is new for the signed-in account and raises it on the device.
     *
     * Safe to call from anywhere and as often as needed: it is a no-op when signed out, when
     * notifications are blocked, or when there is nothing newer than the last delivery.
     */
    suspend fun sync(context: Context) {
        if (!Backend.isConfigured || Backend.currentUserId == null) return
        if (!canPost(context)) return

        val notifications = runCatching { SessionRepository.notifications() }.getOrNull().orEmpty()
        if (notifications.isEmpty()) return

        val newest = notifications.maxOf { it.id }
        val watermark = lastDelivered(context)

        // First run on a device only records where the history is, instead of firing a backlog.
        if (watermark == 0L) {
            setLastDelivered(context, newest)
            return
        }
        if (newest <= watermark) return

        ensureChannel(context)
        val manager = NotificationManagerCompat.from(context)

        notifications
            .filter { it.id > watermark && it.readAt == null && it.kind.uppercase() in IMPORTANT }
            .sortedBy { it.id }
            .forEach { notification ->
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(EXTRA_ROUTE, notification.deepLink)
                }
                val pending = PendingIntent.getActivity(
                    context,
                    notification.id.toInt(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                val built = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle(notification.title)
                    .setContentText(notification.body.orEmpty())
                    .setStyle(NotificationCompat.BigTextStyle().bigText(notification.body.orEmpty()))
                    .setContentIntent(pending)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .build()
                runCatching { manager.notify(notification.id.toInt(), built) }
            }

        setLastDelivered(context, newest)
    }
}
