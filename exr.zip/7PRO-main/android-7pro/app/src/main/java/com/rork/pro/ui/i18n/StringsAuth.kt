package com.rork.pro.ui.i18n

/** Sign in / sign up / password reset. */
object StrAuth {
    val tagline = Tr("The English academy that meets you at your level", "أكاديمية اللغة الإنجليزية التي تبدأ من مستواك")
    val welcomeBack = Tr("Welcome back", "مرحبًا بعودتك")
    val createYourAccount = Tr("Create your account", "أنشئ حسابك")
    val resetYourPassword = Tr("Reset your password", "إعادة تعيين كلمة المرور")
    val fullName = Tr("Full name", "الاسم الكامل")
    val phoneOptional = Tr("Phone (optional)", "رقم الهاتف (اختياري)")
    val emailAddress = Tr("Email address", "البريد الإلكتروني")
    val password = Tr("Password", "كلمة المرور")
    val hidePassword = Tr("Hide password", "إخفاء كلمة المرور")
    val showPassword = Tr("Show password", "إظهار كلمة المرور")
    val signIn = Tr("Sign in", "تسجيل الدخول")
    val createAccount = Tr("Create account", "إنشاء حساب")
    val sendResetLink = Tr("Send reset link", "إرسال رابط إعادة التعيين")
    val forgotPassword = Tr("Forgot password", "نسيت كلمة المرور")
    val backToSignIn = Tr("Back to sign in", "العودة لتسجيل الدخول")
    val trustLine = Tr("Free adaptive placement test · verified teachers · secure payments", "اختبار تحديد مستوى مجاني · معلمون موثوقون · مدفوعات آمنة")
    val continueWithGoogle = Tr("Continue with Google", "المتابعة باستخدام Google")
    val orUseEmail = Tr("or use your email", "أو استخدم بريدك الإلكتروني")
    val noEmailConfirmation = Tr(
        "No email confirmation needed — you are in straight away.",
        "لا حاجة لتأكيد البريد الإلكتروني — تدخل مباشرة.",
    )
}
