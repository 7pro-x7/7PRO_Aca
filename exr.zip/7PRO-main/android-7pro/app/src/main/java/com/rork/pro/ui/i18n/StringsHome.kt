package com.rork.pro.ui.i18n

/** Student home dashboard. */
object StrHome {
    val notifications = Tr("Notifications", "الإشعارات")
    val searchCourses = Tr("Search courses", "ابحث عن دورة")
    val takeFreeLevelTest = Tr("Take your free level test", "اختبر مستواك مجانًا")
    val all = Tr("All", "الكل")
    val featuredCourses = Tr("Featured courses", "دورات مختارة")
    val seeAll = Tr("See all", "عرض الكل")
    val noCoursesYet = Tr("No courses published yet", "لم يتم نشر أي دورات بعد")
    val noCoursesYetBody = Tr("New courses appear here as soon as the academy publishes them.", "ستظهر الدورات الجديدة هنا فور نشرها من الأكاديمية.")
    val goodMorning = Tr("Good morning", "صباح الخير")
    val goodAfternoon = Tr("Good afternoon", "مساء الخير")
    val goodEvening = Tr("Good evening", "مساء الخير")
    val freePlacementTest = Tr("Free adaptive placement test", "اختبار تحديد المستوى التكيفي المجاني")
    val freePlacementBody = Tr("Answer a short set of questions that adapt to you, and get your CEFR level with a full skill breakdown.", "أجب عن مجموعة قصيرة من الأسئلة التي تتكيف مع مستواك، واحصل على مستواك وفق الإطار الأوروبي مع تحليل كامل لمهاراتك.")
    val startTheTest = Tr("Start the test →", "ابدأ الاختبار ←")
    val yourLevelResult = Tr("Your level result", "نتيجة مستواك")
    val sevenProTeacher = Tr("7PRO teacher", "معلم في 7PRO")
    val scheduleAnnounced = Tr("Schedule announced by the teacher", "يعلن المعلم عن الموعد")
    val waitlist = Tr("Waitlist", "قائمة الانتظار")
    val thereFallback = Tr("there", "بك")
    val greetingLine = Tr("%1${'$'}s, %2${'$'}s", "%1${'$'}s، %2${'$'}s")
    val dayStreak = Tr("%d day streak", "%d يوم متتالٍ")
    val scoredBreakdown = Tr(
        "Scored %d%% · tap for your skill breakdown",
        "حصلت على %d%% · اضغط لعرض تحليل مهاراتك",
    )
    val seatsLeft = Tr("%d left", "بقي %d")
}
